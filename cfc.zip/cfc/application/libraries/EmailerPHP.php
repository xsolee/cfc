<?php 
if (!defined('BASEPATH')) exit('No direct script access allowed');  

require_once APPPATH."/third_party/PHPMailer/class.phpmailer.php";
require_once APPPATH."/third_party/PHPMailer/class.smtp.php";

 
class EmailerPHP extends PHPMailer {
	public function __construct() {
		parent::__construct();
		//~ $this->SMTPDebug = 3;                               // Enable verbose debug output
		$this->isSMTP();                                      // Set mailer to use SMTP
		$this->CharSet  = "UTF-8";
		// $this->Host     = 'smtp.gmail.com';                      // Specify main and backup SMTP servers
		// $this->Username   = 'phildepta@gmail.com';                    // SMTP username
		// $this->Password   = 'Dan1975123';                           // SMTP password
		// $this->From       = 'phildepta@gmail.com';
        $this->Host       = "gator4262.hostgator.com";
        $this->SMTPAuth = true; 
		$this->Username = 'admin@cfcteam.org';
		$this->Password = 'cfcteam2019';
		$this->From       = 'admin@cfcteam.org';
		$this->FromName   = 'CFC Team Notification';
		$this->SMTPSecure = 'ssl';   // ssl doesn't work on GoDaddy CPanel SMTP
		$this->Port = 465; 
		$this->isHTML(true);                                  // Set 
	}
}
