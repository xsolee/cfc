<?php 

class Announcement_Model extends CI_Model {
    
    public function __construct() {
        parent::__construct();
    }

    public function get_all_announcements()
    {
        $sql    = "SELECT * FROM announcements";
        $query  = $this->db->query($sql);
        $return = $query->result();
        return $return;
    }

    public function get_visible_announcements()
    {
        $sql    = "SELECT * FROM announcements WHERE visible = 1 ORDER BY id DESC";
        $query  = $this->db->query($sql);
        $return = $query->result();
        return $return;
    }

    public function get_announcement_by_id($announcement_id)
    {
        $sql    = "SELECT * FROM announcements WHERE id = ?";
        $query  = $this->db->query($sql,$announcement_id);
        $return = $query->row();
        return $return;
    }

    public function update_announcement($params)
    {
        $sql    = "SELECT * FROM announcements WHERE id = ?";
        $query  = $this->db->query($sql,$params['id']);
        $return = $query->row();
        
        if($return) {
            $this->db->where('id', $params['id']);
            $this->db->update('announcements', $params); 
        } else {
            unset($params['id']);
            $this->db->insert('announcements', $params);
        }

        return true;
    }
}

?>