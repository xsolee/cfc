<?php 
class Token_gaming_model extends CI_Model {
	public function __construct() {
		parent::__construct();
	}

	public function get_token_by_account_id($account_id) {

        $where = '';
        if($account_id != 1) {
            $where .= ' AND tl.account_id = ' . $account_id;
        }

		$sql = 'SELECT
                tl.account_id,
                a.username,
                a.mobile_number,
                tl.id token_line_id,
                th.batch_id,
                th.date_drawn,
                th.winner_combination1,
                tl.serial_number,
                tl.combination1,
                tl.combination2,
                tl.combination3,
                tl.created_date
                FROM token_lines tl
                LEFT JOIN token_headers th
                ON tl.header_id = th.id
                LEFT JOIN accounts a
                ON tl.account_id = a.account_id
                WHERE 1=1
                '.$where.'
                ORDER BY tl.id ASC';
		$query  = $this->db->query($sql);
		$return = $query->result();
		return $return;
	}

    public function get_all_headers() {

        $sql    = "SELECT a.*, c.username FROM token_headers a LEFT JOIN token_lines b ON a.winner_token_id = b.id LEFT JOIN accounts c ON b.account_id = c.account_id";
        $query  = $this->db->query($sql);
        $return = $query->result();
        return $return;
    }

    public function get_header($id)
    {
        $sql    = "SELECT * FROM token_headers WHERE id = ?";
        $query  = $this->db->query($sql,$id);
        $return = $query->row();
        return $return;
    }

    public function insert_token($params) {
		$this->db->insert('token_lines', $params);
		$id = $this->db->insert_id();
		return $id;
	}

	public function validate_token($params,$token_header_id) {

		$sql    = "SELECT * FROM token_lines WHERE combination1 = ? AND combination2 = ? AND combination3 = ? AND header_id = " . $token_header_id;
        $query  = $this->db->query($sql,$params);
        $return = $query->result();
        return $return;
	}

    public function validate_serial_number($params) {

        $sql    = "SELECT * FROM token_lines WHERE serial_number = ?";
        $query  = $this->db->query($sql,$params);
        $return = $query->result();
        return $return;
    }

    public function get_current()
    {
        $sql = "SELECT * FROM token_headers WHERE date_drawn IS NULL ORDER BY batch_id ASC";
        $query  = $this->db->query($sql);
        $return = $query->result();
        return $return;
    }

    public function get_current_by_batch_id($batch_id)
    {
        $sql = "SELECT * FROM token_headers WHERE batch_id = ? AND date_drawn IS NULL ORDER BY batch_id ASC";
        $query  = $this->db->query($sql,$batch_id);
        $return = $query->row();
        return $return;
    }

    public function end_game($header_id) {

        $sql            = "SELECT * FROM token_headers WHERE id = ?";
        $query          = $this->db->query($sql,$header_id);
        $game_details   = $query->row();

        $this->db->where('id', $header_id);
        $result = $this->db->update('token_headers', array('date_drawn' => date('Y-m-d H:i:s')));

        $insert_params = array(
            'batch_id' => $game_details->batch_id,
            'prize'    => $game_details->prize,
            'price'    => $game_details->price
        );

        $this->db->insert('token_headers', $insert_params);
        $id = $this->db->insert_id();
        return $id;
    }

    public function get_raffle_by_winner_combination($params)
    {
        $sql    = "SELECT * FROM token_lines WHERE header_id = ? AND combination1 = ? AND combination2 = ? AND combination3 = ? ";
        $query  = $this->db->query($sql,$params);
        $return = $query->row();
        return $return;
    }

    public function update_header($id, $params) {
        $this->db->where('id', $id);
        $result = $this->db->update('token_headers', $params);
        return $result;
    }

    /*public function add_winner_money($account_id, $header_id) {
    	$sql = "SELECT * FROM token_headers WHERE id = ?";
        $query        = $this->db->query($sql,$header_id);
        $game_details = $query->row();

    	$sql = "SELECT * FROM money WHERE account_id = ?";
        $query        = $this->db->query($sql,$account_id);
        $money_details = $query->row();

        $sql = "UPDATE money WHERE account_id = ? ";
        $this->db->where('account_id', $account_id);
        $result = $this->db->update('money', array('cfc_exclusive' => $money_details->cfc_exclusive + $game_details->prize));
        return $result;
    }*/

    public function new_referral_winners($params)
    {
        $this->db->insert('winner_referral', $params);
        $id = $this->db->insert_id();
        return $id;
    }

    public function get_token_gaming_details($account_id) {

        $sql = "SELECT 
                m.account_id,
                SUM(COALESCE(table1.total_price,0)) total_price,
                (m.total_bonus - m.withdrawn_bonus) - (SUM(COALESCE(table1.total_price,0))) available_rewards
                FROM 
                money m 
                LEFT JOIN 
                (
                SELECT 
                th.batch_id, 
                tl.account_id,
                count(*) total_entry,
                count(*) * th.price total_price
                FROM token_headers th 
                LEFT JOIN token_lines tl 
                on th.id = tl.header_id
                WHERE tl.account_id = 1
                GROUP BY th.batch_id,tl.account_id) table1
                ON table1.account_id = m.account_id
                WHERE m.account_id = ?";

        $query  = $this->db->query($sql,$account_id);
        $return = $query->row();
        return $return;
    }

    public function add_consolation_winner($params)
    {
        $sql = "UPDATE money JOIN token_lines ON money.account_id = token_lines.account_id SET cfc_exclusive = (cfc_exclusive + ?) WHERE header_id = ? AND combination1 = ? AND combination2 = ? AND combination3 = ?";
        $result = $this->db->query($sql, $params);

        if($result) {
            array_shift($params);
            $sql_account = "SELECT * FROM token_lines WHERE header_id = ? AND combination1 = ? AND combination2 = ? AND combination3 = ?";
            $query       = $this->db->query($sql_account,$params);
            if($query->row()) $result = $query->row()->account_id;
        }

        return $result;
    }

    public function add_free_token($params)
    {
        $sql = "UPDATE money SET free_token = (free_token + ?) WHERE account_id = ?";
        $result = $this->db->query($sql, $params);
        return $result;
    }

    public function test_cron_jobs() {

        $sql = "UPDATE accounts SET middle_name = 'bbb' WHERE id = 1";
        $result = $this->db->query($sql);
        return $result;
    }


} 