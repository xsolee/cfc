<?php 
class Money_model extends CI_Model {
	public function __construct() {
		parent::__construct();
		date_default_timezone_set('Asia/Manila');
	}
	public function new_account($data) {
		$this->db->insert('money', $data);
		$id = $this->db->insert_id();
		return $id;
	}
	public function get_money_details($account_id) {
		$sql = 'SELECT * FROM money WHERE account_id = ?';
		$query  = $this->db->query($sql,$account_id);
		$return = $query->row();
		return $return;
	}
	/*public function get_total_crossline($account_id) {
		$sql = 'SELECT (signup_bonus + direct_referral + pairing_bonus + oneleg_bonus + team_bonus + placement_bonus) AS total FROM money WHERE account_id = ?';
		$query  = $this->db->query($sql,$account_id);
		$return = $query->row();
		return $return;
	}*/
	public function update_money($account_id, $data) {
		$this->db->where('account_id', $account_id);
		$result = $this->db->update('money', $data);
		return $result;
	}
	public function update_affiliate_share_total_income_per_day($account_id) {

		

		//$sql = "UPDATE affiliate_shares SET total_income_per_day = (daily_profit*FLOOR(ABS(TIMESTAMPDIFF(SECOND,CONVERT_TZ(NOW(),'-05:00','+08:00'),created_date))  / 86400)) WHERE account_id = ?";

		$sql = "UPDATE affiliate_shares SET total_income_per_day = (daily_profit*(DATEDIFF(CONVERT_TZ(NOW(),'-05:00','+08:00'),created_date)) ) WHERE account_id = ?";
		//$sql = "UPDATE affiliate_shares SET total_income_per_day = daily_profit*DATEDIFF(CONVERT_TZ(NOW(),'-07:00','+08:00'),CONVERT_TZ(created_date,'-07:00','+08:00')) WHERE account_id = ?";
		$result = $this->db->query($sql, $account_id);
		return $result;
	}
	public function update_total_affiliate_share($account_id) {
		// $sql = 'UPDATE money SET money.total_affiliate_share = affiliate_shares.total FROM money INNER JOIN (SELECT SUM(val) AS total FROM affiliate_shares WHERE affiliate_shares.account_id = ? AND affiliate_shares.due_date < CURRENT_DATE() GROUP BY  affiliate_shares.account_id ) affiliate_shares ON money.account_id = affiliate_shares.account_id';
		//$sql = 'UPDATE money INNER JOIN (SELECT account_id, SUM(total_income) AS total FROM affiliate_shares WHERE due_date < CURRENT_DATE() GROUP BY account_id) affiliate_shares ON money.account_id = affiliate_shares.account_id SET money.total_affiliate_share = affiliate_shares.total WHERE affiliate_shares.account_id = ?';
		$sql = 'UPDATE money INNER JOIN (SELECT account_id, SUM(total_income_per_day) AS total FROM affiliate_shares GROUP BY account_id) affiliate_shares ON money.account_id = affiliate_shares.account_id SET money.total_affiliate_share = affiliate_shares.total WHERE affiliate_shares.account_id = ?';
		$result = $this->db->query($sql, $account_id);
		return $result;
	}
	public function update_total($account_id) {
		$sql = 'UPDATE money SET total_bonus = (signup_bonus + direct_referral + pairing_bonus + total_affiliate_share_unilevel + received_rewards + leadership_rewards) WHERE account_id = ?';
		$result = $this->db->query($sql, $account_id);
		return $result;
	}
	public function update_current($account_id) {
		$sql = 'UPDATE money SET current_bonus = (total_bonus - (withdrawn_bonus + transfered_rewards)) WHERE account_id = ?';
		$result = $this->db->query($sql, $account_id);
		return $result;
	}
	public function add_referral_bonus($account_id) {
		$sql = 'UPDATE money SET direct_referral = (direct_referral + 10) WHERE account_id = ?';
		$result = $this->db->query($sql, $account_id);
		return $result;
	}
	public function add_oneleg_bonus($account_id) {
		$sql = 'UPDATE money SET oneleg_bonus = (oneleg_bonus + 50) WHERE account_id = ?';
		$result = $this->db->query($sql, $account_id);
		return $result;
	}
	public function reset_placement_bonus() {
		$sql = 'UPDATE money SET placement_bonus = 0';
		$result = $this->db->query($sql);
		return $result;
	}
	public function add_placement_bonus($params) {
		$sql = 'UPDATE money SET placement_bonus = (placement_bonus + ?) WHERE account_id = ?';
		$result = $this->db->query($sql, $params);
		return $result;
	}
	public function update_placement_bonus($params) {
		$sql = 'UPDATE money SET placement_bonus = ? WHERE account_id = ?';
		$result = $this->db->query($sql, $params);
		return $result;
	}
	public function add_pairing_bonus($params) {
		$sql = 'UPDATE money SET pairing_bonus = (pairing_bonus + ?) WHERE account_id = ?';
		$result = $this->db->query($sql, $params);
		return $result;
	}
	public function add_crossline_bonus($params) { 
		$sql = 'UPDATE money SET crossline_bonus = (crossline_bonus + ?) WHERE account_id = ?';
		$result = $this->db->query($sql, $params);
		return $result;
	}
	public function add_rbb_bonus($params) {
		$sql = 'UPDATE money SET rbb_bonus = (rbb_bonus + ?) WHERE account_id = ?';
		$result = $this->db->query($sql, $params);
		return $result;
	}
	public function add_affiliate_bonus($params) {
		$sql = 'UPDATE money SET affiliate_bonus = (affiliate_bonus + ?) WHERE account_id = ?';
		$result = $this->db->query($sql, $params);
		return $result;
	}
	public function update_prev_pb($account_id, $date_update_pb) {
		$sql = 'UPDATE money SET prev_pairing_bonus = pairing_bonus, date_updated_pb = ? WHERE account_id = ?';
		$result = $this->db->query($sql, array($date_update_pb, $account_id));
		return $result;
	}
	public function withdraw_bonus($params) {
		$sql = 'UPDATE money SET withdrawn_bonus = (withdrawn_bonus + ?), maintenance = (maintenance + ?) WHERE account_id = ?';
		$result = $this->db->query($sql, $params);
		return $result;
	}
	public function withdraw_affiliate_share($params) {
		$sql = 'UPDATE money SET withdrawn_affiliate_share = (withdrawn_affiliate_share + ?), maintenance = (maintenance + ?) WHERE account_id = ?';
		$result = $this->db->query($sql, $params);
		return $result;
	}
	public function withdraw_affiliate_share_2($params) {
		$sql = 'UPDATE money SET withdrawn_affiliate_share_2 = (withdrawn_affiliate_share_2 + ?), maintenance = (maintenance + ?) WHERE account_id = ?';
		$result = $this->db->query($sql, $params);
		return $result;
	}
	public function withdraw_forex_referral($params) {
		$sql = 'UPDATE money SET withdrawn_forex_referral = (withdrawn_forex_referral + ?), maintenance = (maintenance + ?) WHERE account_id = ?';
		$result = $this->db->query($sql, $params);
		return $result;
	}
	
	public function withdraw_affiliate_share_received($params) {
		$sql = 'UPDATE money SET withdrawn_affiliate_share_received = (withdrawn_affiliate_share_received + ?), maintenance = (maintenance + ?) WHERE account_id = ?';
		$result = $this->db->query($sql, $params);
		return $result;
	}
	public function remove_money($account_id) {
		$this->db->where('account_id', $account_id);
		$result = $this->db->delete('money');
		return $result;
	}
	public function get_account_from_id($account_id) {
		$sql = 'SELECT * FROM accounts WHERE account_id = ?';
		$query  = $this->db->query($sql,$account_id);
		$return = $query->row();
		return $return;
	}
	public function add_affiliate_share_unilevel($no_of_share, $sponsor_ID, $account_id) {
		$money_sql = 'UPDATE money SET total_affiliate_share_unilevel = (total_affiliate_share_unilevel + ?) WHERE account_id = ?';
		$result = $this->db->query($money_sql, array(2*$no_of_share, $sponsor_ID));
		$this->add_logs(array('account_id'  => $sponsor_ID, 'amount' => 2*$no_of_share, 'description' => "Received crowd funding unilevel", 'date' => date('Y-m-d H:i:s') ));
		
		$unilevel_col = "INSERT INTO affiliate_shares_unilevel (account_id, no_of_share, level1";
		$unilevel_val = ") VALUES (".$account_id.", ".$no_of_share.", ".$no_of_share*2;
        $account = $this->get_account_from_id($sponsor_ID);

		for ($i=2; $i <= 10; $i++) { 
			if($account->sponsor_ID){
				$unilevel_col .= ", level".$i;
				$result = $this->db->query($money_sql, array(2*$no_of_share, $account->sponsor_ID));
				$this->add_logs(array('account_id'  => $account->sponsor_ID, 'amount' => 2*$no_of_share, 'description' => "Received crowd funding unilevel", 'date' => date('Y-m-d H:i:s') ));
				$unilevel_val .= ", ".$no_of_share*2;
				/*switch ($i) {
					case $i == 2 || $i == 3 || $i == 4 || $i == 5 || $i == 14:
						$result = $this->db->query($money_sql, array(40*$no_of_share, $account->sponsor_ID));
						$unilevel_val .= ", ".$no_of_share*40;
						break;
					case $i == 6 || $i == 7 || $i == 8 || $i == 9 || $i == 10:
						$result = $this->db->query($money_sql, array(30*$no_of_share, $account->sponsor_ID));
						$unilevel_val .= ", ".$no_of_share*30;
						break;
					case $i == 11 || $i == 12 || $i == 13:
						$result = $this->db->query($money_sql, array(20*$no_of_share, $account->sponsor_ID));
						$unilevel_val .= ", ".$no_of_share*20;
						break;
					case $i == 15:
						$result = $this->db->query($money_sql, array(50*$no_of_share, $account->sponsor_ID));
						$unilevel_val .= ", ".$no_of_share*50;
						break;
				}*/
        		$account = $this->get_account_from_id($account->sponsor_ID);
			} else {
				break;
			}
		}
		$result = $this->db->query($unilevel_col.$unilevel_val.")");
		return $result;
	}
	public function withdraw_affiliate_share_unilevel($params) {
		$sql = 'UPDATE money SET withdrawn_affiliate_share_unilevel = (withdrawn_affiliate_share_unilevel + ?) WHERE account_id = ?';
		$result = $this->db->query($sql, $params);
		return $result;
	}

    public function update_leadership_rewards($params) {

        $sql    = "UPDATE money SET leadership_rewards = (leadership_rewards + ?) WHERE account_id = ?";
        $result = $this->db->query($sql, $params);
        return $result;
    }
    
	public function add_logs($params) {
		$this->db->insert('money_logs', $params);
		$id = $this->db->insert_id();
		return $id;
	}
	public function get_logs($params, $date = NULL) {

		$where = "";
		if($date) {
			$where .= " AND date >= " . "'" . $date . "'";
		}

		$sql = 'SELECT * FROM money_logs WHERE account_id = ? '.$where.' ORDER BY date DESC';

		$query  = $this->db->query($sql,$params);
		$return = $query->result();
		return $return;
	}
	public function add_cfc_exclusive($params) {
		$sql = 'UPDATE money SET cfc_exclusive = (cfc_exclusive + ?), cfc_exclusive_referral = (cfc_exclusive_referral + ?) WHERE account_id = ?';
		$result = $this->db->query($sql, $params);
		return $result;
	}

	public function validate_cfc_exclusive_withdrawal_limit_daily($account_id) {

    	$sql = "SELECT SUM(COALESCE(debit,0)) debit FROM money_logs WHERE account_id = ? AND DATE_FORMAT(date,'%Y-%m-%d') = ? AND description = 'Withdrawn CFC Exclusive'";
    	$query  = $this->db->query($sql,array($account_id,date('Y-m-d')));
        $return = $query->row();

        return $return;
    }

    public function withdraw_cfc_exclusive($params) {
		$sql = 'UPDATE money SET withdrawn_cfc_exclusive = (withdrawn_cfc_exclusive + ?), maintenance = (maintenance + ?) WHERE account_id = ?';
		$result = $this->db->query($sql, $params);
		return $result;
	}

	public function received_rewards($params) {
		$sql = 'UPDATE money SET received_rewards = (received_rewards + ?) WHERE account_id = ?';
		$result = $this->db->query($sql, $params);
		return $result;
	}

	public function transfer_rewards($params) {
		$sql = 'UPDATE money SET transfered_rewards = (transfered_rewards + ?), maintenance = (maintenance + ?) WHERE account_id = ?';
		$result = $this->db->query($sql, $params);
		return $result;
	}

	public function received_cfc_exclusive($params) {
		$sql = 'UPDATE money SET received_cfc_exclusive = (received_cfc_exclusive + ?) WHERE account_id = ?';
		$result = $this->db->query($sql, $params);
		return $result;
	}

	public function transfer_cfc_exclusive($params) {
		$sql = 'UPDATE money SET transfered_cfc_exclusive = (transfered_cfc_exclusive + ?), maintenance = (maintenance + ?) WHERE account_id = ?';
		$result = $this->db->query($sql, $params);
		return $result;
	}

    public function withdraw_free_tokens($params) {
		$sql = 'UPDATE money SET free_token = (free_token - ?) WHERE account_id = ?';
		$result = $this->db->query($sql, $params);
		return $result;
	}

	public function received_affiliate_shares($params) {
		$sql = 'UPDATE money SET received_affiliate_shares = (received_affiliate_shares + ?) WHERE account_id = ?';
		$result = $this->db->query($sql, $params);
		return $result;
	}

	public function transfer_affiliate_shares($params) {
		$sql = 'UPDATE money SET transfered_affiliate_shares = (transfered_affiliate_shares + ?), maintenance = (maintenance + ?) WHERE account_id = ?';
		$result = $this->db->query($sql, $params);
		return $result;
	}

	public function received_affiliate_shares_2($params) {
		$sql = 'UPDATE money SET received_affiliate_shares_2 = (received_affiliate_shares_2 + ?) WHERE account_id = ?';
		$result = $this->db->query($sql, $params);
		return $result;
	}

	public function transfer_affiliate_shares_2($params) {
		$sql = 'UPDATE money SET transfered_affiliate_shares_2 = (transfered_affiliate_shares_2 + ?), maintenance = (maintenance + ?) WHERE account_id = ?';
		$result = $this->db->query($sql, $params);
		return $result;
	}

	public function received_forex_referral($params) {
		$sql = 'UPDATE money SET received_forex_referral = (received_forex_referral + ?) WHERE account_id = ?';
		$result = $this->db->query($sql, $params);
		return $result;
	}

	public function transfer_forex_referral($params) {
		$sql = 'UPDATE money SET transferred_forex_referral = (transferred_forex_referral + ?), maintenance = (maintenance + ?) WHERE account_id = ?';
		$result = $this->db->query($sql, $params);
		return $result;
	}

	public function get_cfc_coins_rate() {
		$sql    = 'SELECT * FROM cfc_coins_rate WHERE id=1';
		$query  = $this->db->query($sql);
		$return = $query->row();
		return $return;
	}

	public function purchase_cfc_coins($account_id, $cfc_coins, $price, $from, $rate) {
		$sql = "UPDATE money SET purchased_cfc_coins = (purchased_cfc_coins + ?), ".$from." = (".$from." + ?) WHERE account_id = ?";
		$result = $this->db->query($sql, array($cfc_coins, $price, $account_id));

		$this->db->insert('cfc_coins_purchases', array('account_id' => $account_id,'amount' => $cfc_coins, 'rate' => $rate, 'created_date' => date('Y-m-d H:i:s')));
		return $result;
	}

	public function transfer_cfc_coins($account_id, $cfc_coins, $receiver_id) {
		$sql = "UPDATE money SET transferred_cfc_coins = (transferred_cfc_coins + ?) WHERE account_id = ?";
		$result = $this->db->query($sql, array($cfc_coins, $account_id));

		$sql = "UPDATE money SET received_cfc_coins = (received_cfc_coins + ?) WHERE account_id = ?";
		$result = $this->db->query($sql, array($cfc_coins, $receiver_id));
		return $result;
	}

	public function update_cfc_coins_rate($params) {
		$sql = "UPDATE cfc_coins_rate SET rate = ? WHERE id=1";
		$result = $this->db->query($sql, $params);
		return $result;
	}

	public function get_cfc_coins_purchases() {
		$sql = "SELECT DATE_FORMAT(created_date,'%Y-%m-%d') AS 'date', SUM(amount) AS 'value' FROM cfc_coins_purchases GROUP BY DATE_FORMAT(created_date,'%Y-%m-%d') ORDER BY 'date'";
		$query  = $this->db->query($sql);
		return $query->result();
	}

	public function add_forex_referral($amount, $sponsor_ID, $sponsored_username ) {
		$sql = 'UPDATE money SET forex_referral = (forex_referral + ?) WHERE account_id = ?';
		$result = $this->db->query($sql, array( $amount, $sponsor_ID ));

		$this->add_logs(array('account_id' => $sponsor_ID, 'amount' => $amount, 'description' => "Received forex referral (".$sponsored_username.")", 'date' => date('Y-m-d H:i:s') ));

		return $result;
	}

	public function get_forex_referral_rate() {
		$sql    = 'SELECT * FROM forex_referral_rate ORDER BY id ASC';
		$query  = $this->db->query($sql);
		return $query->result();
	}
}