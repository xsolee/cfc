<?php 
class Transactions_model extends CI_Model {
	public function __construct() {
		parent::__construct();
		date_default_timezone_set('Asia/Manila');
	}
	public function get_transactions($account_id) {
		$sql = 'SELECT * FROM transactions WHERE account_id = ?';
		$query  = $this->db->query($sql,$account_id);
		$return = $query->result();
		return $return;
	}
	public function get_all_transactions() {
		$sql = 'SELECT * FROM transactions t LEFT JOIN (SELECT bank_id,bank_name,account_name, account_number,account_type FROM banks) AS b ON t.bank_id = b.bank_id';
		$query  = $this->db->query($sql);
		$return = $query->result();
		return $return;
	}
	public function add_transaction($data) {
		$this->db->insert('transactions', $data);
		$id = $this->db->insert_id();
		return $id;
	}
    
    public function get_bought_pincodes($table, $params)
    {
        $sql = "SELECT 
                p.*,
                a.username,
                a.first_name,
                a.last_name
                FROM ".$table." p 
                LEFT JOIN accounts a
                on p.account_id = a.account_id 
                WHERE bought_by = ? OR transfer_to = ?";
        $query  = $this->db->query($sql,$params);
        $return = $query->result();

        return $return;
    }
    
	public function save_pins($params) {
		$this->db->insert('register_pins', $params);
		$id = $this->db->insert_id();
		return $id;
	}

    public function save_buy_pincode_transaction($params, $column)
    {
        $this->db->insert('transactions', $params);
        $id = $this->db->insert_id();
        
        $sql = "UPDATE money SET ".$column." = ".$column." + ? WHERE account_id = ?";
        $this->db->query($sql,array($params['amount'],$params['account_id']));
        return true;
    }
}