<?php 
class Product_purchases_model extends CI_Model {
	public function __construct() {
		parent::__construct();
		date_default_timezone_set('Asia/Manila');
	}

	public function get_purchases($account_id) {
		$sql    = 'SELECT * FROM product_purchases WHERE account_id = ?';
		$query  = $this->db->query($sql,$account_id);
		$return = $query->result();
		return $return;
	}
	public function get_all_purchases() {
		$sql    = 'SELECT * FROM product_purchases';
		$query  = $this->db->query($sql);
		$return = $query->result();
		return $return;
	}
	public function add_purchase($params) {
		$this->db->insert('product_purchases', $params);
		$id = $this->db->insert_id();
		return $id;
	}
}