<?php 
class Affiliate_shares_model extends CI_Model {
	public function __construct() {
		parent::__construct();
		date_default_timezone_set('Asia/Manila');
	}

	public function check_PIN($params) {
		$sql    = 'SELECT * FROM affiliate_shares_pin WHERE pin = ?';
		$query  = $this->db->query($sql,$params);
		$return = $query->row();
		return $return;
	}
	public function check_pin_unused($params) {
		$sql    = 'SELECT * FROM affiliate_shares_pin WHERE pin = ? AND no_of_share = ? AND used = 0';
		$query  = $this->db->query($sql,$params);
		$return = $query->row();
		return $return;
	}
	public function get_all_PINs() {
		$sql    = 'SELECT affiliate_shares_pin.*, accounts.username, accounts.first_name, accounts.last_name FROM affiliate_shares_pin LEFT JOIN accounts ON affiliate_shares_pin.account_id = accounts.account_id';
		$query  = $this->db->query($sql);
		$return = $query->result();
		return $return;
	}
	public function get_all_unused_PINs() {
		$sql    = 'SELECT pin, used FROM affiliate_shares_pin WHERE used = false';
		$query  = $this->db->query($sql);
		$return = $query->result();
		return $return;
	}
	public function use_PIN($params) {
		$sql    = 'UPDATE affiliate_shares_pin SET used = 1, account_id = ?, date_used = ? WHERE pin = ?';
		$result = $this->db->query($sql, $params);
		return $result;
	}
	public function save_pin($params) {
		$this->db->insert('affiliate_shares_pin', $params);
		$id = $this->db->insert_id();
		return $id;
	}

	public function save_affiliate_shares($params) {
		$this->db->insert('affiliate_shares', $params);
		$id = $this->db->insert_id();
		return $id;
	}

	public function get_affiliate_shares($params) {
		$sql    = 'SELECT
					id,
					account_id,
					pin,
					no_of_share,
					shares_amount,
					daily_profit,
					total_income,
					((DATEDIFF(?,DATE_FORMAT(created_date,"%Y-%m-%d"))) * daily_profit) present_income,
					total_income_per_day,
					due_date,
					invest_type,
					created_date
					FROM affiliate_shares WHERE account_id = ?';
		$query  = $this->db->query($sql,array(date('Y-m-d'), $params));
		$return = $query->result();
		return $return;
	}

	public function update_affiliate_shares_pin($params) {
		$sql    = 'UPDATE affiliate_shares_pin SET used = 1, date_used = ?, account_id = ? WHERE pin = ?';
		$result = $this->db->query($sql, $params);
		return true;
	}

	public function get_active_affiliate_shares($account_id) {
		$sql    = 'SELECT * FROM affiliate_shares WHERE account_id = ? AND due_date > CURRENT_DATE()';
		$query  = $this->db->query($sql,$account_id);
		$return = $query->result();
		return $return;
	}

	public function get_affiliate_shares_for_encashment($account_id) {
		$sql    = 'SELECT * FROM affiliate_shares WHERE account_id = ? AND due_date < CURRENT_DATE()';
		$query  = $this->db->query($sql,$account_id);
		$return = $query->result();
		return $return;
	}
	public function get_total_matured_affiliate_shares($account_id) {
		$sql    = 'SELECT (0+SUM(total_income)) AS total FROM affiliate_shares WHERE account_id = ? AND due_date < CURRENT_DATE() GROUP BY account_id';
		$query  = $this->db->query($sql,$account_id);
		$return = $query->row();
		return $return;
	}

	public function validate_affiliate_shares_amount_exceeded($account_id) {
		$sql    = 'SELECT 
					SUM(shares_amount) total_shares_amount 
					FROM affiliate_shares WHERE account_id = ?';
		$query  = $this->db->query($sql,$account_id);
		$return = $query->row();
		return ($return)? $return->total_shares_amount : 0 ;
	}

	public function get_account_for_reinvest() {
		$sql    = 'SELECT 
					account_id,
					SUM(total_income_per_day) total_income_per_day
					FROM affiliate_shares 
					WHERE due_date > CURRENT_DATE()
					GROUP BY account_id
					HAVING total_income_per_day >= 100';
		$query  = $this->db->query($sql);
		$return = $query->result();
		return $return;
	}

	public function get_account_for_reinvest_by_account_id($account_id) {
		$sql    = 'SELECT 
					account_id,
					SUM(total_income_per_day) total_income_per_day
					FROM affiliate_shares 
					WHERE due_date > CURRENT_DATE()
					AND account_id = ?
					GROUP BY account_id';
		$query  = $this->db->query($sql,$account_id);
		$return = $query->row();
		return $return;
	}

	public function get_affiliate_shares_for_reinvest($account_id) {
		$sql    = 'SELECT id,(total_income_per_day - redeemed) total_income_per_day  FROM affiliate_shares WHERE (total_income_per_day - redeemed) >= 100 AND due_date > CURRENT_DATE() AND account_id = ?';
		$query  = $this->db->query($sql,$account_id);
		$return = $query->result();
		return $return;
	}

	public function update_affiliate_shares($params,$id) {

		$this->db->where('id', $id);
		$this->db->update('affiliate_shares', $params); 

		return true;
	}

	public function sample() {


		// (daily_profit*   (DATEDIFF(CONVERT_TZ(NOW(),'-05:00','+08:00'),created_date) -1)) total_income,
		// 		FLOOR(ABS(TIMESTAMPDIFF(SECOND,CONVERT_TZ(NOW(),'-05:00','+08:00'),created_date))  / 86400) TIMESTAMPDIFF,
		// 		DATEDIFF(CONVERT_TZ(NOW(),'-05:00','+08:00'),created_date) DATE_DIFF,
		// 		CONVERT_TZ(NOW(),'-05:00','+08:00') NOW_CONVERT,
		// 		created_date,
		$sql = "SELECT 
				(daily_profit*(DATEDIFF(CONVERT_TZ(NOW(),'-07:00','+08:00'),created_date)) ) OLD_TOTAL_INCOME,
				(DATEDIFF(CONVERT_TZ(NOW(),'-07:00','+08:00'),created_date)) OLD_DATE_DIFF,
				created_date,
				CONVERT_TZ(NOW(),'-07:00','+08:00') NOW_CONVERT
				from  affiliate_shares WHERE account_id = 1";

		$query  = $this->db->query($sql);
		$return = $query->result();
		return $return;
	}
    public function update_pin($id, $params) {
        $this->db->where('id', $id);
        $result = $this->db->update('affiliate_shares_pin', $params);
        return $result;
    }
}