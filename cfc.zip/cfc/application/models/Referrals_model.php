<?php 

class Referrals_model extends CI_Model {

	public function __construct() {
		parent::__construct();
	}

	public function add_referral($data) {
		$this->db->insert('direct_referrals', $data);
		$id = $this->db->insert_id();

		return $id;
	}
}