<?php 
class Register_pins_model extends CI_Model {
	public function __construct() {
		parent::__construct();
		date_default_timezone_set('Asia/Manila');
	}
	public function new_PIN($data) {
		$pin1 = rand(0, 100000);
		$pin2 = rand(0, 100000);
		$this->db->insert('register_pins', array('PIN1' => $pin1, 'PIN2' => $pin2 ));
		$id = $this->db->insert_id();
		return $id;
	}
	public function check_PIN($params) {
		$sql    = 'SELECT * FROM register_pins WHERE PIN1 = ? AND PIN2 = ? AND used = 0';
		$query  = $this->db->query($sql,$params);
		$return = $query->row();
		return $return;
	}
	public function get_all_PINs() {
		$sql    = 'SELECT register_pins.*, accounts.username, accounts.first_name, accounts.last_name FROM register_pins LEFT JOIN accounts ON register_pins.account_id = accounts.account_id';
		$query  = $this->db->query($sql);
		$return = $query->result();
		return $return;
	}
	public function get_all_unused_PINs() {
		$sql    = 'SELECT PIN1, PIN2, used FROM register_pins WHERE used = false';
		$query  = $this->db->query($sql);
		$return = $query->result();
		return $return;
	}
	public function use_PIN($params) {
		$sql    = 'UPDATE register_pins SET used = 1, account_id = ?, date_used = ? WHERE PIN1 = ? AND PIN2 = ?';
		$result = $this->db->query($sql, $params);
		return $result;
	}
	public function save_pins($params) {
		$this->db->insert('register_pins', $params);
		$id = $this->db->insert_id();
		return $id;
	}
	public function validate_pin_if_exist($params) {
		$sql    = 'SELECT * FROM register_pins WHERE PIN1 = ? AND PIN2 = ?';
		$query  = $this->db->query($sql,$params);
		$return = $query->row();
		return $return;
	}
    public function update_pin($id, $params) {
        $this->db->where('PIN_id', $id);
        $result = $this->db->update('register_pins', $params);
        return $result;
    }

    public function pin_transfer_logs($params) {
        $this->db->insert('pin_transfer_logs', $params);
        $id = $this->db->insert_id();
        return $id;
    }
}