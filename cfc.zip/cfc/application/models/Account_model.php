<?php 
class Account_Model extends CI_Model {
	public function __construct() {
		parent::__construct();
	}
	public function get_all_account() {
		$sql = 'SELECT * FROM accounts';
		$query  = $this->db->query($sql);
		$return = $query->result();
		return $return;
	}
	public function get_account($username) {
		$sql = 'SELECT * FROM accounts WHERE username = ?';
		$query  = $this->db->query($sql,$username);
		$return = $query->row();
		return $return;
	}
	public function get_subaccounts($params, $middle_name = NULL) {
		$sql = 'SELECT * FROM accounts WHERE last_name = ? and first_name = ?';
		if($middle_name) $sql .= ' and middle_name = ?';
		else $sql .= ' and middle_name IS ?';
		$query  = $this->db->query($sql,$params);
		$return = $query->result();
		return $return;
	}
	public function check_account($params) {
		$sql = 'SELECT * FROM accounts WHERE username = ? and password = ?';
		$query  = $this->db->query($sql,$params);
		$return = $query->row();
		return $return;
	}
	public function check_transfer_password($params) {
		$sql = 'SELECT * FROM accounts WHERE account_id = ? and transfer_password = ?';
		$query  = $this->db->query($sql,$params);
		$return = $query->row();
		return $return;
	}
	public function get_account_from_id($account_id) {
		$sql = 'SELECT * FROM accounts WHERE account_id = ?';
		$query  = $this->db->query($sql,$account_id);
		$return = $query->row();
		return $return;
	}
	public function get_account_from_email($email) {
		$sql = 'SELECT * FROM accounts WHERE email_address = ?';
		$query  = $this->db->query($sql,$email);
		$return = $query->row();
		return $return;
	}
	public function check_mobile($mobile_number) {
		$sql = 'SELECT * FROM accounts WHERE mobile_number = ?';
		$query  = $this->db->query($sql,$mobile_number);
		$return = $query->row();
		return $return;
	}
	public function check_left($account_id) {
		$sql = 'SELECT * FROM accounts WHERE account_id = ?';
		$query  = $this->db->query($sql,$account_id);
		$return = $query->row();
		return $return;
	}
	public function insert_new_account($data) {
		$this->db->insert('accounts', $data);
		$id = $this->db->insert_id();
		return $id;
	}
	public function update_account($id, $data) {
		$this->db->where('account_id', $id);
		$result = $this->db->update('accounts', $data);
		return $result;
	}
	public function update_accounts($ids, $data) {
		$this->db->where_in('account_id', $ids);
		$result = $this->db->update('accounts', $data);
		return $result;
	}
	public function set_left($account_id, $left_id) {
		$sql = 'UPDATE accounts SET left_id = ?, height_left = (height_left+1) WHERE account_id = ?';
		$result = $this->db->query($sql, array($left_id, $account_id));
		return $result;
	}
	public function set_right($account_id, $left_id) {
		$sql = 'UPDATE accounts SET right_id = ?, height_right = (height_right+1) WHERE account_id = ?';
		$result = $this->db->query($sql, array($left_id, $account_id));
		return $result;
	}
	public function add_points($position, $params) {
		if($position == "left"){ $sql = 'UPDATE accounts SET points_left = (points_left + ?) WHERE account_id = ?';}
		else { $sql = 'UPDATE accounts SET points_right = (points_right + ?) WHERE account_id = ?';}
		$result = $this->db->query($sql, $params);
		return $result;
	}
	public function get_tree() {
		$sql = "SELECT 
				account_id parent_id,
				left_id,
				right_id
				FROM accounts";
		$query  = $this->db->query($sql);
		$return = $query->result_array();
		return $return;
	}
	public function get_account_details($account_id) {
		$sql = 'SELECT * FROM accounts WHERE account_id = ?';
		$query  = $this->db->query($sql,$account_id);
		$return = $query->row();
		return $return;
	}

	public function get_sub_accounts($main_account_id)
	{
		$sql = 'SELECT * FROM subaccounts WHERE main_account_id = ?';
		$query  = $this->db->query($sql,$main_account_id);
		$return = $query->result();
		return $return;
	}

	public function get_sub_accounts_details($main_account_id)
	{
		$sql = 'SELECT subaccounts.*, accounts.username, accounts.placement_ID FROM subaccounts LEFT JOIN accounts ON subaccounts.sub_account_id=accounts.account_id WHERE subaccounts.main_account_id=?';
		$query  = $this->db->query($sql,$main_account_id);
		$return = $query->result();
		return $return;
	}

	public function update_sub_account_table($params) 
	{
		$this->db->insert('subaccounts', $params);
		$id = $this->db->insert_id();
		return $id;
	}

	public function get_sub_account_id($main_account_id)
	{
		$sql = 'SELECT COUNT(*) count FROM subaccounts WHERE main_account_id = ?';
		$query  = $this->db->query($sql,$main_account_id);
		$return = $query->row();
		return $return->count + 1;
	}

	public function get_main_account_id($account_id)
	{
		$sql = 'SELECT main_account_id FROM subaccounts WHERE sub_account_id = ?';
		$query  = $this->db->query($sql,$account_id);
		$return = $query->row();
		return $return;
	}
	public function get_sponsored_accounts($account_id) {
		$sql = 'SELECT direct_referrals.*, accounts.username, accounts.first_name, accounts.last_name FROM direct_referrals LEFT JOIN accounts ON direct_referrals.sponsored_id = accounts.account_id WHERE direct_referrals.sponsor_id = ?';
		$query  = $this->db->query($sql,$account_id);
		$return = $query->result();
		return $return;
	}
	public function get_all_sponsored_accounts() {
		$sql = 'SELECT dr.*, a.username AS sponsored_username, a.first_name AS sponsored_firstname, a.last_name AS sponsored_lastname, b.username AS sponsor_username, b.first_name AS sponsor_firstname, b.last_name AS sponsor_lastname FROM direct_referrals dr LEFT JOIN accounts a ON dr.sponsored_id = a.account_id LEFT JOIN accounts b ON dr.sponsor_id = b.account_id ';
		$query  = $this->db->query($sql);
		$return = $query->result();
		return $return;
	}
	public function get_sponsored_accounts_details($account_id) {
		$sql = 'SELECT * FROM direct_referrals LEFT JOIN accounts ON direct_referrals.sponsored_id = accounts.account_id WHERE direct_referrals.sponsor_id = ?';
		$query  = $this->db->query($sql,$account_id);
		$return = $query->result();
		return $return;
	}
	public function get_monthly_registered() {

		$return_data = [0,0,0,0,0,0,0,0,0,0,0,0];
		$sql = "SELECT
				DATE_FORMAT(date_created,'%m') month,
				COUNT(*) total_registered
				FROM accounts
				WHERE DATE_FORMAT(date_created,'%Y') = ?
				GROUP BY DATE_FORMAT(date_created,'%Y-%m')
				ORDER BY DATE_FORMAT(date_created,'%Y-%m')";
		$query  = $this->db->query($sql,date('Y'));
		$return = $query->result_array();

		foreach($return as $row) {
			$return_data[$row['month'] - 1] = $row['total_registered'];
		}
		return $return_data;
	}

    public function activate_account($id)
    {
        $this->db->where('id', $id);
        $this->db->update('accounts', array('activated' => 1, 'date_activated'=>date('Y-m-d H:i:s'))); 
        return true;
    }
    public function get_placement_by_id($account_id) {

        $sql = "SELECT
                CASE WHEN left_id = ?
                THEN 'Left'
                ELSE 'Right'    
                END
                placement
                FROM accounts WHERE left_id = ? OR right_id = ?";
        $query  = $this->db->query($sql,array($account_id,$account_id,$account_id));
        $return = $query->row();
        return $return;
    }
	public function get_direct_referrals($account_id) {
		$sql = 'SELECT a.username, a.account_id, a.activated, a.first_name, a.last_name, dr.date_created FROM direct_referrals dr LEFT JOIN accounts a ON dr.sponsored_id = a.account_id WHERE dr.sponsor_id = ?';
		$query  = $this->db->query($sql,$account_id);
		$return = $query->result();
		return $return;
	}

    public function get_last_level() {
        $sql    = "SELECT * FROM accounts ORDER BY level DESC";
        $query  = $this->db->query($sql);
        $return = $query->row();
        return $return->level;
    }

    public function get_activated_account_by_id($account_id) {
		$sql = 'SELECT * FROM accounts WHERE account_id = ? and activated = 1';
		$query  = $this->db->query($sql,$account_id);
		$return = $query->row();
		return $return;
	}
}