<?php 

class Banks_model extends CI_Model {

	public function __construct() {
		parent::__construct();
	}

	public function add_bank($data) {
		$this->db->insert('banks', $data);
		$id = $this->db->insert_id();
		return $id;
	}

	public function get_bank_account($bank_id) {
		$sql = 'SELECT * FROM banks WHERE bank_id = ?';
		$query  = $this->db->query($sql,$bank_id);
		$return = $query->row();
		return $return;
	}

	public function get_bank_accounts($account_id) {
		$sql = 'SELECT * FROM banks WHERE account_id = ?';
		$query  = $this->db->query($sql,$account_id);
		$return = $query->result();
		return $return;
	}

	public function get_all_bank_accounts() {
		$sql = 'SELECT * FROM banks';
		$query  = $this->db->query($sql);
		$return = $query->result();
		return $return;
	}

	public function update_bank($id, $data) {
		$this->db->where('bank_id', $id);
		$result = $this->db->update('banks', $data);
		return $result;
	}

	public function remove_bank($id) {
		$this->db->where('bank_id', $id);
		$result = $this->db->delete('banks');
		return $result;
	}

	public function get_bank_by_bank_name($bank_name) {
		$sql = 'SELECT * FROM banks WHERE bank_name = ? AND account_id = ?';
		$query  = $this->db->query($sql,array($bank_name,$this->session->userdata()['account_id']));
		$return = $query->result();
		return $return;
	}

	public function get_existing_bank($params) {
		$sql = 'SELECT * FROM banks WHERE bank_name = ? AND account_number = ? AND account_type = ?';
		$query  = $this->db->query($sql,$params);
		$return = $query->result();
		return $return;
	}
}