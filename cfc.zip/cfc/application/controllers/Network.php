<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Network extends CI_Controller {

	public function __construct() {
		parent::__construct();
		$this->load->library('session');
		if ( ! $this->session->userdata('user_id')) {redirect('account/login'); }
		$this->load->model(array('Account_model', 'Referrals_model'));
		date_default_timezone_set('Asia/Manila');
	}

	public function subaccount($message = null) {
		$data = array(
			'title'   => 'Add Account', 
			'content' => 'network/add_account',
			'message' => $message
		);

		$this->load->view('template/template',$data);
	}

	public function genealogy_list($message = null) {
		$account = $this->Account_model->get_account($this->session->userdata()['username']);
		$current = array("parent"=>"", "position"=>"", "user_id"=>$account->account_id, "name"=> $account->first_name." ".$account->last_name, "username"=>$account->username);
		$tree[0] = $current;
		$tree    = $this->get_downline($account, $tree, 0, 1);
		$data    = array(
			'title'    => 'Genealogy List', 
			'content'  => 'network/genealogy_list', 
			'tree' => $tree
		);

		$this->load->view('template/template',$data);
	}

	public function genealogy_tree($id=null) {
		if($id == null) $account = $this->Account_model->get_account($this->session->userdata()['username']);
		else $account = $this->Account_model->get_account_from_id($id);
		if(!$account) {
			echo "Not found";
			exit();
		}
		$current = array("user_id"=>$account->account_id, "name"=> $account->first_name." ".$account->last_name, "username"=>$account->username, "left_id"=>$account->left_id, "right_id"=>$account->right_id, "level"=>$account->level, "activated"=>$account->activated);
		$tree[0] = $current;

		$level = $tree[0]['level'];
		if($level-1 >=0 ) $children_id[$level-1] = array($account->account_id);
		$number = 0;
		for ($i=$level; $i < $level+5; $i++) { 
			if($i-1 < 0) $children_id[$i] = $this->find_children(array($account->account_id));
			else $children_id[$i] = $this->find_children($children_id[$i-1]);
			$tree = $this->add_children($tree, $children_id, $i, $number);
			$number = $number*2 + 1;
		}

		if($this->session->userdata()['user_id'] != $account->account_id){
			$parent_id = $account->placement_ID;
		} else {
			$parent_id = $account->account_id;
		}
		
		$data    = array(
			'title'   => 'Genealogy Tree', 
			'content' => 'network/genealogy_tree', 
			'tree'    => $tree,
			'parent_id'    => $account->placement_ID!=null?$account->placement_ID:1
		);

		$this->load->view('template/template',$data);
	}

	public function add_children($tree, $children_id, $level, $number) {
		for($i=0; $i<count($children_id[$level]); $i++){
			$child = $this->Account_model->get_account_from_id($children_id[$level][$i]);
			$child_data = null;
			if($child) {
				$child_data = array("user_id"=>$child->account_id, "name"=> $child->first_name." ".$child->last_name, "username"=>$child->username, "left_id"=>$child->left_id, "right_id"=>$child->right_id, "level"=>$child->level, "activated"=>$child->activated);
			}
			if($i%2 == 0){	//left
				$tree[($number*2)+1] = $child_data;
			} else if($i%2 == 1){	//right
				$tree[($number*2)+2] = $child_data;
				$number++;
			}
		}
		return $tree;
	}

	public function find_children($list) {
		$children_id = array();
		foreach ($list as $parent_id) {
			$parent = $this->Account_model->get_account_from_id($parent_id);
			if($parent) array_push($children_id, $parent->left_id, $parent->right_id);
			else array_push($children_id, null, null);
		}

		return $children_id;
	}

	public function get_downline($account, $tree, $parent, $tree_count) {
		if($account->left_id != null){
			$left = $this->Account_model->get_account_from_id($account->left_id);
			$tree[$tree_count] = array("parent"=>$parent, "position"=>"left", "user_id"=>$left->account_id, "name"=> $left->first_name." ".$left->last_name, "username"=>$left->username);
			$tree = $this->get_downline($left, $tree, $tree_count, $tree_count+1);
			$tree_count = count($tree);
		}
		if($account->right_id != null){
			$right = $this->Account_model->get_account_from_id($account->right_id);
			$tree[$tree_count] = array("parent"=>$parent, "position"=>"right", "user_id"=>$right->account_id, "name"=> $right->first_name." ".$right->last_name, "username"=>$right->username);
			$tree = $this->get_downline($right, $tree, $tree_count, $tree_count+1);
			$tree_count = count($tree);
		}
		return $tree;
	}

	public function direct_referrals()
	{
		$data = array(
			'title'     => 'Direct Referrals',
			'content'   => 'network/referral_graph_view',
			'referrals' => $this->Referrals_model->get_level1_by_account_id($this->session->userdata()['user_id'])
		);
		// echo '<pre>';
		// print_r($this->Referrals_model->get_level1_by_account_id($this->session->userdata()['user_id']));
		// exit();

		$this->load->view('template/template',$data);
	}

	public function forex_referrals()
	{
		$account = $this->Account_model->get_account_from_id($this->session->userdata('user_id'));
		if ( !$account->activated ) redirect('dashboard');
		$data = array(
			'title'               => 'Forex Referrals',
			'content'             => 'network/forex_referral_view',
			'has_forex_sponsor'   => $account->forex_sponsor_ID,
			'has_forex_placement' => $account->forex_placement_ID,
			'referrals'           => $this->Referrals_model->get_forex_level1($this->session->userdata()['user_id'])
		);

		$this->load->view('template/template',$data);
	}

	public function ajax_tree()
	{
		$parent = $_REQUEST["parent"];

		$data = array();

		/*$states = array(
		  	"success",
		  	"info",
		  	"danger",
		  	"warning"
		);*/

		if ($parent == "#") {
			$referrals = $this->Referrals_model->get_level1_by_account_id($this->session->userdata()['user_id']);
			foreach($referrals as $row) {
				$data[] = array(
					"id" => $row->level1_id,  
					"text" => $row->level1, 
					// "icon" => "fa fa-folder icon-lg kt-font-" . ($states[rand(0, 3)]),
					"children" => true, 
					"type" => "root"
				);
			}
		} else {
			$referrals = $this->Referrals_model->get_level1_by_account_id($parent);
			if($referrals){
				foreach($referrals as $row) {
					$data[] = array(
						"id" => $row->level1_id,  
						"text" => $row->level1, 
						// "icon" => ( rand(0, 3) == 2 ? "fa fa-file icon-lg" : "fa fa-folder icon-lg")." kt-font-" . ($states[rand(0, 3)]),
						"children" => true, 
					);
				}
			} else {
				$data[] = array(
					"id" => null, 
					"text" => "No referrals", 
					// "icon" => "fa fa-file fa-large kt-font-default",
					"state" => array("disabled" => true),
					"children" => false
				);
			}
		}

		header('Content-type: text/json');
		header('Content-type: application/json');
		header('Access-Control-Allow-Origin: *');
		echo json_encode($data);
	}

	public function forex_tree()
	{
		$parent = $_REQUEST["parent"];
		$data = array();

		if ($parent == "#") {
			$referrals = $this->Referrals_model->get_forex_level1($this->session->userdata()['user_id']);
			foreach($referrals as $row) {
				$data[] = array(
					"id" => $row->level1_id,  
					"text" => $row->level1, 
					"children" => true, 
					"type" => "root"
				);
			}
		} else {
			$referrals = $this->Referrals_model->get_forex_level1($parent);
			if($referrals){
				foreach($referrals as $row) {
					$data[] = array(
						"id" => $row->level1_id,  
						"text" => $row->level1, 
						"children" => true, 
					);
				}
			} else {
				$data[] = array(
					"id" => null, 
					"text" => "No referrals", 
					"state" => array("disabled" => true),
					"children" => false
				);
			}
		}

		header('Content-type: text/json');
		header('Content-type: application/json');
		header('Access-Control-Allow-Origin: *');
		echo json_encode($data);
	}

	public function forex_trinary()
	{
		$account = $this->Account_model->get_account_from_id($this->session->userdata('user_id'));
		if ( !$account->activated ) redirect('dashboard');
		$data = array(
			'title'             => 'Forex Referrals',
			'content'           => 'network/forex_trinary_view',
			'has_forex_sponsor' => $account->forex_sponsor_ID,
			'referrals'         => $this->Referrals_model->get_forex_level1($this->session->userdata()['user_id'])
		);

		$this->load->view('template/template',$data);
	}

	public function forex_trinary_tree($id = null) {

		if($id == null) $account = $this->Account_model->get_account($this->session->userdata()['username']);
		else $account = $this->Account_model->get_account_from_id($id);
		if(!$account) {
			echo "Not found";
			exit();
		}

		$color = 'noman';

		$datenow = new DateTime(date('Y-m-d'));
		$forex_date_renewal = new DateTime($account->forex_date_renewal);
		$interval = $datenow->diff($forex_date_renewal);

		$interval_days = (int)$interval->format('%r%a');

		if($interval_days <= 0 && $account->account_id != '00000001') {
			$color = 'noman_red';
		} else if($interval_days == 7 && $account->account_id != '00000001') {
			$color = 'noman_orange';
		} else {
			$color = 'noman';
		}

		$current = array("user_id"=>$account->account_id, "name"=> $account->first_name." ".$account->last_name, "username"=>$account->username, "left_id"=>$account->forex_left_id, "center_id"=>$account->forex_center_id,"right_id"=>$account->forex_right_id, "level"=>$account->forex_level, "activated"=>$account->activated, "color"=>$color);
		
		$tree[0] = $current;
		$level = $tree[0]['level'];
		if($level-1 >=0 ) $children_id[$level-1] = array($account->account_id);
		$number = 0;

		for ($i=$level; $i < $level+5; $i++) { 

			if($i-1 < 0) {
				$children_id[$i] = $this->find_children_forex(array($account->account_id));
			}
			else { 
				if(!empty($children_id[$i-1])) {
					$children_id[$i] = $this->find_children_forex($children_id[$i-1]);
				}
				
			}

			$array = array_map('array_filter', $children_id);
			$array = array_filter($array);

			// echo "<pre>";
			// print_r($array);
			// exit();

			if(!empty($array)) {
				$tree = $this->add_children_forex($tree, $children_id, $i, $number);
				$number = $number*3 + 1;
			}
		}

		if($this->session->userdata()['user_id'] != $account->account_id){
			$parent_id = $account->forex_placement_ID;
		} else {
			$parent_id = $account->account_id;
		}


		// echo "<pre>";
		// print_r(array_values($tree));
		// exit();
		$data    = array(
			'title'     => 'Forex Trinary Tree', 
			'content'   => 'network/forex_trinary_tree',
			'tree'      => array_values($tree),
			'parent_id' => $account->forex_placement_ID!=null?$account->forex_placement_ID:1
		);

		$this->load->view('template/template',$data);
	}

	public function add_children_forex($tree, $children_id, $level, $number) {

		

		for($i=0; $i<count($children_id[$level]); $i++){
			$child = $this->Account_model->get_account_from_id($children_id[$level][$i]);
			$child_data = null;
			if($child) {

				$color = 'noman';

				$datenow = new DateTime(date('Y-m-d'));
				$forex_date_renewal = new DateTime($child->forex_date_renewal);
				$interval = $datenow->diff($forex_date_renewal);

				$interval_days = (int)$interval->format('%r%a');

				if($interval_days <= 0 && $child->account_id != '00000001') {
					$color = 'noman_red';
				} else if($interval_days == 7 && $child->account_id != '00000001') {
					$color = 'noman_orange';
				} else {
					$color = 'noman';
				}

				$child_data = array("user_id"=>$child->account_id, "name"=> $child->first_name." ".$child->last_name, "username"=>$child->username, "left_id"=>$child->forex_left_id, "center_id"=>$child->forex_center_id,"right_id"=>$child->forex_right_id, "level"=>$child->forex_level, "activated"=>$child->activated, "color"=>$color);
			}

			if($i%3 == 1){	//left
				$tree[($number*3)+1] = $child_data;
			} else if($i%3 == 2){	//center
				$tree[($number*3)+2] = $child_data;
				$number++;
			} else if($i%3 == 0){	//right
				$tree[($number*3)+3] = $child_data;
				$number++;
			}
		}
		return $tree;
	}

	public function find_children_forex($list) {
		$children_id = array();
		foreach ($list as $parent_id) {
			$parent = $this->Account_model->get_account_from_id($parent_id);
			if($parent) array_push($children_id, $parent->forex_left_id, $parent->forex_center_id, $parent->forex_right_id);
			else array_push($children_id, null, null);
		}

		return $children_id;
	}
}
