<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Bank extends CI_Controller {

	public function __construct() {
		parent::__construct();
		$this->load->library('session');
		$this->load->model(array('Account_model'));
		$this->load->model(array('Banks_model'));
		date_default_timezone_set('Asia/Manila');
	}

	public function banks() {
		$banks = $this->Banks_model->get_bank_accounts($this->session->userdata()['user_id']);
		$data = array(
			'title'    => 'List of Banks', 
            'content' => 'bank/banks_view',
            'banks'   => $banks
		);

		$this->load->view('template/template',$data);
	}

	public function add_bank() { 
		$post    = array_map("trim", $this->input->post());
		
		$message = '';

		$isexist = $this->Banks_model->get_existing_bank(array($post['bank_name'],$post['account_number'],$post['account_type']));

		if(!$isexist){

			$result  = $this->Banks_model->add_bank($post);
			$message = 'Success';

			
			//echo $this->load->view('bank/banks_table',$data,true);
		} else {
			$message = 'Duplicate bank account!';
		}

		$data['banks'] = $this->Banks_model->get_bank_accounts($this->session->userdata()['user_id']);

		echo json_encode(
			array(
				'message' => $message, 
				'table'   => $this->load->view('bank/banks_table',$data,true)
			)
		);
	}

	public function edit_bank($bank_id = null) { 
		if($bank_id){
			$bank = $this->Banks_model->get_bank_account($bank_id);
			if($bank && $bank->account_id == $this->session->userdata()['user_id']){
				$data = array(
					'title'    => 'Edit Bank Account', 
		            'content' => 'bank/edit_bank_view',
		            'bank'   => $bank
				);
				$this->load->view('template/template',$data);
			} else {
				redirect(base_url('bank/banks'));
			}
		} else {
			redirect(base_url('bank/banks'));
		}
	}

	public function update_bank() { 
		$post = array_map("trim", $this->input->post());
		$bank = $this->Banks_model->get_bank_account($post['bank_id']);
		if($bank->account_id == $this->session->userdata()['user_id']){
			$result = $this->Banks_model->update_bank($post['bank_id'], $post);
			if($result){
				echo json_encode("Success!");
			} else {
				echo json_encode("Database error. Please contact administrator.");
			}
		} else {
			echo json_encode("Bank not found.");
		}
	}

	public function remove_bank() {
		$post = $this->input->post();
		$result = $this->Banks_model->remove_bank($post['id']);

		if($result) echo json_encode(array('status' => 'success', 'message' => "Successfully deleted bank account."));
		else echo json_encode(array('status' => 'error', 'message' => "Error."));
	}
}
