<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Dashboard extends CI_Controller {
	public function __construct() {
		parent::__construct();
		$this->load->library('session');
		if ( ! $this->session->userdata('user_id')) {
			redirect('Account/login');
		}
		$this->load->model(array('Account_model','Token_gaming_model','Money_model','Affiliate_shares_model', 'Announcement_model'));
	}
	
	public function index()
	{

		// echo "<pre>";
		// print_r(json_encode($this->Money_model->get_cfc_coins_purchases()));
		// echo "</pre>";
		// exit();
		$result = $this->Account_model->get_account($this->session->userdata('username'));
		$team_bonus = $this->get_team_bonus($result);
		$this->Money_model->update_money($result->account_id, array('team_bonus'=> $team_bonus*20));

		//update rbb
		if($result->points_left >= 20 && $result->points_right >= 20){
			if($result->points_left>$result->points_right){
				$rbb = (int)($result->points_right/20);
			} else {
				$rbb = (int)($result->points_left/20);
			}
			$remainder_left = $result->points_left - ($rbb*20);
			$remainder_right = $result->points_right - ($rbb*20);
			$rbb = $rbb*200;
			$this->Account_model->update_account($result->account_id, array('points_left'=> $remainder_left, 'points_right'=> $remainder_right));
			$this->Money_model->add_pairing_bonus(array($rbb, $result->account_id));

			//update crossline bonus & placement bonus
			// if($result->placement_ID != null){
			// 	$this->update_crossline_bonus($result, $rbb);
			// }
			// $this->update_placement_bonus($result, $rbb);
		}

		$this->Money_model->update_total($this->session->userdata('user_id'));
		$this->Money_model->update_current($this->session->userdata('user_id'));
		// $this->Money_model->update_affiliate_share_total_income_per_day($this->session->userdata('user_id'));
		$this->Money_model->update_total_affiliate_share($this->session->userdata('user_id'));
		$money      = $this->Money_model->get_money_details($this->session->userdata('user_id'));
		$money_logs = $this->Money_model->get_logs($this->session->userdata('user_id'),date('Y-m-1'));

		$affiliate_shares               = $this->Affiliate_shares_model->get_active_affiliate_shares($this->session->userdata('user_id'));
		$matured_affiliate_shares       = $this->Affiliate_shares_model->get_affiliate_shares_for_encashment($this->session->userdata('user_id'));
		$total_matured_affiliate_shares = $this->Affiliate_shares_model->get_total_matured_affiliate_shares($this->session->userdata('user_id'));
		$cfc_coins_report               = $this->Money_model->get_cfc_coins_purchases();

		//$monthly_registered = array();
		$monthly_registered   = "";
		$month_ctr            = 1;


		foreach($this->Account_model->get_monthly_registered() as $row) {
			$monthly_registered .= "[" . $month_ctr . ',' . $row . "],";
			//array_push($monthly_registered, array($month_ctr,$row));
			$month_ctr++;
		}

		$data = array (
			'title'                          => 'Dashboard',
			'content'                        => 'dashboard_view',
			'points_left'                    => $result->points_left,
			'points_right'                   => $result->points_right,
			'email_address'                  => $result->email_address,
			'mobile_number'                  => $result->mobile_number,
			'sponsor_ID'                     => $result->sponsor_ID,
			'placement_ID'                   => $result->placement_ID,
			'PIN1'                           => $result->PIN1,
			'PIN2'                           => $result->PIN2, 
			'money'                          => $money,
			'money_logs'                     => $money_logs,
			'affiliate_shares'               => $affiliate_shares,
			'matured_affiliate_shares'       => $matured_affiliate_shares,
			'total_matured_affiliate_shares' => $total_matured_affiliate_shares?$total_matured_affiliate_shares->total:0,
            'cfc_exclusive'                  => $this->Token_gaming_model->get_current(),
            'announcement_data'        		 => $this->Announcement_model->get_visible_announcements(),
			'monthly_registered'             => substr($monthly_registered,0,-1),
			'cfc_coins_report'				 => $cfc_coins_report? json_encode($cfc_coins_report):null
		);

		

		// echo "<pre>";
		// 	print_r($monthly_registered);
		// 	echo "</pre>";
		// 	exit();

		// echo "<pre>";
		// echo ();
		// echo "</pre>";
		// exit();

		$this->load->view('template/template',$data);
	}

	public function get_team_bonus($account) {
		$count = 0;
		$level = $account->level+10;
		if($account->left_id != null){
			$count += $this->get_indirect_count($account->left_id, -1, $level);
		}
		if($account->right_id != null){
			$count += $this->get_indirect_count($account->right_id, -1, $level);
		}
		return $count;
	}

	public function get_indirect_count($account_id, $count, $level) {
		$account = $this->Account_model->get_account_from_id($account_id);
		if($account->level > $level) return $count;
		if($account->left_id != null){
			$count = $this->get_indirect_count($account->left_id, $count, $level);
		}
		if($account->right_id != null){
			$count = $this->get_indirect_count($account->right_id, $count, $level);
		}
		return $count+1;
	}

    public function manage_announcement()
    {
        $data = array(
            'title'   => 'Manage Announcement',
            'content' => 'manage_announcement_view',
            'result'  => $this->Announcement_model->get_all_announcements()
        );

        $this->load->view('template/template',$data);
    }

    public function update_announcement()
    {
    	// echo getcwd() . "/resources/upload/\n";
    	// exit();
        $post = $this->input->post();

        // $path = $_FILES['uploaded_file']['name'];

        // if($path) {
        //     $ext  = pathinfo($path, PATHINFO_EXTENSION);
        //     $file = 'resources/upload/' . time() . '.' . $ext;
        //     $post['bg_img'] = $file;
        //     move_uploaded_file($_FILES['uploaded_file']['tmp_name'], $file);
        // }

        $this->Announcement_model->update_announcement($post);

        $data['result'] = $this->Announcement_model->get_all_announcements();

        echo $this->load->view('manage_announcement_table',$data,true);
    }

    public function update_announcement_modal()
    {
        $post = $this->input->post();

        $result = $this->Announcement_model->get_announcement_by_id($post['announcement_id']);

        echo json_encode($result);
    }

	/*public function update_crossline_bonus($account, $pairing_bonus){
		$placement_account = $this->Account_model->get_account_from_id($account->placement_ID);
		if($placement_account->left_id == $account->account_id && $placement_account->right_id != null){	//account is left child and has sibling
			$this->Money_model->add_crossline_bonus(array($pairing_bonus*0.10, $placement_account->right_id));
		} else if ($placement_account->right_id == $account->account_id && $placement_account->left_id != null){ //account is right child and has sibling
			$this->Money_model->add_crossline_bonus(array($pairing_bonus*0.10, $placement_account->left_id));
		}
	}

	public function update_placement_bonus($account, $pairing_bonus){
		if($account->left_id){
			$money = $this->Money_model->get_money_details($account->left_id);
			if($money->direct_referral >= 200){
				$this->Money_model->add_placement_bonus(array($pairing_bonus*0.10, $account->left_id));
			}
		}
		if($account->right_id){
			$money = $this->Money_model->get_money_details($account->right_id);
			if($money->direct_referral >= 200){
				$this->Money_model->add_placement_bonus(array($pairing_bonus*0.10, $account->right_id));
			}
		}
	}*/
}