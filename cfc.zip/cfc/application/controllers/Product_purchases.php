<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Product_Purchases extends CI_Controller {
	public function __construct() {
		parent::__construct();
		$this->load->library('session');
		if ( $this->session->userdata('user_id') != "0000001" ) {
			redirect('dashboard');
		}
		$this->load->model(array('Product_purchases_model'));
		$this->load->model(array('Account_model'));
		date_default_timezone_set('Asia/Manila');
	}

	public function view() {
		$data = array(
			'title'   => 'Products Purchased', 
            'content' => 'product_purchases/product_purchases_view',
            'result'  => $this->Product_purchases_model->get_all_purchases()
		);
		$this->load->view('template/template',$data);
	}

	public function add() {

		$post = $this->input->post();
		$account = $this->Account_model->get_account_from_id($post['account_id']);
		if($account){
			$post['product_price'] = str_replace(',',"",$post['product_price']);
			$this->Product_purchases_model->add_purchase($post);

			//Add points to upline
			if($account->placement_ID != null){
				$placement_account = $this->Account_model->get_account_from_id($account->placement_ID);
				if($placement_account->left_id == $post['account_id']){
					$this->Account_model->add_points("left", array('quantity' => $post['product_quantity'], 'account_id'=>$placement_account->account_id));
				} else if($placement_account->right_id == $post['account_id']){
					$this->Account_model->add_points("right", array('quantity' => $post['product_quantity'], 'account_id'=>$placement_account->account_id));
				}
			}
			$data['result'] = $this->Product_purchases_model->get_all_purchases();
			echo $this->load->view('product_purchases/product_purchases_table',$data,true);
		} else {
			echo json_encode("Error: Account ID not found.");
		}
	}
}