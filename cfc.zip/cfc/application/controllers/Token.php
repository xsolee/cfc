<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Token extends CI_Controller {
	public function __construct() {
		parent::__construct();
		$this->load->library('session');
		$this->load->model(array('Token_gaming_model','Money_model'));
		date_default_timezone_set('Asia/Manila');
	}

	public function token_gaming() {

		$user_id = $this->session->userdata('user_id');
		$money   = $this->Money_model->get_money_details($user_id);

		$data = array(
			'title'   => 'Tokens', 
            'content' => 'token/token_view',
            'money'   => $money,
            'result'  => $this->Token_gaming_model->get_token_by_id()
		);

		$this->load->view('template/template',$data);
	}

	public function generate_token()
	{
		$post = $this->input->post();
		$generate_token = array();
		$generated_tokens = array();
		$ctr = 0;
		while($post['no_of_token'] != $ctr) {
			$generate_token = $this->randomGen(1,54,3);
			$validate_token = $this->Token_gaming_model->validate_token($generate_token);

			if(!$validate_token) {
	        	array_push($generated_tokens, $generate_token);
		        $ctr++;

		        if(count(array_unique($generated_tokens, SORT_REGULAR)) != count($generated_tokens)) {
		        	$ctr--;
		        }
	        }
		}

		foreach($generated_tokens as $row) {
        	$this->Token_gaming_model->insert_token(
        		array(
	        		'header_id' => $post['token_type'], 
	        		'account_id' => $this->session->userdata('user_id'),
	        		'created_date' => date('Y-m-d'),
	        		'combination1' => $row[0],
	        		'combination2' => $row[1],
	        		'combination3' => $row[2]
        		)
        	);
        }

        $data['result'] = $this->Token_gaming_model->get_token_by_id();
		echo $this->load->view('token/token_table',$data,true);
	}

	function randomGen($min, $max, $quantity) {
	    $numbers = range($min, $max);
	    shuffle($numbers);
	    return array_slice($numbers, 0, $quantity);
	}

	public function test_cron_jobs1() {
		$this->Token_gaming_model->test_cron_jobs1();
	}

	public function test_cron_jobs2() {
		$this->Token_gaming_model->test_cron_jobs2();
	}
}