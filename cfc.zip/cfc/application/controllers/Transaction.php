<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Transaction extends CI_Controller {
	public function __construct() {
		parent::__construct();
		$this->load->library('session');
		if ( ! $this->session->userdata('user_id')) {
			redirect('Account/login');
		}
		$this->load->model(array('Account_model'));
		$this->load->model(array('Transactions_model'));
		$this->load->model(array('Banks_model'));
		$this->load->model(array('Money_model'));
		$this->load->model(array('Affiliate_shares_model'));
		$this->load->model(array('Register_pins_model'));
		date_default_timezone_set('Asia/Manila');
	}

	public function encashment() {

		$data = array(
			'title'   => 'Cashback', 
            'content' => 'transactions/encash_view',
            'banks'  => $this->Banks_model->get_bank_accounts($this->session->userdata()['user_id'])
		);
		$this->load->view('template/template',$data);
	}

	public function history() {
		$transactions = $this->Transactions_model->filter_accounting_transactions("None","None",$this->session->userdata('user_id'));
		$ttype = $this->Transactions_model->get_transaction_types($this->session->userdata('user_id'));
		$data = array(
			'title'   => 'Cashback History', 
            'content' => 'transactions/encash_history_view',
            'result'  => $transactions?$transactions:array(),
            'ttype'   => $ttype?$ttype:array()
            // 'banks'  => $this->Banks_model->get_bank_accounts($this->session->userdata()['user_id'])
		);
		$this->load->view('template/template',$data);
	}

	public function update_status() {
		$account_id = $this->session->userdata()['user_id'];
		if(in_array($account_id, array("0000002","0000001"))) {	
			$post = array_map("trim", $this->input->post());
			$this->Transactions_model->update_status($post['header_id']);
			
			$transactions = $account_id=="0000002"?$this->Transactions_model->get_transactions("0000002"):$this->Transactions_model->get_all_transactions();

			$data['result'] = $transactions?$transactions:array();
			echo $account_id=="0000002"?$this->load->view('transactions/encash_history_table',$data,true):$this->load->view('transactions/all_requests_table',$data,true);
		} else {
			redirect('dashboard');
		}
	}

	public function all_requests() {
		if($this->session->userdata()['user_id'] != "0000001") { redirect('dashboard'); }
		$transactions = $this->Transactions_model->get_all_transactions();
		$ttype = $this->Transactions_model->get_transaction_types();
		$data = array(
			'title'   => 'Requests History', 
            'content' => 'transactions/all_requests_view',
            'result'  => $transactions?$transactions:array(),
            'ttype'   => $ttype?$ttype:array(),
            'banks'   => $this->Banks_model->get_all_bank_accounts()
		);
		$this->load->view('template/template',$data);
	}

	public function get_filtered_transactions()
	{
		$post = array_map("trim", $this->input->post());
		$data['result'] = $this->Transactions_model->get_filtered_transactions($post['ttype'],$post['status']);
		echo $this->load->view('transactions/all_requests_table',$data,true);
	}

	public function encash() {
		$post = array_map("trim", $this->input->post());
		$post['status'] = "pending";
		$account_id = $this->session->userdata('user_id');
		if($post['request_type']!="GCash" && !isset($post['bank_id'])){ 
			echo json_encode("Error: Please add your bank account.");
			exit(); 
		}
		if($post['amount']>3000 && $post['encash_from'] != 'Forex Trinary') {
			echo json_encode("Error: Maximum amount is 3000 usd.");
			exit();
		}
		if($post['amount']<1000 && $post['encash_from'] == "Rewards") {
			echo json_encode("Error: Minimum amount is 1000.");
			exit();
		}

		if($post['amount']<50 && $post['encash_from'] == "CFC WS Rewards") {
			echo json_encode("Error: Minimum amount is 50.");
			exit();
		}

		if(($post['amount']<100 || $post['amount']>5000) && $post['encash_from'] == "Forex Trinary") {
			echo json_encode("Error: Minimum amount is 100 and Maximum amount is 5000");
			exit();
		}

		if ($post['bank_id'] == ""){ $post['bank_id'] = null; }

		$this->Money_model->update_total($account_id);
		$this->Money_model->update_current($account_id);
		$this->Money_model->update_total_affiliate_share($account_id);
		$money = $this->Money_model->get_money_details($account_id);

		if ($post['encash_from'] == "Rewards"){
			if($money->current_bonus < $post['amount'])	{
				echo json_encode("Error: Insufficient funds.");
				exit();
			} else {
				$post['date_created'] = date('Y-m-d H:i:s');
        		$this->Transactions_model->add_transaction($post);
				$this->Money_model->withdraw_bonus(array($post['amount'], $post['amount']*0.10, $account_id));
			}
		} else if($post['encash_from'] == "CFC WS Rewards"){
			if(in_array(date('d'), array(26,27))) {	//Encash affiliate share cutoff

				if((($money->total_affiliate_share) - ($money->withdrawn_affiliate_share + $money->reinvest_affiliate_shares + $money->transfered_affiliate_shares)) < $post['amount'])	{
					echo json_encode("Error: Insufficient funds. Current fund: " . (($money->total_affiliate_share) - ($money->withdrawn_affiliate_share + $money->reinvest_affiliate_shares + $money->transfered_affiliate_shares)));
					exit();
				} else {
					$post['date_created'] = date('Y-m-d H:i:s');
            		$this->Transactions_model->add_transaction($post);
					$this->Money_model->withdraw_affiliate_share(array($post['amount'], $post['amount']*0.10, $account_id));
				}
			} else {
				echo json_encode("Error: Withdrawal of affiliate shares is open every 26th and 27th of the month.");
				exit();
			}
		} else if($post['encash_from'] == "CFC Exclusive") {

			$money_exclusive_withdrawal_limit = $this->Money_model->validate_cfc_exclusive_withdrawal_limit_daily($account_id);
			
			if($money_exclusive_withdrawal_limit->debit + $post['amount'] > 3000) {
				echo json_encode("Error: Maximum daily withdrawal of CFC Exclusive is 3000. Total withdrawal today: " . $money_exclusive_withdrawal_limit->debit);
				exit();
			}

			if((($money->cfc_exclusive + $money->cfc_exclusive_referral + $money->received_cfc_exclusive) - ($money->withdrawn_cfc_exclusive + $money->transfered_cfc_exclusive)) < $post['amount']) {
				echo json_encode("Error: Insufficient funds. Available CFC Exclusive: " . (($money->cfc_exclusive + $money->cfc_exclusive_referral + $money->received_cfc_exclusive) - ($money->withdrawn_cfc_exclusive + $money->transfered_cfc_exclusive)));
				exit();
			}
			$post['date_created'] = date('Y-m-d H:i:s');
			$this->Transactions_model->add_transaction($post);
			$this->Money_model->withdraw_cfc_exclusive(array($post['amount'],0, $account_id));
		} else if($post['encash_from'] == "CFC WS Rewards Received") {
			if(in_array(date('d'), array(26,27))) {	//Encash affiliate share cutoff

				if((($money->received_affiliate_shares) - ($money->withdrawn_affiliate_share_2 + $money->transfered_affiliate_shares_2)) < $post['amount'])	{
					echo json_encode("Error: Insufficient funds. Current fund: " . (($money->received_affiliate_shares) - ($money->withdrawn_affiliate_share_2 + $money->transfered_affiliate_shares_2)));
					exit();
				} else {
					$post['date_created'] = date('Y-m-d H:i:s');
            		$this->Transactions_model->add_transaction($post);
					$this->Money_model->withdraw_affiliate_share_2(array($post['amount'], $post['amount']*0.10, $account_id));
				}
			} else {
				echo json_encode("Error: Withdrawal of affiliate shares is open every 26th and 27th of the month.");
				exit();
			}
		} else if($post['encash_from'] == "Forex Unilevel") {
			if(in_array(date('d'), array(10,25))) {	//Encash affiliate share cutoff

				if( (($money->forex_referral + $money->received_forex_referral) - ($money->transferred_forex_referral-$money->withdrawn_forex_referral)) < $post['amount'] )	{
					echo json_encode("Error: Insufficient funds. Current fund: " . (($money->forex_referral + $money->received_forex_referral) - ($money->transferred_forex_referral-$money->withdrawn_forex_referral)) );
					exit();
				} else {
					$post['date_created'] = date('Y-m-d H:i:s');
            		$this->Transactions_model->add_transaction($post);
					$this->Money_model->withdraw_forex_referral(array($post['amount'], $post['amount']*0.10, $account_id));
				}
			} else {
				echo json_encode("Error: Withdrawal of forex unilevel is open every 10th and 25th of the month.");
				exit();
			}
		} else if($post['encash_from'] == "Forex Trinary") {
			if(in_array(date('d'), array(28))) {	//Encash affiliate share cutoff

				if( (($money->forex_trinary + $money->received_forex_trinary) - ($money->transferred_forex_trinary-$money->withdrawn_forex_trinary)) < $post['amount'] )	{
					echo json_encode("Error: Insufficient funds. Current fund: " . (($money->forex_trinary + $money->received_forex_trinary) - ($money->transferred_forex_trinary-$money->withdrawn_forex_trinary)) );
					exit();
				} else {
					$post['date_created'] = date('Y-m-d H:i:s');
            		$this->Transactions_model->add_transaction($post);
					$this->Money_model->withdraw_forex_trinary(array($post['amount'], $post['amount']*0.10, $account_id));
				}
			} else {
				echo json_encode("Error: Withdrawal of forex trinary is open every 28th of the month.");
				exit();
			}
		} else {
			echo json_encode("Error: Unknown transaction type.");
			exit();
		}

		$this->add_money_logs($account_id, $post['amount'], "Withdrawn ".$post['encash_from']);
		echo json_encode("Success");
		/*$data['result'] = $this->Transactions_model->get_transactions($account_id);
		echo $this->load->view('transactions/encash_history_table',$data,true);*/
	}

    public function buy_pincodes()
    {
        $user_id = $this->session->userdata('user_id');

		$this->Money_model->update_total($user_id);
		$this->Money_model->update_current($user_id);
		$this->Money_model->update_total_affiliate_share($user_id);
		$money = $this->Money_model->get_money_details($user_id);

		$account = $this->Account_model->get_account_from_id($this->session->userdata('user_id'));
        
        $tree = $this->add_to_tree(array(), $account->account_id);
        $tree = $this->traverse_tree($tree, $account->account_id);

        /*$tree  = array();
        $level = $account->level;

        if($level-1 >=0 ) $children_id[$level-1] = array($account->account_id);
        else $children_id[$i] = $this->find_children(array($account->account_id));
        for ($i=$level; $i < $this->Account_model->get_last_level(); $i++) { 

            // echo "<pre>";
            // print_r($level);
            // echo "</pre>";
            // exit();

            $children_id[$i] = $this->find_children($children_id[$i-1]);
            $tree = $this->add_children($tree, $children_id, $i);
            if(empty($children_id[$i])) break;
        }*/

        $data = array(
            'title'                   => 'Buy Pincodes',
            'content'                 => 'transactions/buy_pincodes_view',
            'bought_account_pincodes' => $this->Transactions_model->get_bought_pincodes_available("register_pins", array($user_id,$user_id)),
            'bought_cfc_pincodes'     => $this->Transactions_model->get_bought_pincodes_available("affiliate_shares_pin", array($user_id,$user_id)),
            'money'                   => $money,
            'transfer_list'           => array_filter($tree)
        );

        $this->load->view('template/template',$data);
    }

    public function traverse_tree($tree, $account_id) {
    	if(isset($tree[$account_id]['left_id']) && $tree[$account_id]['left_id'] != null){
	        $tree = $this->add_to_tree($tree, $tree[$account_id]['left_id']);
	        $tree = $this->traverse_tree($tree, $tree[$account_id]['left_id']);
    	}
	    if(isset($tree[$account_id]['right_id']) && $tree[$account_id]['right_id'] != null){
	        $tree = $this->add_to_tree($tree, $tree[$account_id]['right_id']);
	        $tree = $this->traverse_tree($tree, $tree[$account_id]['right_id']);
    	}
	    return $tree;
    }

    public function add_to_tree($tree, $child_id) {
		$child = $this->Account_model->get_account_from_id($child_id);
        if($child) {
	        $child_data = array("id"=>$child->id, "account_id"=>$child->account_id, "name"=> $child->first_name." ".$child->last_name, "username"=>$child->username, "left_id"=>$child->left_id, "right_id"=>$child->right_id, "level"=>$child->level, "activated"=>$child->activated);
	        $tree[$child->account_id] = $child_data;
	    }
	    return $tree;
    }

    public function add_children($tree, $children_id, $level) {
        for($i=0; $i<count($children_id[$level]); $i++){
			$child = $this->Account_model->get_account_from_id($children_id[$level][$i]);
            $child_data = null;
            if($child) {
                $child_data = array("id"=>$child->id, "account_id"=>$child->account_id, "name"=> $child->first_name." ".$child->last_name, "username"=>$child->username, "left_id"=>$child->left_id, "right_id"=>$child->right_id, "level"=>$child->level, "activated"=>$child->activated);
            	$tree[$child->id] = $child_data;
            }
        }
        return $tree;
    }

    public function find_children($list) {
        $children_id = array();
        foreach ($list as $parent_id) {
			$parent = $this->Account_model->get_account_from_id($parent_id);
            if($parent) array_push($children_id, $parent->left_id, $parent->right_id);
        }

        return $children_id;
    }

    public function get_money()
    {
        $post    = $this->input->post();
        $user_id = $this->session->userdata('user_id');

		$this->Money_model->update_total($user_id);
		$this->Money_model->update_current($user_id);
		$this->Money_model->update_total_affiliate_share($user_id);
		$money = $this->Money_model->get_money_details($user_id);

		if($post['withdraw_from'] == "from rewards") $available_withdrawal = $money->current_bonus;
		else if($post['withdraw_from'] == "from cfc") $available_withdrawal = $money->total_affiliate_share-($money->withdrawn_affiliate_share+$money->reinvest_affiliate_shares+$money->transfered_affiliate_shares);
		else if($post['withdraw_from'] == "from maintenance") $available_withdrawal = $money->maintenance - $money->withdrawn_maintenance;
		else $available_withdrawal = 0;

        echo json_encode(
            array(
                'available_withdrawal' => $available_withdrawal
            )
        );
    }

    public function bought_pincodes() {
        $post         = $this->input->post();

        // echo "<pre>";
        // print_r($post);
        // echo "</pre>";
        // exit();

        $created_date = date('Y-m-d H:i:s');
        $user_id      = $this->session->userdata('user_id');

		$this->Money_model->update_total($user_id);
		$this->Money_model->update_current($user_id);
		$this->Money_model->update_total_affiliate_share($user_id);
		$money = $this->Money_model->get_money_details($user_id);

		if(($post['withdraw_from']=="from rewards" && $post['total_amount']>$money->current_bonus) || ($post['withdraw_from']=="from cfc" && $post['total_amount']>$money->total_affiliate_share-($money->withdrawn_affiliate_share+$money->reinvest_affiliate_shares+$money->transfered_affiliate_shares)) || ($post['withdraw_from']=="from maintenance" && $post['total_amount']>($money->maintenance - $money->withdrawn_maintenance))){
            echo json_encode(
                array(
                    'message' => "Error: Total amount is greater than available withdrawal",
                )
            );
			exit();
		}


		if($post['pincode_type'] == "Account"){
	        $possibleChars  = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
	        $pin1           = '';
	        $pin2           = '';
	        $pin1_length    = 8;
	        $pin2_length    = 6;
	        $ctr            = 0;
	        $generated_pin = array();
	        $duplicate_entries = array();


	        while($post['no_of_pin'] != $ctr) {

	        	for($i = 0; $i < $pin1_length; $i++) {
		            $rand = rand(0, strlen($possibleChars) - 1);
		            $pin1 .= substr($possibleChars, $rand, 1);
		        }

		        for($i = 0; $i < $pin2_length; $i++) {
		            $rand = rand(0, strlen($possibleChars) - 1);
		            $pin2 .= substr($possibleChars, $rand, 1);
		        }

		        $validate_pin = $this->Register_pins_model->validate_pin_if_exist(array($pin1,$pin2));

		        if(!$validate_pin) {
		        	array_push($generated_pin, array('pin1' => $pin1, 'pin2' => $pin2));
			        $ctr++;

			        if(count(array_unique($generated_pin, SORT_REGULAR)) != count($generated_pin)) {
			        	$ctr--;
			        }
		        }

		        $pin1 = '';
				$pin2 = '';
	        }

	        foreach($generated_pin as $row) {
	        	$this->Transactions_model->save_pins(array('PIN1' => $row['pin1'], 'PIN2' => $row['pin2'], 'bought_by' => $user_id, 'date_created'=>$created_date));
	        }

	    } else if($post['pincode_type'] == "CFC"){

	    	if(in_array(date('d'), array(26,27))) {
		    	if($post['no_of_accounts'] == 0) {
					$post['no_of_accounts'] = 0.5;
				}
			
		    	$possibleChars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
		        $pin           = '';
		        $pin_length    = 10;
		        $ctr           = 0;
		        $generated_pin = array();
		        $duplicate_entries = array();


		        while($post['no_of_pin'] != $ctr) {

		        	for($i = 0; $i < $pin_length; $i++) {
			            $rand = rand(0, strlen($possibleChars) - 1);
			            $pin .= substr($possibleChars, $rand, 1);
			        }
			        
			        $validate_pin = $this->Affiliate_shares_model->check_PIN(array($pin));

			        if(!$validate_pin) {
			        	array_push($generated_pin, array('pin' => $pin, 'no_of_shares' => $post['no_of_accounts']));
				        $ctr++;

				        if(count(array_unique($generated_pin, SORT_REGULAR)) != count($generated_pin)) {
				        	$ctr--;
				        }
			        }

			        $pin = '';
		        }

		        foreach($generated_pin as $row) {
		        	$this->Affiliate_shares_model->save_pin(array('pin' => $row['pin'], 'no_of_share' => $row['no_of_shares'], 'bought_by' => $user_id, 'created_date'=>$created_date));
		        }

		    } else {

		    	$data['bought_account_pincodes'] = $this->Transactions_model->get_bought_pincodes_available("register_pins", array($user_id,0));
        		$data['bought_cfc_pincodes'] = $this->Transactions_model->get_bought_pincodes_available("affiliate_shares_pin", array($user_id,0));
        		$money = $this->Money_model->get_money_details($user_id);

        		
            	$available_withdrawal = $money->total_affiliate_share-($money->withdrawn_affiliate_share+$money->reinvest_affiliate_shares+$money->transfered_affiliate_shares);
		    	echo json_encode(
		            array(
		                'message'              => "Buying pincodes / Withdrawal is every 26th and 27th of the month only",
		                'table'                => $post['pincode_type']=="Account"?$this->load->view('transactions/buy_account_pincodes_table',$data,true):$this->load->view('transactions/buy_cfc_pincodes_table',$data,true),
		                'available_withdrawal' => $available_withdrawal
		            )
		        );
		        exit();
		    }

	    }

        $params = array(
            'account_id'   => $user_id,
            'amount'       => $post['total_amount'],
            'encash_from'  => 'Bought Pincodes ('.$post['withdraw_from'].")",
            'date_created' => $created_date
        );

        if($post['withdraw_from']=="from rewards"){   //buys pincodes from rewards
            $this->Transactions_model->save_buy_pincode_transaction($params, "withdrawn_bonus");
			$this->Money_model->update_current($user_id);
			$money = $this->Money_model->get_money_details($user_id);
            $available_withdrawal = $money->current_bonus;

        } else if($post['withdraw_from']=="from cfc"){    //buys pincodes from maintenance
            $this->Transactions_model->save_buy_pincode_transaction($params, "withdrawn_affiliate_share");
			$money = $this->Money_model->get_money_details($user_id);
            $available_withdrawal = $money->total_affiliate_share-($money->withdrawn_affiliate_share+$money->reinvest_affiliate_shares+$money->transfered_affiliate_shares);

        } else if($post['withdraw_from']=="from maintenance"){    //buys pincodes from maintenance
            $this->Transactions_model->save_buy_pincode_transaction($params, "withdrawn_maintenance");
			$money = $this->Money_model->get_money_details($user_id);
            $available_withdrawal = $money->maintenance - $money->withdrawn_maintenance;
        }

        $data['bought_account_pincodes'] = $this->Transactions_model->get_bought_pincodes_available("register_pins", array($user_id,0));
        $data['bought_cfc_pincodes'] = $this->Transactions_model->get_bought_pincodes_available("affiliate_shares_pin", array($user_id,0));
		$this->add_money_logs($user_id, $post['total_amount'], "Bought pincodes ".$post['withdraw_from']);

        echo json_encode(
            array(
                'message'              => "Success",
                'table'                => $post['pincode_type']=="Account"?$this->load->view('transactions/buy_account_pincodes_table',$data,true):$this->load->view('transactions/buy_cfc_pincodes_table',$data,true),
                'available_withdrawal' => $available_withdrawal
            )
        );
    }

    public function get_bank_list()
    {
    	$post    = $this->input->post();
    	$result  = $this->Banks_model->get_bank_by_bank_name($post['bank_name']);
    	$options = '<option value="">Nothing Selected</option>';

		foreach($result as $row) {
			$options .= '<option value="' . $row->bank_id . '">' . $row->account_name . ' [' .$row->account_number. ']' . '</option>'; 
		}
		echo $options;
    }
	public function add_money_logs($account_id, $amount, $description) { 
		$data = array(
			'account_id'  => $account_id,
			'debit'       => $amount,
			'description' => $description,
			'date'        => date('Y-m-d H:i:s')
		);
		$this->Money_model->add_logs($data);
	}

	public function transfer_rewards() {
		$data = array(
			'title'   => 'Transfer Rewards', 
            'content' => 'transactions/transfer_rewards_view',
			'accounts' => $this->Account_model->get_all_account(),
			'hasTransferPassword'=>$this->Account_model->get_account_from_id($this->session->userdata('user_id'))->transfer_password? true: false
		);
		$this->load->view('template/template',$data);
	}

	public function transfer() {
		$post = array_map("trim", $this->input->post());
		$account_id = $this->session->userdata('user_id');

		if(!$this->Account_model->check_transfer_password(array($account_id, $post['password']))) {
			echo $this->Account_model->get_account_from_id($account_id)->transfer_password? json_encode("Error: Incorrect Transfer Password!"): json_encode("Error: Please Set Transfer Password first!");
			exit();
		}

		if(!$this->Account_model->get_account_from_id($post['receiver_id'])) {
			echo json_encode("Error: Account ID doesn't exist!");
			exit();
		}

		if($post['amount']<100) {
			echo json_encode("Error: Minimum amount is 100.");
			exit();
		}

		if($post['receiver_id'] == "0000002") {
			if(date('N') != 7) {	//Check if sunday
				echo json_encode("Error: Transfer rewards to accounting is available during Sundays only.");
				exit();
			}
			if(!$this->Banks_model->get_bank_accounts($account_id, "BDO")) {	//Check if sunday
				echo json_encode("Error: Please add a BDO Bank account to enable transfer to accounting.");
				exit();
			}
			$status = 'pending';
			$maintenance = $post['amount']*0.10;
		} else {
			$status = 'success';
			$maintenance = 0;
		}

		$this->Money_model->update_total($account_id);
		$this->Money_model->update_current($account_id);		
		$money = $this->Money_model->get_money_details($account_id);
		$transaction_params = array();
		

		if ($post['transfer_from'] == "Rewards"){
			if($money->current_bonus < $post['amount'])	{
				echo json_encode("Error: Insufficient funds.");
				exit();
			} 

			$this->Money_model->received_rewards(array(($post['amount']-( 5+$maintenance )),$post['receiver_id']));
			$this->Money_model->transfer_rewards(array($post['amount'],$maintenance,$account_id));

			$transaction_params[] = array(
				'account_id'    => $account_id,
				'amount'        => $post['amount'],
				'maintenance'   => $maintenance,
				'status'   		=> $status,
				'encash_from'   => 'Transfer Rewards',
				'date_created'  => date('Y-m-d H:i:s'),
				'transfered_by' => null,
				'receiver_name' => $post['receiver_id']
			);

			$transaction_params[] = array(
				'account_id'    => $post['receiver_id'],
				'amount'        => $post['amount'],
				'maintenance'   => $maintenance,
				'status'   		=> $status,
				'encash_from'   => 'Received Rewards',
				'date_created'  => date('Y-m-d H:i:s'),
				'transfered_by' => $account_id,
				'receiver_name' => null
			);

			$this->Money_model->update_total($account_id);
			$this->Money_model->update_current($account_id);
			//Complete Transfer of Money
			
		} else if($post['transfer_from'] == "CFC Exclusive") {
			if((($money->cfc_exclusive + $money->cfc_exclusive_referral + $money->received_cfc_exclusive) - ($money->withdrawn_cfc_exclusive + $money->transfered_cfc_exclusive)) < $post['amount']) {
				echo json_encode("Error: Insufficient funds. Available CFC Exclusive: " . (($money->cfc_exclusive + $money->cfc_exclusive_referral + $money->received_cfc_exclusive) - ($money->withdrawn_cfc_exclusive + $money->transfered_cfc_exclusive)));
				exit();
			}

			$this->Money_model->received_cfc_exclusive(array(($post['amount']-( 5+$maintenance )),$post['receiver_id']));
			$this->Money_model->transfer_cfc_exclusive(array($post['amount'],$maintenance,$account_id));

			$transaction_params[] = array(
				'account_id'    => $account_id,
				'amount'        => $post['amount'],
				'maintenance'   => $maintenance,
				'status'   		=> $status,
				'encash_from'   => 'Transfer CFC Exclusive',
				'date_created'  => date('Y-m-d H:i:s'),
				'transfered_by' => null,
				'receiver_name' => $post['receiver_id']
			);

			$transaction_params[] = array(
				'account_id'    => $post['receiver_id'],
				'amount'        => $post['amount'],
				'maintenance'   => $maintenance,
				'status'   		=> $status,
				'encash_from'   => 'Received CFC Exclusive',
				'date_created'  => date('Y-m-d H:i:s'),
				'transfered_by' => $account_id,
				'receiver_name' => null
			);

				//Complete Transfer of Money
		} else if($post['transfer_from'] == "CFC WS Rewards") {

			if((($money->total_affiliate_share) - ($money->withdrawn_affiliate_share + $money->reinvest_affiliate_shares + $money->transfered_affiliate_shares)) < $post['amount'])	{
				echo json_encode("Error: Insufficient funds. Currend Fund: " . (($money->total_affiliate_share) - ($money->withdrawn_affiliate_share + $money->reinvest_affiliate_shares + $money->transfered_affiliate_shares)));
				exit();
			} 

			$this->Money_model->received_affiliate_shares(array(($post['amount']-( 5+$maintenance )),$post['receiver_id']));
			$this->Money_model->transfer_affiliate_shares(array($post['amount'],$maintenance,$account_id));

			$transaction_params[] = array(
				'account_id'    => $account_id,
				'amount'        => $post['amount'],
				'maintenance'   => $maintenance,
				'status'   		=> $status,
				'encash_from'   => 'Transfer CFC WS Rewards',
				'date_created'  => date('Y-m-d H:i:s'),
				'transfered_by' => null,
				'receiver_name' => $post['receiver_id']
			);

			$transaction_params[] = array(
				'account_id'    => $post['receiver_id'],
				'amount'        => $post['amount'],
				'maintenance'   => $maintenance,
				'status'   		=> $status,
				'encash_from'   => 'Received CFC WS Rewards',
				'date_created'  => date('Y-m-d H:i:s'),
				'transfered_by' => $account_id,
				'receiver_name' => null
			);
		} else if($post['transfer_from'] == "CFC WS Received Rewards") {

			if((($money->received_affiliate_shares) - ($money->withdrawn_affiliate_share_2 + $money->transfered_affiliate_shares_2)) < $post['amount'])	{
				echo json_encode("Error: Insufficient funds. Current Fund: " . (($money->received_affiliate_shares) - ($money->withdrawn_affiliate_share_2 + $money->transfered_affiliate_shares_2)));
				exit();
			} 

			$this->Money_model->received_affiliate_shares(array(($post['amount']-( 5+$maintenance )),$post['receiver_id']));
			$this->Money_model->transfer_affiliate_shares_2(array($post['amount'],$maintenance,$account_id));

			$transaction_params[] = array(
				'account_id'    => $account_id,
				'amount'        => $post['amount'],
				'maintenance'   => $maintenance,
				'status'   		=> $status,
				'encash_from'   => 'Transfer CFC WS Rewards [2]',
				'date_created'  => date('Y-m-d H:i:s'),
				'transfered_by' => null,
				'receiver_name' => $post['receiver_id']
			);

			$transaction_params[] = array(
				'account_id'    => $post['receiver_id'],
				'amount'        => $post['amount'],
				'maintenance'   => $maintenance,
				'status'   		=> $status,
				'encash_from'   => 'Received CFC WS Rewards [2]',
				'date_created'  => date('Y-m-d H:i:s'),
				'transfered_by' => $account_id,
				'receiver_name' => null
			);
		} else if($post['transfer_from'] == "Forex Unilevel") {
			if( (($money->forex_referral + $money->received_forex_referral) - ($money->transferred_forex_referral-$money->withdrawn_forex_referral)) < $post['amount'] )	{
				echo json_encode("Error: Insufficient funds. Current fund: " . (($money->forex_referral + $money->received_forex_referral) - ($money->transferred_forex_referral-$money->withdrawn_forex_referral)) );
				exit();
			}

			$this->Money_model->received_forex_referral(array(($post['amount']-( 5+$maintenance )),$post['receiver_id']));
			$this->Money_model->transfer_forex_referral(array($post['amount'],$maintenance,$account_id));

			$transaction_params[] = array(
				'account_id'    => $account_id,
				'amount'        => $post['amount'],
				'maintenance'   => $maintenance,
				'status'   		=> $status,
				'encash_from'   => 'Transfer Forex Unilevel',
				'date_created'  => date('Y-m-d H:i:s'),
				'transfered_by' => null,
				'receiver_name' => $post['receiver_id']
			);

			$transaction_params[] = array(
				'account_id'    => $post['receiver_id'],
				'amount'        => $post['amount'],
				'maintenance'   => $maintenance,
				'status'   		=> $status,
				'encash_from'   => 'Received Forex Unilevel',
				'date_created'  => date('Y-m-d H:i:s'),
				'transfered_by' => $account_id,
				'receiver_name' => null
			);
		} else {
			echo json_encode("Error: Unknown transaction type.");
			exit();
		}

		$this->Transactions_model->add_batch_transaction($transaction_params);
		$this->add_money_logs($account_id, $post['amount'], "Transfer from ".$post['transfer_from']);

		$data = array(
			'account_id'  => $post['receiver_id'],
			'amount'      => $post['amount']-( 5+$maintenance ),
			'description' => "Received (" .$post['transfer_from']. ") from ".$this->session->userdata('username'),
			'date'        => date('Y-m-d H:i:s')
		);
		$this->Money_model->add_logs($data);

		echo json_encode("Success!");
	}

    public function transfer_pincodes()
    {
        $post                = $this->input->post();
        $post['transfer_to'] = trim($post['transfer_to']);

        if($this->Account_model->get_account_from_id($post['transfer_to'])) {
            $post['account_id'] = array_filter(explode("-", $post['account_id']));
            $post['cfc_id'] = array_filter(explode("-", $post['cfc_id']));

            if(empty($post['account_id']) && empty($post['cfc_id'])){
                $message      = 'Invalid! Please check pincodes for transfer';
                $message_type = 'warning';
            } else {
	            if($post['account_id']) {
	                foreach($post['account_id'] as $row) {
	                    $this->Register_pins_model->update_pin($row,array('transfer_to' => $post['transfer_to']));
	                    $transfer_params = array(
	                        'transfer_to'     => $post['transfer_to'],
	                        'transfer_from ' => $this->session->userdata()['user_id'],
	                        'pincode_id'      => $row,
	                        'pincode_type'    => 'Account Pin'
	                    );
	                    $this->Register_pins_model->pin_transfer_logs($transfer_params);
	                }
                }
	            if($post['cfc_id']) {
	                foreach($post['cfc_id'] as $row) {
	                    $this->Affiliate_shares_model->update_pin($row,array('transfer_to' => $post['transfer_to']));
	                    $transfer_params = array(
	                        'transfer_to'   => $post['transfer_to'],
	                        'transfer_from' => $this->session->userdata()['user_id'],
	                        'pincode_id'    => $row,
	                        'pincode_type'  => 'CFC WS Pin'
	                    );
	                    $this->Register_pins_model->pin_transfer_logs($transfer_params);
	                }
                }

                $message      = 'Success';
                $message_type = 'success';
            }
        } else {
            $message      = 'Invalid Account ID';
            $message_type = 'warning';
        }
        $user_id = $this->session->userdata()['user_id'];

        $data['bought_account_pincodes'] = $this->Transactions_model->get_bought_pincodes_available("register_pins", array($user_id,$user_id));
        $data['bought_cfc_pincodes'] = $this->Transactions_model->get_bought_pincodes_available("affiliate_shares_pin", array($user_id,$user_id));

        echo json_encode(
            array(
                'account_table' => $this->load->view('transactions/buy_account_pincodes_table',$data,true),
                'cfc_table'     => $this->load->view('transactions/buy_cfc_pincodes_table',$data,true),
                'message'       => $message,
                'message_type'  => $message_type
            )
        );
    }

	public function set_transfer_password()
	{
		$post = array_map("trim", $this->input->post());
		$this->Account_model->update_account($this->session->userdata()['user_id'] ,array("transfer_password" => $post['new_password']));

		echo 'Success';
	}

	public function reset_transfer_password()
	{
		$post = array_map("trim", $this->input->post());
		$account = $this->Account_model->get_account_from_id($this->session->userdata('user_id'));
		if(!$account){
			echo "Account not found.";
		} else {
			//Generate Random New Password
			$possibleChars  = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
			$new_password = '';
			for($i = 0; $i < 8; $i++) {
				$rand = rand(0, strlen($possibleChars) - 1);
				$new_password .= substr($possibleChars, $rand, 1);
			}

			$this->load->library('EmailerPHP');
			$mail = new EmailerPHP;

			$data['message'] = "This account's transfer password has been reset. Please transfer rewards with the new password. <br>Username: ".$account->username."<br>New Transfer Password: " . $new_password;

			if($account->email_address == null){
				//Send email to admin email
				$mail->addAddress("admin@cfcteam.org"); 
			}else{
				//Send email to user email
				$mail->addAddress($account->email_address); 
				$mail->AddBCC("admin@cfcteam.org");
			}

			$body = $this->load->view('template/email_template',$data,true);
			$mail->Subject = 'CFC Team - Transfer Password Reset';
			$mail->Body    = $body;
			$mail->send();

			if($this->Account_model->update_account($account->account_id ,array("transfer_password" => $new_password))){
				echo 'Success';
			}
		}
	}

	public function money_logs() {
		$data = array(
			'title'	  => 'Money Logs', 
            'content' => 'transactions/money_logs_view',
			'result'  => $this->Money_model->get_logs($this->session->userdata('user_id'))
		);
		$this->load->view('template/template',$data);
	}

	public function filter_accounting_transactions()
	{
		$post = array_map("trim", $this->input->post());
		$data['result'] = $this->Transactions_model->filter_accounting_transactions($post['ttype'],$post['status'],$this->session->userdata('user_id'));
		echo $this->load->view('transactions/encash_history_table',$data,true);
	}
}