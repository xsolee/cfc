<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Pins extends CI_Controller {

	public function __construct() {

		parent::__construct();

		$this->load->library('session');
		if ( $this->session->userdata('user_id') != "0000001" ) {
			redirect('dashboard');
		}
		$this->load->model(array('Register_pins_model','Affiliate_shares_model','Forex_pins_model'));
		date_default_timezone_set('Asia/Manila');
	}

	public function generate_pins() {

		$data = array(
			'title'    => 'Generate Account Pins', 
            'content' => 'pins/generate_pins_view',
            'result'  => $this->Register_pins_model->get_all_PINs()
		);

		$this->load->view('template/template',$data);
	}

	public function generated_pins() {

		$post = $this->input->post();

		$possibleChars 	   = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
        $pin1              = '';
        $pin2              = '';
        $pin1_length       = 8;
        $pin2_length       = 6;
        $ctr               = 0;
        $generated_pin     = array();
        $duplicate_entries = array();
        $created_date = date('Y-m-d H:i:s');

        while($post['no_of_pin'] != $ctr) {

        	for($i = 0; $i < $pin1_length; $i++) {
	            $rand = rand(0, strlen($possibleChars) - 1);
	            $pin1 .= substr($possibleChars, $rand, 1);
	        }

	        for($i = 0; $i < $pin2_length; $i++) {
	            $rand = rand(0, strlen($possibleChars) - 1);
	            $pin2 .= substr($possibleChars, $rand, 1);
	        }

	        $validate_pin = $this->Register_pins_model->validate_pin_if_exist(array($pin1,$pin2));

	        if(!$validate_pin) {
	        	array_push($generated_pin, array('pin1' => $pin1, 'pin2' => $pin2));
		        $ctr++;

		        if(count(array_unique($generated_pin, SORT_REGULAR)) != count($generated_pin)) {
		        	$ctr--;
		        }
	        }

	        $pin1 = '';
			$pin2 = '';
        }

        foreach(array_unique($generated_pin, SORT_REGULAR) as $row) {
        	$this->Register_pins_model->save_pins(array('PIN1' => $row['pin1'], 'PIN2' => $row['pin2'], 'bought_by' => $this->session->userdata('user_id'), 'date_created'=>$created_date ));
        }

        $data['result'] = $this->Register_pins_model->get_all_PINs();
		echo json_encode(
            array(
                'table'        => $this->load->view('pins/registered_pins_table',$data,true),
                'created_date' => $created_date
            )
        );

	}

	public function save_generated_pins() {

		$post = $this->input->post();

		$this->Register_pins_model->save_pins($post);

		echo json_encode('Success');
	}

	public function generate_affiliate_shares_pin() {
		
		$data = array(
			'title'    => 'Generate CFC WS Reward Pins', 
            'content'  => 'pins/generate_affiliate_shares_pin_view',
            'result'  => $this->Affiliate_shares_model->get_all_PINs()
		);

		$this->load->view('template/template',$data);
	}

	public function generated_affiliate_shares_pin() {

		$post = $this->input->post();
        $created_date = date('Y-m-d H:i:s');

		if($post['no_of_shares'] == 0) {
			$post['no_of_shares'] = 0.5;
		}

		$possibleChars  = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
        $pin               = '';
        $pin_length        = 10;
        $ctr               = 0;
        $generated_pin     = array();
        $duplicate_entries = array();


        while(1 != $ctr) {

        	for($i = 0; $i < $pin_length; $i++) {
	            $rand = rand(0, strlen($possibleChars) - 1);
	            $pin .= substr($possibleChars, $rand, 1);
	        }
	        
	        $validate_pin = $this->Affiliate_shares_model->check_PIN(array($pin));

	        if(!$validate_pin) {
	        	array_push($generated_pin, array('pin' => $pin, 'no_of_shares' => $post['no_of_shares']));
		        $ctr++;

		        if(count(array_unique($generated_pin, SORT_REGULAR)) != count($generated_pin)) {
		        	$ctr--;
		        }
	        }

	        $pin = '';
        }

        foreach(array_unique($generated_pin, SORT_REGULAR) as $row) {
        	$this->Affiliate_shares_model->save_pin(array('pin' => $row['pin'], 'no_of_share' => $row['no_of_shares'], 'bought_by' => $this->session->userdata('user_id'), 'created_date'=>$created_date));
        }

        $data['result'] = $this->Affiliate_shares_model->get_all_PINs();

		echo json_encode(
            array(
                'table'        => $this->load->view('pins/affiliate_shares_pin_table',$data,true),
                'created_date' => $created_date
            )
        );

	}

	public function save_generated_affiliate_shares_pin() {

		$post = $this->input->post();

		$this->Affiliate_shares_model->save_pin($post);

		echo json_encode('Success');

	}

    public function export_account_pins($created_date = null)
    {
    	$created_date = urldecode($created_date);
        $result = $this->Register_pins_model->get_all_PINs_by_date($created_date);
        $result = json_decode(json_encode($result), true);

        $this->load->library('excel');
        $styleArray = array(
            'borders' => array(
                'allborders' => array(
                    'style' => PHPExcel_Style_Border::BORDER_THIN
                )
            ),

            'font'  => array(
                'bold'  => false,
                'size'  => 12,
                'name'  => 'Calibri'
            ),

            'alignment' => array(
                'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
            )
        );

        $row         = count($result) + 1;
        $objPHPExcel = PHPExcel_IOFactory::load("././resources/report_template/account_pincodes_template.xlsx");
        $objPHPExcel->setActiveSheetIndex(0);

        $objPHPExcel->getActiveSheet()->fromArray($result,null, 'A2');
        $objPHPExcel->getActiveSheet()->getStyle(
            'A2:' . 
            'B' . 
            $row
        )->applyFromArray($styleArray);

        $objWriter = new PHPExcel_Writer_Excel2007($objPHPExcel);
        $filename  = 'account_pincodes_'.date('Y-m-d', strtotime($created_date)).'.xls';
 
        header('Content-Type: application/vnd.ms-excel');
        header('Content-Disposition: attachment;filename="'.$filename.'"');
        header('Cache-Control: max-age=0');
 
        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
        $objWriter->save('php://output');
    }

    public function export_cfcws_pins($created_date = null)
    {
    	$created_date = urldecode($created_date);
        $result = $this->Affiliate_shares_model->get_all_PINs_by_date($created_date);
        $result = json_decode(json_encode($result), true);

        $this->load->library('excel');
        $styleArray = array(
            'borders' => array(
                'allborders' => array(
                    'style' => PHPExcel_Style_Border::BORDER_THIN
                )
            ),

            'font'  => array(
                'bold'  => false,
                'size'  => 12,
                'name'  => 'Calibri'
            ),

            'alignment' => array(
                'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
            )
        );

        $row         = count($result) + 1;
        $objPHPExcel = PHPExcel_IOFactory::load("././resources/report_template/cfcws_pincodes_template.xlsx");
        $objPHPExcel->setActiveSheetIndex(0);

        $objPHPExcel->getActiveSheet()->fromArray($result,null, 'A2');
        $objPHPExcel->getActiveSheet()->getStyle(
            'A2:' . 
            'B' . 
            $row
        )->applyFromArray($styleArray);

        $objWriter = new PHPExcel_Writer_Excel2007($objPHPExcel);
        $filename  = 'cfcws_pincodes_'.date('Y-m-d', strtotime($created_date)).'.xls';
 
        header('Content-Type: application/vnd.ms-excel');
        header('Content-Disposition: attachment;filename="'.$filename.'"');
        header('Cache-Control: max-age=0');
 
        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
        $objWriter->save('php://output');
    }

    public function forex_pins() {
        
        $data = array(
            'title'    => 'Generate Forex Pins', 
            'content'  => 'pins/forex_pins_view',
            'result'  => $this->Forex_pins_model->get_all_PINs()
        );

        $this->load->view('template/template',$data);
    }

    public function generate_forex_pins() {
        $post = array_map("trim", $this->input->post());

        $possibleChars     = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
        $pin               = '';
        $pin_length        = 10;
        $ctr               = 0;
        $generated_pin     = array();
        $duplicate_entries = array();
        $created_date      = date('Y-m-d H:i:s');

        while($post['no_of_pin'] != $ctr) {

            for($i = 0; $i < $pin_length; $i++) {
                $rand = rand(0, strlen($possibleChars) - 1);
                $pin .= substr($possibleChars, $rand, 1);
            }

            $validate_pin = $this->Forex_pins_model->validate_pin_if_exist($pin);

            if(!$validate_pin) {
                array_push($generated_pin, array('pin' => $pin));
                $ctr++;

                if(count(array_unique($generated_pin, SORT_REGULAR)) != count($generated_pin)) {
                    $ctr--;
                }
            }

            $pin = '';
        }

        foreach(array_unique($generated_pin, SORT_REGULAR) as $row) {
            $this->Forex_pins_model->save_pins(array('pin' => $row['pin'], 'bought_by' => $this->session->userdata('user_id'), 'date_created'=>$created_date ));
        }

        $data['result'] = $this->Forex_pins_model->get_all_PINs();
        echo json_encode(
            array(
                'table'        => $this->load->view('pins/forex_pins_table',$data,true),
                'created_date' => $created_date
            )
        );
    }
}