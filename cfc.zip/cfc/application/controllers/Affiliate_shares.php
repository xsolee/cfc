<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Affiliate_Shares extends CI_Controller {
	public function __construct() {
		parent::__construct();
		$this->load->library('session');
		$this->load->model(array('Account_model','Token_gaming_model','Money_model','affiliate_shares_model'));
		date_default_timezone_set('Asia/Manila');
	}

	public function investment() {

		$money  = $this->Money_model->get_money_details($this->session->userdata('user_id'));
		$result = $this->affiliate_shares_model->get_affiliate_shares($this->session->userdata()['user_id']);
		$current_rate = $this->affiliate_shares_model->get_cfc_ws_current_rate(array(date('M'), date('Y')));

		$data = array(
			'title'   => 'Cfc WS Products',
            'content'             => 'affiliate_share/investment_view',
            'result'              => $result,
            'money'               => $money,
            'cfc_ws_current_rate' => $current_rate->total_rate
		);
		$this->load->view('template/template',$data);
	}

	public function invest() {
		$this->update_can_invest($this->session->userdata('lastname'), $this->session->userdata('firstname'), $this->session->userdata('middlename'));
		$account = $this->Account_model->get_account_from_id($this->session->userdata('user_id'));

		$post = $this->input->post();
		if($post['no_of_share'] == 0) {
			$post['no_of_share'] = 0.5;
		}
		$flag_exist   = 0;
		$validate_pin = $this->affiliate_shares_model->check_pin_unused(array($post['pin'], $post['no_of_share']));

		if($account->can_invest){
			if($validate_pin) {

				$post['account_id']    = $this->session->userdata()['user_id'];
				$post['shares_amount'] = str_replace(',',"",$post['shares_amount']);
				$post['daily_profit']  = str_replace(',',"",$post['daily_profit']);
				$post['total_income']  = str_replace(',',"",$post['total_income']);
				$post['due_date']      = date('Y-m-d', strtotime(date('Y-m-d'). ' + 365 days'));
				$post['created_date']  = date('Y-m-d H:i:s');

				$validate_shares_amount = $this->affiliate_shares_model->validate_affiliate_shares_amount_exceeded($this->session->userdata()['user_id']);

				if(($validate_shares_amount + $post['shares_amount']) <= 1000) {
				
					$this->affiliate_shares_model->save_affiliate_shares($post);
					$this->affiliate_shares_model->update_affiliate_shares_pin(array(date('Y-m-d'),$this->session->userdata()['user_id'],$post['pin']));

					// $account = $this->Account_model->get_account_from_id($this->session->userdata()['user_id']);
					if($account->sponsor_ID != null) $this->Money_model->add_affiliate_share_unilevel($post['no_of_share'], $account->sponsor_ID, $account->account_id);
					$this->Token_gaming_model->add_free_token(array($post['no_of_share'], $account->account_id));
					// $this->generate_free_token($post['no_of_share']);
					$message = 'Success';
				} else {
					$message = 'Shares amount exceeded 1000. Current shares is: ' . $validate_shares_amount;
				}
			} else {
				$message = 'Invalid Pin/No of Account';
			}
		} else {
			$message = 'This account isn\'t allowed for escrow yet. Use previous accounts first.';
		}


		$money  = $this->Money_model->get_money_details($this->session->userdata('user_id'));


		//echo json_encode($flag_exist);
		//$data['result'] = $this->affiliate_shares_model->get_affiliate_shares($this->session->userdata()['user_id']);

		$data = array(
			'result' => $this->affiliate_shares_model->get_affiliate_shares($this->session->userdata()['user_id']),
			'total'     => $money->total_affiliate_share,
            'money' => $money
		);
		echo json_encode(
			array(
				'table'   => $this->load->view('affiliate_share/investment_table',$data,true),
				'message' => $message
				
			)
		);
	}

	public function generate_free_token($no_of_token = 1) {
		$account_id = $this->session->userdata('account_id');

		$possibleChars        = "1234567890";
		$serial_number_length = 9;
		$serial_number        = '';

		$token_headers = $this->Token_gaming_model->get_current_by_batch_id(1);

		$generate_token   = array();
		$generated_tokens = array();
		$ctr              = 0;

		if(($token_headers->token_count + $no_of_token) > 148824) {
			$this->Token_gaming_model->end_game($token_headers->id);	//ends game and adds new header
			$token_headers = $this->Token_gaming_model->get_current_by_batch_id(1);
		}

		while($no_of_token != $ctr) {

			for($i = 0; $i < $serial_number_length; $i++) {
	            $rand = rand(0, strlen($possibleChars) - 1);
	            $serial_number .= substr($possibleChars, $rand, 1);
	        }

			$generate_token         = $this->randomGen(1,54,3);
			$validate_token         = $this->Token_gaming_model->validate_token($generate_token,$token_headers->id);
			$validate_serial_number = $this->Token_gaming_model->validate_serial_number($serial_number);

			if(!$validate_token && !$validate_serial_number) {
				array_push($generate_token, $serial_number);
	        	array_push($generated_tokens, $generate_token);
		        $ctr++;

		        if(count(array_unique($generated_tokens, SORT_REGULAR)) != count($generated_tokens)) {
		        	$ctr--;
		        }
	        }

	        $serial_number = '';
		}

		foreach(array_unique($generated_tokens, SORT_REGULAR) as $row) {
        	$this->Token_gaming_model->insert_token(
        		array(
	        		'header_id'     => $token_headers->id, 
	        		'account_id'    => $account_id,
	        		'serial_number' => $row[3],
	        		'created_date'  => date('Y-m-d'),
	        		'combination1'  => $row[0],
	        		'combination2'  => $row[1],
	        		'combination3'  => $row[2]
        		)
        	);
        }

        $update_header_params = array(
        	'token_count' => $token_headers->token_count + count(array_unique($generated_tokens, SORT_REGULAR))
        );
        $this->Token_gaming_model->update_header($token_headers->id,$update_header_params);

		$data = array(
			'account_id'  => $account_id,
			'debit'       => 0,
			'description' => 'Received '.$no_of_token.' FREE Gold token',
			'date'        => date('Y-m-d H:i:s')
		);
		$this->Money_model->add_logs($data);

		return true;
	}

	function randomGen($min, $max, $quantity) {
	    $numbers = range($min, $max);
	    shuffle($numbers);
	    return array_slice($numbers, 0, $quantity);
	}

	public function auto_invest() {

		$reinvest_total = 0;
		$list_account_id = $this->affiliate_shares_model->get_account_for_reinvest();

		foreach($list_account_id as $account) {
			$no_of_share    = 0;
			$reinvest_total = 0;

			// $this->Money_model->update_affiliate_share_total_income_per_day($account->account_id);
			$this->Money_model->update_total_affiliate_share($account->account_id);
			$current_rate = $this->affiliate_shares_model->get_cfc_ws_current_rate(array(date('M'), date('Y')));

			$account_details    = $this->affiliate_shares_model->get_account_for_reinvest_by_account_id($account->account_id);
			$money_details      = $this->Money_model->get_money_details($account_details->account_id);
			$available_reinvest = $account_details->total_income_per_day - ($money_details->withdrawn_affiliate_share + $money_details->reinvest_affiliate_shares + $money_details->transfered_affiliate_shares);
			$no_of_share        = floor($available_reinvest / 100);
			$reinvest_total     = ($no_of_share * 100);
		
			if($reinvest_total > 0) {
				$reinvest_params = array(
					'account_id'    => $account_details->account_id,
					'no_of_share'   => $reinvest_total / 100,
					'shares_amount' => $reinvest_total,
					'daily_profit'  => ($reinvest_total / 100) * $current_rate->total_rate,
					'total_income'  => (($reinvest_total / 100) * $current_rate->total_rate) * 365,
					'due_date'      => date('Y-m-d', strtotime(date('Y-m-d'). ' + 365 days')),
					'invest_type'   => 'Automated',
					'created_date'  => date('Y-m-d H:i:s')
				);

				$this->affiliate_shares_model->save_affiliate_shares($reinvest_params);


				$this->Money_model->update_money($account_details->account_id,array('reinvest_affiliate_shares' => $money_details->reinvest_affiliate_shares + $reinvest_total));
				$account = $this->Account_model->get_account_from_id($account_details->account_id);
				if($account->sponsor_ID != null) $this->Money_model->add_affiliate_share_unilevel(($reinvest_total / 100), $account->sponsor_ID, $account->account_id);
				//$this->Money_model->update_total_affiliate_share($account->account_id);

				$data = array(
					'account_id'  => $account->account_id,
					'debit'       => $reinvest_total,
					'description' => 'Auto reinvest affiliate shares',
					'date'        => date('Y-m-d H:i:s')
				);
				$this->Money_model->add_logs($data);
			}
		}
	}

	public function manage_cfc_ws_rates() {
		$all_rates = $this->affiliate_shares_model->get_cfc_ws_all_rate();
		$data = array(
            'content'   => 'affiliate_share/cfc_ws_rates_view',
            'all_rates' => $all_rates
		);
		$this->load->view('template/template',$data);
	}

	public function cfc_ws_daily_rates() {
		$all_rates = $this->affiliate_shares_model->get_cfc_ws_header_lines();
		$data = array(
            'content'   => 'affiliate_share/cfc_ws_header_lines_view',
            'all_rates' => $all_rates
		);
		$this->load->view('template/template',$data);
	}

	public function change_cfc_ws_rate() {
		$post = array_map("trim", $this->input->post());

		$month = date('M',strtotime($post['date']));
		$year = date('Y',strtotime($post['date']));

		$header_id = $this->affiliate_shares_model->change_cfc_ws_rate(array('month'=>$month, 'year'=>$year, 'total_rate' => $post['total_rate']));

		//update cfc ws daily rate
		$this->compute_cfc_ws_daily($header_id);
		
		$data['all_rates'] = $this->affiliate_shares_model->get_cfc_ws_all_rate();
		echo $this->load->view('affiliate_share/cfc_ws_rates_table',$data,true);
	}

	function rand_float($st_num=0,$end_num=1,$mul=100) {
		if ($st_num>$end_num) return false;
		return mt_rand($st_num*$mul,$end_num*$mul)/$mul;
	}

	public function compute_cfc_ws_daily($header_id=null) {
		if($header_id)
			$current_rate = $this->affiliate_shares_model->get_cfc_ws_current_rate_by_id($header_id);
		else 
			$current_rate = $this->affiliate_shares_model->get_cfc_ws_current_rate(array(date('M'), date('Y')));
		$days_of_month	= date('t', strtotime($current_rate->month." ".$current_rate->year));
		$random_daily_rates = $this->randomize_daily_rate($days_of_month,$current_rate->total_rate);
		$daily_rates = array();
		
		foreach ($random_daily_rates as $key => $value) {
			$daily_rates[] = array(
				'header_id' => $current_rate->id, 
				'day' => $key+1, 
				'rate' => $value
			);
		}

		$this->affiliate_shares_model->update_cfc_ws_daily_rates($daily_rates);
	}

	function randomize_daily_rate($days=0, $total_rate=0, $min_rate=0.02, $max_rate=2) {
		$daily_rates = array();
		$day = 0;

		while(array_sum($daily_rates) != $total_rate)
		{
			if( $total_rate<20 ){
				$max_rate = $total_rate/mt_rand(1,$days);
				while( $max_rate>2 ){ $max_rate = $total_rate/mt_rand(1,$days); }
			}

			$daily_rates[$day] = $this->rand_float($min_rate,$max_rate,100);

			if(++$day == $days)  $day  = 0;
		}
		return $daily_rates;
	}

	function cfc_ws_daily_to_total_rate($header_id) {
		$daily_rates = $this->affiliate_shares_model->get_cfc_ws_lines_by_header_id($header_id);

		$total = array_sum(array_column($daily_rates, 'rate'));
		echo $total."<br>";
		print_r(array_column($daily_rates, 'rate'));
	}

	function update_can_invest($last_name, $first_name, $middle_name = NULL) {
		$subaccounts = $this->Account_model->get_subaccounts(array($last_name, $first_name, $middle_name), $middle_name);

		for ($i=1; $i < count($subaccounts); $i++) { 
			if($subaccounts[$i]->can_invest){
				continue;
			} else {	//can_invest = 0
				if($subaccounts[$i-1]->can_invest){	//if previous account can invest, check if they have existing cfc ws
					if($this->affiliate_shares_model->get_affiliate_shares($subaccounts[$i-1]->account_id)){	//has cfc ws thus $subaccounts[$i] can invest
						$this->Account_model->update_account($subaccounts[$i]->account_id, array("can_invest"=>1));
					} else { //no cfc ws thus $subaccounts[$i] cannot invest
						break;
					}
				}
			}
		}
	}

	public function update_cfc_ws_all() {

		$this->affiliate_shares_model->update_cfc_ws_total_income_per_day_all();
		$this->affiliate_shares_model->update_total_affiliate_share_all();
	}

	public function update_daily_cfc_income() {

		$result = $this->affiliate_shares_model->get_all_active_affiliate_shares();

		$current_rate = $this->affiliate_shares_model->get_current_rate_today();
		if(!$current_rate) {
			$total_rate = $this->affiliate_shares_model->get_cfc_ws_current_rate(array(date('M'), date('Y')));
			if(!$total_rate) {
				$header_id = $this->affiliate_shares_model->change_cfc_ws_rate(array('month'=>date('M'), 'year'=>date('Y'), 'total_rate' => 20));
				$total_rate = $this->affiliate_shares_model->get_cfc_ws_current_rate(array(date('M'), date('Y')));
			}
			$this->compute_cfc_ws_daily($total_rate->id);
			$current_rate = $this->affiliate_shares_model->get_current_rate_today();
		}

		$current_rate = $current_rate->day_rate;

		foreach($result as $row) {

			$add_rate = $row->no_of_share * $current_rate;

			$update_params = array(
				'total_income_per_day' => $row->total_income_per_day + $add_rate
			);

			$this->affiliate_shares_model->update_affiliate_shares($update_params,$row->id);

			$money_logs_params = array(
				'account_id'  => $row->account_id,
				'amount'      => $add_rate,
				'description' => "Received CFC WS Rewards. Current rate (" . $current_rate . ")",
				'date'        => date('Y-m-d H:i:s')
			);

			$this->Money_model->add_logs($money_logs_params);
		}

	}
}