<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Money extends CI_Controller {
	public function __construct() {
		parent::__construct();
		$this->load->library('session');
		$this->load->model(array('Account_model','Money_model','Referrals_model','Forex_pins_model'));
		date_default_timezone_set('Asia/Manila');
	}
	public function add_forex_unilevel()
	{
		/*if(in_array(date('d'), array(10,25))) {	
			$rates = $this->Money_model->get_forex_referral_rate();	//as array
			$referrals = $this->Referrals_model->get_all_forex_referrals();

			foreach ($referrals as $key => $referral) {
				$sponsor_unilevel = explode( "-", $referral->forex_unilevel );
			}
		}
*/
		/*echo "<pre>";
		print_r($sponsor_unilevel);
		exit();*/

		//think of algo
	}

}