<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Token_gaming extends CI_Controller {
	public function __construct() {
		parent::__construct();
		$this->load->library('session');
		if ( ! $this->session->userdata('user_id')) {
			redirect('Account/login');
		}
		$this->load->model(array('Account_model','Token_gaming_model','Money_model','affiliate_shares_model','Transactions_model','Affiliate_shares_model'));
		date_default_timezone_set('Asia/Manila');
	}

	public function view_games() {
		// if($this->session->userdata('raffle_session')->id != 1) redirect('dashboard');
		$data = array(
			'title'   => 'CFC Exclusive', 
            'content' => 'token/token_gaming_view',
			'result' => $this->Token_gaming_model->get_all_headers()
		);
		$this->load->view('template/template',$data);

	}

	public function avail_token() {

		$user_id    = $this->session->userdata('user_id');
		$account_id = $this->session->userdata('account_id');

		$money   = $this->Money_model->get_money_details($user_id);
		
		// $affiliate_shares      = $this->Affiliate_shares_model->get_active_affiliate_shares($user_id);
		// $total_affiliate_share = 0;

		// foreach($affiliate_shares as $affiliate_share) {
		// 	$date = date('Y-m-d',strtotime($affiliate_share->created_date));
		// 	$days_invested = (new DateTime())->diff(new DateTime($date))->days;
		// 	$total_affiliate_share += $days_invested*$affiliate_share->daily_profit;
		// }

		$data = array(
			'title'   => 'CFC Exclusive Tokens', 
            'content'               => 'token/token_view',
            'money'                 => $money,
            'token_headers'         => $this->Token_gaming_model->get_current(),
            'result'                => $this->Token_gaming_model->get_token_by_account_id($account_id),
            'current_free_token'    => $money->free_token,
            'current_rewards'       => ($money->current_bonus),
            'current_cfc_ws'        => $money->total_affiliate_share-($money->withdrawn_affiliate_share+$money->reinvest_affiliate_shares+$money->transfered_affiliate_shares),
            'current_cfc_exclusive' => (($money->cfc_exclusive + $money->cfc_exclusive_referral + $money->received_cfc_exclusive) - ($money->withdrawn_cfc_exclusive + $money->transfered_cfc_exclusive))
		);

		$this->load->view('template/template',$data);
	}

	public function generate_token()
	{
		$post       = $this->input->post();
		$post['total_amount'] = str_replace(',',"",$post['total_amount']);

		$account_id = $this->session->userdata('account_id');

		$possibleChars        = "1234567890";
		$serial_number_length = 9;
		$serial_number        = '';

		$current_rewards = $this->Money_model->get_money_details($account_id);

		$token_headers = $this->Token_gaming_model->get_current_by_batch_id($post['token_type']);

		if($token_headers->batch_id == 1) {
			$token_description = 'Gold';
		} else {
			$token_description = 'Diamond';
		}

		$generate_token   = array();
		$generated_tokens = array();
		$ctr              = 0;



		if($post['rewards_type'] == 'Rewards') {
        	if((($current_rewards->current_bonus) - $post['total_amount']) < 0) {
				echo json_encode(
					array(
						'message' => 'Not enough rewards!'
					)
				);
				exit();
			}	
        } else if($post['rewards_type'] == 'CFC WS') {

   //      	$affiliate_shares      = $this->Affiliate_shares_model->get_active_affiliate_shares($this->session->userdata('user_id'));
			// $total_affiliate_share = 0;

   //      	foreach($affiliate_shares as $affiliate_share) {
			// 	$date = date('Y-m-d',strtotime($affiliate_share->created_date));
			// 	$days_invested = (new DateTime())->diff(new DateTime($date))->days;
			// 	$total_affiliate_share += $days_invested*$affiliate_share->daily_profit;
			// }

        	if((($current_rewards->total_affiliate_share-($current_rewards->withdrawn_affiliate_share+$current_rewards->reinvest_affiliate_shares+$current_rewards->transfered_affiliate_shares)) - $post['total_amount']) < 0) {
				echo json_encode(
					array(
						'message' => 'Not enough CFC WS!'
					)
				);
				exit();
			}
        } else if($post['rewards_type'] == 'CFC Exclusive') {


        	if((((($current_rewards->cfc_exclusive + $current_rewards->cfc_exclusive_referral + $current_rewards->received_cfc_exclusive) - ($current_rewards->withdrawn_cfc_exclusive + $current_rewards->transfered_cfc_exclusive))) - $post['total_amount']) < 0) {
				echo json_encode(
					array(
						'message' => 'Not enough CFC Exclusive!'
					)
				);
				exit();
			}
        } else if($post['rewards_type'] == 'Free Token') {
        	if((($current_rewards->free_token) - $post['total_amount']) < 0) {
				echo json_encode(
					array(
						'message' => 'Not enough free token!'
					)
				);
				exit();
			} else if($token_headers->batch_id != 1) {
				echo json_encode(
					array(
						'message' => 'Only gold tokens can be used for free tokens!'
					)
				);
				exit();
			}
        } else {
        	echo json_encode(
				array(
					'message' => 'Unknown Rewards Type!'
				)
			);
			exit();
        }

		

		if(($token_headers->token_count + $post['no_of_token']) > 148824) {
			$this->Token_gaming_model->end_game($token_headers->id);	//ends game and adds new header

			echo json_encode(
				array(
					'message' => 'Not enough tokens! Available Tokens: ' .  (148824 - ($token_headers->token_count))
				)
			);
			exit();
		}

		while($post['no_of_token'] != $ctr) {

			for($i = 0; $i < $serial_number_length; $i++) {
	            $rand = rand(0, strlen($possibleChars) - 1);
	            $serial_number .= substr($possibleChars, $rand, 1);
	        }

			$generate_token         = $this->randomGen(1,54,3);
			$validate_token         = $this->Token_gaming_model->validate_token($generate_token,$token_headers->id);
			$validate_serial_number = $this->Token_gaming_model->validate_serial_number($serial_number);

			if(!$validate_token && !$validate_serial_number) {
				array_push($generate_token, $serial_number);
	        	array_push($generated_tokens, $generate_token);
		        $ctr++;

		        if(count(array_unique($generated_tokens, SORT_REGULAR)) != count($generated_tokens)) {
		        	$ctr--;
		        }
	        }

	        $serial_number = '';
		}

		foreach(array_unique($generated_tokens, SORT_REGULAR) as $row) {
        	$this->Token_gaming_model->insert_token(
        		array(
	        		'header_id'     => $token_headers->id, 
	        		'account_id'    => $this->session->userdata('user_id'),
	        		'serial_number' => $row[3],
	        		'created_date'  => date('Y-m-d'),
	        		'combination1'  => $row[0],
	        		'combination2'  => $row[1],
	        		'combination3'  => $row[2]
        		)
        	);
        }

        $update_header_params = array(
        	'token_count' => $token_headers->token_count + count(array_unique($generated_tokens, SORT_REGULAR))
        );
        $this->Token_gaming_model->update_header($token_headers->id,$update_header_params);

        $transaction_params = array(
        	'account_id'   => $account_id,
        	'amount'       => $post['total_amount'],
        	'encash_from'  => 'Bought ' . $token_description . ' tokens using ' . $post['rewards_type'],
        	'date_created' => date('Y-m-d H:i:s'),
        );

        $this->Transactions_model->add_transaction($transaction_params);

        if($post['rewards_type'] == 'Rewards') {
        	$this->Money_model->withdraw_bonus(array($post['total_amount'], 0, $account_id));		
        } else if($post['rewards_type'] == 'CFC WS') {
        	$this->Money_model->withdraw_affiliate_share(array($post['total_amount'], 0, $account_id));
        } else if($post['rewards_type'] == 'CFC Exclusive') {
        	$this->Money_model->withdraw_cfc_exclusive(array($post['total_amount'], 0, $account_id));
        } else if($post['rewards_type'] == 'Free Token') {
        	$this->Money_model->withdraw_free_tokens(array($post['total_amount'], $account_id));
        }

			

		$data = array(
			'account_id'  => $account_id,
			'debit'       => $post['total_amount'],
			'description' => $post['rewards_type'] == 'Free Token'?'Received '.$post['no_of_token'].' FREE Gold token':'Bought ' . $token_description . ' tokens using ' . $post['rewards_type'],
			'date'        => date('Y-m-d H:i:s')
		);
		$this->Money_model->add_logs($data);

		$data['result']  = $this->Token_gaming_model->get_token_by_account_id($account_id);

		$this->Money_model->update_total($account_id);
		$this->Money_model->update_current($account_id);

		$current_rewards = $this->Money_model->get_money_details($account_id);

		// $affiliate_shares      = $this->Affiliate_shares_model->get_active_affiliate_shares($this->session->userdata('user_id'));
		// $total_affiliate_share = 0;

		// foreach($affiliate_shares as $affiliate_share) {
		// 	$date = date('Y-m-d',strtotime($affiliate_share->created_date));
		// 	$days_invested = (new DateTime())->diff(new DateTime($date))->days;
		// 	$total_affiliate_share += $days_invested*$affiliate_share->daily_profit;
		// }

        echo json_encode(
			array(
				'message'               => 'Success',
				'table'                 => $this->load->view('token/token_table',$data,true),
				'current_rewards'       => ($current_rewards->current_bonus),
            	'current_free_token'    => $current_rewards->free_token,
				'current_cfc_ws'        => ($current_rewards->total_affiliate_share-($current_rewards->withdrawn_affiliate_share+$current_rewards->reinvest_affiliate_shares+$current_rewards->transfered_affiliate_shares)),
				'current_cfc_exclusive' => (($current_rewards->cfc_exclusive + $current_rewards->cfc_exclusive_referral + $current_rewards->received_cfc_exclusive) - ($current_rewards->withdrawn_cfc_exclusive + $current_rewards->transfered_cfc_exclusive))
			)
		);
	}

	function randomGen($min, $max, $quantity) {
	    $numbers = range($min, $max);
	    shuffle($numbers);
	    return array_slice($numbers, 0, $quantity);
	}

	public function end_game()
	{
		$post = array_map("trim", $this->input->post());

		$id = $this->Token_gaming_model->end_game($post['header_id']);	//ends game and adds new header
		$data['result'] = $this->Token_gaming_model->get_all_headers();

		echo $this->load->view('token/token_gaming_table',$data,true);
	}

	public function add_winner_combination()
	{
		$post = array_map("trim", $this->input->post());
		
		$result = $this->Token_gaming_model->get_raffle_by_winner_combination(array($post['header_id'], $post['winner_combination1'], $post['winner_combination2'], $post['winner_combination3']));

		if($result) {
			$this->Token_gaming_model->update_header($post['header_id'],array('winner_token_id' => $result->id, 'winner_combination1' => $post['winner_combination1'], 'winner_combination2' => $post['winner_combination2'], 'winner_combination3' => $post['winner_combination3']));

			$this->add_winner_and_referral_money($post['header_id'], $result);	//result = token lines
		} else {
			$this->Token_gaming_model->update_header($post['header_id'],array('winner_combination1' => $post['winner_combination1'],'winner_combination2' => $post['winner_combination2'],'winner_combination3' => $post['winner_combination3']));
		}

		$this->add_consolation_winner($post);

		$data['result'] = $this->Token_gaming_model->get_all_headers();
		echo $this->load->view('token/token_gaming_table',$data,true);

	}

	public function add_winner_and_referral_money($header_id, $token_line)
	{
		$account = $this->Account_model->get_account_from_id($token_line->account_id);
		$account_id = $account->account_id;
		$game = $this->Token_gaming_model->get_header($header_id);
		$date = date('Y-m-d H:i:s');
		
		if($account->activated){	//add winner money
			$this->Money_model->add_cfc_exclusive(array($game->prize, 0, $account_id));
			$this->add_money_logs($account_id, $game->prize, "Received CFC exclusive");
		}

		for ($i=1; $i <= 10; $i++) { 
			if($account->sponsor_ID){
				$account = $this->Account_model->get_account_from_id($account->sponsor_ID);
				if($account->activated){	//if account is activated, add referral winner
					$prize = 0;
					switch ($i) {
						case 1:
							$prize = $game->prize / 2;
							break;
						case 2:
						case 3:
							$prize = $game->prize / 4;
							break;
						case 4:
						case 5:
							$prize = $game->prize / 5;
							break;
						case 6:
						case 7:
							$prize = ($game->prize - ($game->prize/10)) / 6;
							break;
						case 8:
						case 9:
						case 10:
							$prize = $game->prize / 10;
							break;
					}

					$this->Money_model->add_cfc_exclusive(array(0, $prize, $account->account_id));
					$this->Token_gaming_model->new_referral_winners(array('header_id' => $header_id, 'referror_id' => $account->account_id, 'winner_id' => $account_id, 'level' => $i, 'referral_amount' => $prize));
					$this->add_money_logs($account_id, $prize, "Received CFC exclusive referral rewards");
				}
			} else {
				break;
			}
		}
	}

	public function add_money_logs($account_id, $amount, $description) { //credit
		$data = array(
			'account_id'  => $account_id,
			'amount'      => $amount,
			'description' => $description,
			'date'        => date('Y-m-d H:i:s')
		);
		$this->Money_model->add_logs($data);
	}

	public function add_consolation_winner($post)
	{
		$game = $this->Token_gaming_model->get_header($post['header_id']);
		$prize = $game->prize/10;
		$one = $post['winner_combination1'];
		$two = $post['winner_combination2'];
		$three = $post['winner_combination3'];

		//1-3-2
		if($account_id = $this->Token_gaming_model->add_consolation_winner(array($prize, $post['header_id'], $one, $three, $two))) 
			$this->add_money_logs($account_id, $prize, "Received CFC exclusive consolation");

		//2-3-1
		if($account_id = $this->Token_gaming_model->add_consolation_winner(array($prize, $post['header_id'], $two, $three, $one))) 
			$this->add_money_logs($account_id, $prize, "Received CFC exclusive consolation");

		//2-1-3
		if($account_id = $this->Token_gaming_model->add_consolation_winner(array($prize, $post['header_id'], $two, $one, $three))) 
			$this->add_money_logs($account_id, $prize, "Received CFC exclusive consolation");

		//3-1-2
		if($account_id = $this->Token_gaming_model->add_consolation_winner(array($prize, $post['header_id'], $three, $one, $two))) 
			$this->add_money_logs($account_id, $prize, "Received CFC exclusive consolation");

		//3-2-1
		if($account_id = $this->Token_gaming_model->add_consolation_winner(array($prize, $post['header_id'], $three, $two, $one))) 
			$this->add_money_logs($account_id, $prize, "Received CFC exclusive consolation");

	}

}