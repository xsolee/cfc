<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Cfc_coins extends CI_Controller {
	public function __construct() 
	{
		parent::__construct();
		$this->load->library('session');
		if ( ! $this->session->userdata('user_id')) {
			redirect('Account/login');
		}
		$this->load->model(array('Account_model','Money_model'));
	}
	
	public function index()
	{
		$money  	  = $this->Money_model->get_money_details($this->session->userdata('user_id'));
		$current_rate = $this->Money_model->get_cfc_coins_rate();

		$data = array(
			'title'   			  => 'CFC Coins',
            'content'       	  => 'cfc_coins/cfc_coins_view',
            'money'         	  => $money,
            'cfc_coins_rate'  	  => $current_rate->rate,
			'hasTransferPassword' => $this->Account_model->get_account_from_id($this->session->userdata('user_id'))->transfer_password? true: false
		);
		$this->load->view('template/template',$data);
	}
	
	public function purchase()
	{
		$post = array_map("trim", $this->input->post());
		$account_id = $this->session->userdata('user_id');

		$this->Money_model->update_total($account_id);
		$this->Money_model->update_current($account_id);

		$current_rewards = $this->Money_model->get_money_details($account_id);
		
		$current_rate = $this->Money_model->get_cfc_coins_rate();
		$total_amount = $post['amount'] * $current_rate->rate;

		if($post['purchase_from'] == 'Rewards') {
        	if((($current_rewards->current_bonus) - $total_amount) < 0) {
				echo json_encode(
					array(
						'message' => 'Not enough rewards!'
					)
				);
				exit();
			}	
			$purchase_from = "withdrawn_bonus";
        } else if($post['purchase_from'] == 'CFC WS Rewards') {
        	if((($current_rewards->total_affiliate_share-($current_rewards->withdrawn_affiliate_share+$current_rewards->reinvest_affiliate_shares+$current_rewards->transfered_affiliate_shares)) - $total_amount) < 0) {
				echo json_encode(
					array(
						'message' => 'Not enough CFC WS Rewards!'
					)
				);
				exit();
			}
			$purchase_from = "withdrawn_affiliate_share";
        } else if($post['purchase_from'] == 'CFC Exclusive') {
        	if((((($current_rewards->cfc_exclusive + $current_rewards->cfc_exclusive_referral + $current_rewards->received_cfc_exclusive) - ($current_rewards->withdrawn_cfc_exclusive + $current_rewards->transfered_cfc_exclusive))) - $total_amount) < 0) {
				echo json_encode(
					array(
						'message' => 'Not enough CFC Exclusive!'
					)
				);
				exit();
			}
			$purchase_from = "withdrawn_cfc_exclusive";
        } else {
        	echo json_encode(
				array(
					'message' => 'Unknown Rewards Type!'
				)
			);
			exit();
        }

        $this->Money_model->purchase_cfc_coins($account_id,$post['amount'],$total_amount,$purchase_from,$current_rate->rate);


		$data = array(
			'account_id'  => $account_id,
			'amount'      => $post['amount'],
			'debit'       => $total_amount,
			'description' => "Purchased CFC Coins from ".$post['purchase_from'],
			'date'        => date('Y-m-d H:i:s')
		);
		$this->Money_model->add_logs($data);

		$this->Money_model->update_total($account_id);
		$this->Money_model->update_current($account_id);
		$money = $this->Money_model->get_money_details($account_id);

		$cfc_exclusive = ($money->cfc_exclusive + $money->cfc_exclusive_referral + $money->received_cfc_exclusive) - ($money->withdrawn_cfc_exclusive + $money->transfered_cfc_exclusive); 
		$cfc_ws = ($money->total_affiliate_share + $money->received_affiliate_shares) - ($money->reinvest_affiliate_shares + $money->withdrawn_affiliate_share + $money->withdrawn_affiliate_share_2 + $money->transfered_affiliate_shares + $money->transfered_affiliate_shares_2);

		$data = array(
			'money'          => $money, 
			'cfc_exclusive'  => $cfc_exclusive, 
			'cfc_ws'         => $cfc_ws, 
			// 'purchased'   => $money->purchased_cfc_coins, 
			// 'received'    => $money->received_cfc_coins, 
			// 'transferred' => $money->transferred_cfc_coins, 
			'message'        => "success"
		);
		echo json_encode($data);
		exit();
	}

	public function transfer() {
		$post = array_map("trim", $this->input->post());
		$account_id = $this->session->userdata('user_id');

		if(!$this->Account_model->check_transfer_password(array($account_id, $post['password']))) {
        	echo json_encode(array(
				'message' => $this->Account_model->get_account_from_id($account_id)->transfer_password? "Error: Incorrect Transfer Password!": "Error: Please Set Transfer Password first!"
			) );
			exit();
		}

		if(!$this->Account_model->get_account_from_id($post['account_id'])) {
        	echo json_encode(array('message' => "Error: Account ID doesn't exist!") );
			exit();
		}

		/*if($post['transfer_amount']<100) {
        	echo json_encode(array('message' => "Error: Minimum amount is 100.") );
			exit();
		}*/

		$money = $this->Money_model->get_money_details($account_id);
		$available_cfc_coins = $money->purchased_cfc_coins+$money->received_cfc_coins-$money->transferred_cfc_coins-$money->withdrawn_cfc_coins;
		if($available_cfc_coins < $post['transfer_amount'])	{
        	echo json_encode(
				array(
					'message' => 'Insufficient CFC Coins!'
				)
			);
			exit();
        }

        $this->Money_model->transfer_cfc_coins($account_id,$post['transfer_amount'],$post['account_id']);

		$data = array(
			'account_id'  => $account_id,
			'debit'       => $post['transfer_amount'],
			'description' => "Transfer CFC Coins to ".$post['account_id'],
			'date'        => date('Y-m-d H:i:s')
		);
		$this->Money_model->add_logs($data);

		$data = array(
			'account_id'  => $post['account_id'],
			'amount'       => $post['transfer_amount'],
			'description' => "Received CFC Coins from ".$account_id,
			'date'        => date('Y-m-d H:i:s')
		);
		$this->Money_model->add_logs($data);

		$this->Money_model->update_total($account_id);
		$this->Money_model->update_current($account_id);
		$money = $this->Money_model->get_money_details($account_id);

		$cfc_exclusive = ($money->cfc_exclusive + $money->cfc_exclusive_referral + $money->received_cfc_exclusive) - ($money->withdrawn_cfc_exclusive + $money->transfered_cfc_exclusive); 
		$cfc_ws = ($money->total_affiliate_share + $money->received_affiliate_shares) - ($money->reinvest_affiliate_shares + $money->withdrawn_affiliate_share + $money->withdrawn_affiliate_share_2 + $money->transfered_affiliate_shares + $money->transfered_affiliate_shares_2);

		$data = array(
			'money'          => $money, 
			'cfc_exclusive'  => $cfc_exclusive, 
			'cfc_ws'         => $cfc_ws, 
			// 'purchased'   => $money->purchased_cfc_coins, 
			// 'received'    => $money->received_cfc_coins, 
			// 'transferred' => $money->transferred_cfc_coins, 
			'message'     => "success"
		);
		echo json_encode($data);
	}

	public function update_rate()
	{
		$post = array_map("trim", $this->input->post());
		if ( $this->session->userdata('user_id')!="0000001") redirect('dashboard');

        if($this->Money_model->update_cfc_coins_rate($post['rate'])) echo $post['rate'];
        else echo "Error";
	}
}
