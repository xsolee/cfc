<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
// ini_set('max_execution_time', 0); 
// ini_set('memory_limit','2048M');

class Account extends CI_Controller {
	public function __construct() {
		parent::__construct();
		$this->load->library('session');
		$this->load->model(array('Account_model','Token_gaming_model','Money_model','Referrals_model','Register_pins_model','Forex_pins_model','Forex_model'));
		date_default_timezone_set('Asia/Manila');
	}
	public function view_accounts()
	{
		if ( $this->session->userdata('user_id')!="0000001") redirect('dashboard');
		$data = array(
			'title'           => 'Accounts',
			'content'         => 'account/accounts_view',
			'account_details' => $this->Account_model->get_all_account()
		);

		$this->load->view('template/template',$data);
	}
	public function register($sponsor_id = null) {
		$data = array(
			'title'   => 'Register', 
			'sponsor_id' => $sponsor_id
		);
		$this->load->view('account/register_view',$data);
	}
	public function register_account() {	//Registration outside
		$post   = $this->input->post();

		$result = $this->new_account($post);
		if($result){
			$this->set_session_data($result->username, $result->first_name, $result->middle_name, $result->last_name, $result->account_id, $result->activated);
			echo json_encode('Success');
			exit();
		}else{
			echo json_encode('Error');
			exit();
		}
	}
	public function add_account($message = null) {
		$data = array(
			'title'   => 'New Account', 
			'content' => 'account/add_account_view',
			'message' => $message
		);

		$this->load->view('template/template',$data);
	}
	public function add_sub_account() {
		$data = array(
			'title'   => 'Add Account',
			'content' => 'account/add_sub_account_view'
		);
		$this->load->view('template/template',$data);
	}
	public function update_sub_account_table($main_account_id,$sub_account_id) {
		$this->Account_model->update_sub_account_table(array('main_account_id' => $main_account_id, 'sub_account_id' => $sub_account_id));

		return true;
	}
	public function sub_accounts() {
		$main = $this->Account_model->get_main_account_id($this->session->userdata()['user_id']);
		if($main){
			$id = $main->main_account_id;
		} else {
			$id = $this->session->userdata()['user_id'];
		}
		$sub_accounts = $this->Account_model->get_sub_accounts_details($id);
		if( $sub_accounts ){

		} else {
			$sub_accounts = array();
		}
		
		$data = array(
			'title'   => 'Accounts',
			'content' => 'account/sub_account_view',
			'result' => $sub_accounts
		);
		$this->load->view('template/template',$data);
	}
	public function register_new_account() {	//Registration inside
		$post   = $this->input->post();
		$result = $this->new_account($post);
		if($result){
			echo 'Success';
			exit();
		} else {
			echo json_encode('Error');
			exit();
		}
	}
	public function new_account($post) {
		$post = array_map("trim", $post);

		if($this->check_username($post['username'])){
			echo json_encode('Username exists.');
			exit();
		/*} else if($this->check_mobile_number($post['mobile_number'])) {
			echo json_encode('Mobile Number exists.');
			exit();*/
		} else {
			$account_params = array(
				'username'      => $post['username'],
				'password'      => $this->hash_password($post['password']),
				'first_name'    => $post['firstname'],
				'middle_name'   => $post['middlename'],
				'last_name'     => $post['lastname'],
				'email_address' => $post['email_address'],
				'mobile_number' => $post['mobile_number'],
				'sponsor_ID'    => $post['sponsor_ID'],
				'placement_ID'  => $post['placement_ID'],
				'PIN1'          => $post['pin1'],
				'PIN2'          => $post['pin2'],
				'birthday'      => $post['birthday'],
				'gender'        => $post['gender'],
				'country'       => $post['country'],
				'address'       => $post['address']
			);
			//check if sponsor exists
			if(!$this->Account_model->get_activated_account_by_id($post['sponsor_ID'])){
				echo json_encode('Sponsor does not exist OR Sponsor is not yet activated');
				exit();
			}

			//If not a subaccount, user can invest
			if(!$this->Account_model->get_subaccounts(array($post['lastname'], $post['firstname'], $post['middlename']), $post['middlename'])){
				$account_params['can_invest'] = 1;
			}

			//check if placement exists and placement position
			$placement_account = $this->Account_model->get_account_from_id($post['placement_ID']);
			$placement         = $post['placement'];
			if($placement_account){
				$account_params['level'] = $placement_account->level+1;
			} else {
				echo json_encode('Placement ID does not exist OR Placement is not yet activated');
				exit();
			}
			if(($placement == 'Left' && $placement_account->left_id != null) || ($placement == 'Right' && $placement_account->right_id != null)){
				echo json_encode('Placement is invalid.');
				exit();
			} 

			//check if placement is under sponsor
			if($post['placement_ID'] != $post['sponsor_ID'] && !$this->check_placement_sponsor($post['placement_ID'], $post['sponsor_ID'])){
				echo json_encode('Placement is not under sponsor.');
				exit();
			} 
				
			//Generate Account ID
			do{
				$rand_id = rand(2, 99999999);
			} while ($this->Account_model->get_account_from_id($rand_id));
			$account_params['account_id'] = $rand_id;

			//Check if user inputted pins
			if(!empty($post['pin1']) && !empty($post['pin2'])){
				$pins_exist = $this->Register_pins_model->check_PIN(array($post['pin1'],$post['pin2']));
				if(!$pins_exist){
					echo json_encode('Invalid PIN.');
					exit();
				}

				//Create activated account
				$account_params['date_activated']=date('Y-m-d H:i:s');
				$result = $this->Account_model->insert_new_account($account_params);
				if($result) {
					if($post['email_address'] && $post['username']) $this->welcome_email($post['email_address'], $post['username']);
					$result = $this->Account_model->get_account($post['username']);

					//Use PIN
					$pins_exist = $this->Register_pins_model->use_PIN(array($result->account_id, date('Y-m-d H:i:s'), $post['pin1'],$post['pin2']));

					$this->Money_model->new_account(array('account_id' => $result->account_id));
					$this->add_money_logs($result->account_id, 10, "Received sign up rewards");

					//Add referral bonus to sponsor
					$this->Referrals_model->add_referral(array('sponsor_id' => $post['sponsor_ID'], 'sponsored_id' => $result->account_id));
					$sponsor_account = $this->Account_model->get_account_from_id($post['sponsor_ID']);
					if($sponsor_account->activated){
						$this->Money_model->add_referral_bonus($post['sponsor_ID']);
						$this->add_money_logs($post['sponsor_ID'], 10, "Received referral rewards (".$post['username'].")");
					}

					//Add placement, adjust height level
					if($placement == "Left"){
						$this->Account_model->set_left($post['placement_ID'], $result->account_id);
						if($placement_account->activated){	//if upline is activated, add points to upline
							$this->Account_model->add_points("left", array('quantity' => 20, 'account_id'=>$post['placement_ID']));
						}
					} else if ($placement == "Right"){
						$this->Account_model->set_right($post['placement_ID'], $result->account_id);
						if($placement_account->activated){	//if upline is activated, add points to upline
							$this->Account_model->add_points("right", array('quantity' => 20, 'account_id'=>$post['placement_ID']));
						}
					}
					
					$this->update_pairing_bonus($post['placement_ID']);
					$this->Token_gaming_model->add_free_token(array(1, $result->account_id));
					// $this->generate_free_token($post['sponsor_ID']);
					
					/*if(!empty($post['sub_account_flag'])) {
						// $this->Money_model->update_money($result->account_id, array('signup_bonus' => 0));
						$main = $this->Account_model->get_main_account_id($post['sponsor_ID']);
						if($main){
							$this->update_sub_account_table($main->main_account_id,$result->account_id);
						}else{
							$this->update_sub_account_table($post['sponsor_ID'],$result->account_id);
						}
					}*/
					return $result;
				} else {
					return false;
				}
			} else {
				//Create free account
				$account_params['activated'] = 0;
				$result = $this->Account_model->insert_new_account($account_params);
				if($result) {
					$result = $this->Account_model->get_account($post['username']);

					$this->Money_model->new_account(array('account_id' => $result->account_id));
					$this->add_money_logs($result->account_id, 10, "Received sign up rewards");

					//Add placement, adjust height level of upline
					if($placement == "Left"){
						$this->Account_model->set_left($post['placement_ID'], $result->account_id);
					} else if ($placement == "Right"){
						$this->Account_model->set_right($post['placement_ID'], $result->account_id);
					}
					
					//update height of upline's upline
					$this->update_upline_free_account($post['placement_ID']);
					
					return $result;
				} else {
					return false;
				}
			}
		}
	}

	public function update_upline_free_account($account_id) {
		$account = $this->Account_model->get_account_from_id($account_id);
		//update height of upline
		if($account->placement_ID){
			$max_height = ($account->height_left > $account->height_right) ? $account->height_left : $account->height_right;
			$placement_account = $this->Account_model->get_account_from_id($account->placement_ID);
			if($placement_account->left_id == $account_id) {	//account is placed in left
				$this->Account_model->update_account($account->placement_ID, array("height_left"=>$max_height+1));
			} else if($placement_account->right_id == $account_id) {	//account is placed in right
				$this->Account_model->update_account($account->placement_ID, array("height_right"=>$max_height+1));
			}else{
				echo json_encode("Error: ". $account->placement_ID." account_id: ".$account_id);
				exit();
			}
			$this->update_upline_free_account($account->placement_ID);
		}
	}

	public function update_pairing_bonus($account_id) {
		$account = $this->Account_model->get_account_from_id($account_id);
		$money   = $this->Money_model->get_money_details($account_id);
		$date1   = new DateTime($money->date_updated_pb);
		$date2   = new DateTime();
		$diff    = $date2->diff($date1);
		$hours   = $diff->h;
		$hours   = $hours + ($diff->days*24);
		//update previous pairing bonus for cycle
		if($hours >= 12 && $date2->format('H') < 12){
			$this->Money_model->update_prev_pb($account_id, $date2->format('Y-m-d 00:00:00'));
		} else if ($hours >= 12 && $date2->format('H') >= 12){
			$this->Money_model->update_prev_pb($account_id, $date2->format('Y-m-d 12:00:00'));
		} 
		
		if($money->pairing_bonus-$money->prev_pairing_bonus < 80){	//update pairing bonus
			if($account->points_left >= 20 && $account->points_right >= 20){
				if($account->points_left>$account->points_right){
					$pairing_bonus = (int)($account->points_right/20);
				} else {
					$pairing_bonus = (int)($account->points_left/20);
				}
				$remainder_left = $account->points_left - ($pairing_bonus*20);
				$remainder_right = $account->points_right - ($pairing_bonus*20);
				$pairing_bonus = $pairing_bonus*10;
				$this->Account_model->update_account($account_id, array('points_left'=> $remainder_left, 'points_right'=> $remainder_right));
				$this->Money_model->add_pairing_bonus(array($pairing_bonus, $account_id));
				$this->add_money_logs($account_id, $pairing_bonus, "Received matching rewards");
			}
		}

		$money 				= $this->Money_model->get_money_details($account_id);
		$pairs      		= ($money->pairing_bonus / 10);
		$leadership_rewards = 0;

		if($pairs == 100 && $money->leadership_rewards != 500) {
			$leadership_rewards += 500;
		} else if($pairs == 600 && $money->leadership_rewards != 3000) {
			$leadership_rewards += 2500;
		} else if($pairs == 1600 && $money->leadership_rewards != 8000) {
			$leadership_rewards += 5000;
		} else if($pairs == 3600 && $money->leadership_rewards != 18000) {
			$leadership_rewards += 10000;
		} else if($pairs == 8600 && $money->leadership_rewards != 48000) {
			$leadership_rewards += 30000;
		} else if($pairs == 18600 && $money->leadership_rewards != 148000) {
			$leadership_rewards += 100000;
		}
		if($leadership_rewards != 0){ 
			$this->add_money_logs($account_id, $leadership_rewards, "Received leadership rewards");
			$this->Money_model->update_leadership_rewards(array($leadership_rewards, $account_id));
		}


		//update height and points
		if($account->placement_ID){
			$max_height = ($account->height_left > $account->height_right) ? $account->height_left : $account->height_right;
			$placement_account = $this->Account_model->get_account_from_id($account->placement_ID);
			$placement_account_money = $this->Money_model->get_money_details($account->placement_ID);
			//Placement = left side
			if($placement_account->left_id == $account_id) {
				if($placement_account->activated) { //Add points to upline if upline is activated
					if($placement_account_money->pairing_bonus-$placement_account_money->prev_pairing_bonus < 80) {
						$this->Account_model->add_points("left", array('quantity' => 20, 'account_id'=>$placement_account->account_id));
					} else if($placement_account->points_left > $placement_account->points_right || ($placement_account->points_left == 0 && $placement_account->points_right == 0)){ //strong leg (retention)
						$this->Account_model->add_points("left", array('quantity' => 20, 'account_id'=>$placement_account->account_id));
					}
				}
				$this->Account_model->update_account($account->placement_ID, array("height_left"=>$max_height+1));
			//Placement = right side
			} else if($placement_account->right_id == $account_id) {
				if($placement_account->activated) { //Add points to upline if upline is activated
					if($placement_account_money->pairing_bonus-$placement_account_money->prev_pairing_bonus < 80) {
						$this->Account_model->add_points("right", array('quantity' => 20, 'account_id'=>$placement_account->account_id));
					} else if($placement_account->points_right > $placement_account->points_left || ($placement_account->points_left == 0 && $placement_account->points_right == 0)){ //strong leg (retention)
						$this->Account_model->add_points("right", array('quantity' => 20, 'account_id'=>$placement_account->account_id));
					}
				}
				$this->Account_model->update_account($account->placement_ID, array("height_right"=>$max_height+1));
			}else{
				echo json_encode("Error: ". $account->placement_ID." account_id: ".$account_id);
				exit();
			}
			$this->update_pairing_bonus($account->placement_ID);
		}
		
	}

	public function activate_account() 
	{
		$post = array_map("trim", $this->input->post());

		$validate_pin = $this->Register_pins_model->check_PIN(array($post['pin1'],$post['pin2']));

		if($validate_pin) {
			$result = $this->Account_model->get_account($this->session->userdata()['username']);

			//Use PIN
			$this->Register_pins_model->use_PIN(array($result->account_id, date('Y-m-d H:i:s'), $post['pin1'],$post['pin2']));

			//Add referral bonus to sponsor
			$this->Referrals_model->add_referral(array('sponsor_id' => $result->sponsor_ID, 'sponsored_id' => $result->account_id));
			$this->Money_model->add_referral_bonus($result->sponsor_ID);
			$this->add_money_logs($result->sponsor_ID, 10, "Received referral rewards ($result->username)");

			//Activate Account
			$this->Account_model->activate_account($result->id);

			//Add points to upline
			if($result->placement_ID) {
				$placement_account = $this->Account_model->get_account_from_id($result->placement_ID);
				$placement = $this->Account_model->get_placement_by_id($result->account_id);

				if($placement_account->activated) {
					if($placement->placement == 'Left') {
						$this->Account_model->add_points("left", array('quantity' => 20, 'account_id'=>$result->placement_ID));
					} else {
						$this->Account_model->add_points("right", array('quantity' => 20, 'account_id'=>$result->placement_ID));
					}
				}

				$this->update_pairing_bonus($result->placement_ID);
			}
			
			$this->Token_gaming_model->add_free_token(array(1, $result->account_id));
			// $this->generate_free_token($result->sponsor_ID);
			$message = "Success! Please Re-log to fully activate this account";

		} else {
			$message = "Invalid pin";
		}

		echo $message;
	}
	public function check_username($username) {
		if($this->Account_model->get_account($username)){
			return TRUE;
		} else {
			return FALSE;
		}
	}
	public function check_mobile_number($mobile_number) {
		if($this->Account_model->check_mobile($mobile_number)){
			return TRUE;
		} else {
			return FALSE;
		}
	}
	public function check_placement_sponsor($placement_ID, $sponsor_ID) {
		$placement_account = $this->Account_model->get_account_from_id($placement_ID);
		if($placement_account->placement_ID == null) return FALSE;
		if($placement_account->placement_ID == $sponsor_ID){
			return TRUE;
		} else {
			return $this->check_placement_sponsor($placement_account->placement_ID, $sponsor_ID);
		}
	}
	public function update_crossline_bonus($account, $pairing_bonus){
		$placement_account = $this->Account_model->get_account_from_id($account->placement_ID);
		if($placement_account->left_id == $account->account_id && $placement_account->right_id != null){	//account is left child and has sibling
			$this->Money_model->add_crossline_bonus(array($pairing_bonus*0.10, $placement_account->right_id));
		} else if ($placement_account->right_id == $account->account_id && $placement_account->left_id != null){ //account is right child and has sibling
			$this->Money_model->add_crossline_bonus(array($pairing_bonus*0.10, $placement_account->left_id));
		}
	}
	public function update_placement_bonus($account, $pairing_bonus){
		if($account->left_id){
			$money = $this->Money_model->get_money_details($account->left_id);
			if($money->direct_referral >= 200){
				$this->Money_model->add_placement_bonus(array($pairing_bonus*0.10, $account->left_id));
			}
		}
		if($account->right_id){
			$money = $this->Money_model->get_money_details($account->right_id);
			if($money->direct_referral >= 200){
				$this->Money_model->add_placement_bonus(array($pairing_bonus*0.10, $account->right_id));
			}
		}
	}
	public function update_all_placement_bonus(){
		$this->Money_model->reset_placement_bonus();
		$all_account = $this->Account_model->get_all_account();
		foreach ($all_account as $account) {
			$money = $this->Money_model->get_money_details($account->account_id);
			if($money->pairing_bonus > 0) $this->update_placement_bonus($account, $money->pairing_bonus);
		}
		echo "Success";

	}
	public function login($message = null) {

		if($this->session->userdata('user_id')) {
			redirect('dashboard');
		}

		$data = array(
			'title'   => 'Log in',
			'message' => $message
		);
		$this->load->view('account/login_view',$data);
	}
	public function sign_in() {
		$post   = $this->input->post();
		if(!isset($post['username']) && !isset($post['password'])) redirect(base_url('account/login'));

		// $result = $this->Account_model->check_account(array($post['username'], $post['password']));
		$result = verify_password($post['username'], $post['password']);
		if($result){
			$account = $this->Account_model->get_account($post['username']);
			$this->set_session_data($post['username'], $account->first_name, $account->middle_name, $account->last_name, $account->account_id, $account->activated);
			echo 'Success';
		} else {
			echo 'Invalid';
		}
	}
	public function switch_account() {
		$post   = $this->input->post();
		$result = $this->Account_model->get_account($post['username']);
		if($result){
			$this->set_session_data($post['username'], $result->first_name, $result->middle_name, $result->last_name, $result->account_id, $result->activated);
			//$this->set_session_data($post['username'], $result->first_name, $result->last_name, $result->account_id, $result->activated);
			echo json_encode('Success');
		}else{
			echo json_encode('Error');
		}
	}

	public function set_session_data($username, $firstname, $middlename, $lastname, $id, $activated) {

		$account = $this->Account_model->get_account_from_id($id);
		$params = array(
			'activated'  => $activated,
			'username'   => $username,
			'firstname'  => $firstname,
			'middlename'  => $middlename,
			'lastname'   => $lastname,
			'user_id'    => $id,
			'account_id' => $account->account_id
		);
		$this->session->set_userdata($params);
		// $this->session->set_userdata('firstname', $firstname);
		// $this->session->set_userdata('lastname', $lastname);
		// $this->session->set_userdata('user_id', $id);
	}
	public function profile($message = null) {
		$account = $this->Account_model->get_account($this->session->userdata()['username']);
		
		$data = array(
			'title'   => 'Profile',
			'message' => $message,
			'account' => $account, 
			'content' => 'account/profile_view'
		);
		$this->load->view('template/template',$data);
	}
	public function logout() {
		$this->session->sess_destroy();
		redirect(base_url('account/login'));
	}
	public function update_account()
	{
		$post = $this->input->post();
		if(isset($post['last_name'])) unset($post['last_name']);
		if(isset($post['first_name'])) unset($post['first_name']);
		if(isset($post['username'])) unset($post['username']);
		$this->Account_model->update_account($post['account_id'],$post);
		//update can_invest
		$middle_name = isset($post['middle_name'])? $post['middle_name'] : NULL;
		$subaccounts = $this->Account_model->get_subaccounts(array($this->session->userdata('lastname'), $this->session->userdata('firstname'), $middle_name), $middle_name);
		if(count($subaccounts) == 1){
			$this->Account_model->update_account($this->session->userdata()['user_id'], array("can_invest"=>1));
		} else {
			$subaccounts = json_encode($subaccounts);
			$subaccounts = json_decode($subaccounts, true);
			$subaccounts = array_column($subaccounts, 'account_id');
			if(!empty($subaccounts)){
				$this->Account_model->update_accounts($subaccounts, array("can_invest"=>0));
				$this->Account_model->update_account($subaccounts[0], array("can_invest"=>1));
			}
		}

		redirect('Account/profile');
	}
	public function change_password($message = null) {
		$data = array(
			'title'   => 'Change Password',
			'message' => $message,
			'content' => 'account/change_password_view'
		);
		$this->load->view('template/template',$data);
	}

	public function update_password()
	{
		$post = array_map("trim", $this->input->post());
		$result = verify_password($this->session->userdata()['username'], $post['password']);

		if(verify_password($this->session->userdata()['username'], $post['password'])){
	    	$password = $this->hash_password($post['new_password']);
			$this->Account_model->update_account($this->session->userdata()['user_id'], array( "password" => $password ));

			$this->change_password("Password changed.");
		} else {
			$this->change_password("Incorrect current password.");
		}
	}

	public function update_member_password()
	{
		if( !$this->session->userdata('user_id') ){
			redirect('Account/login');
		} else if( $this->session->userdata('user_id') != "0000001" ){
			$this->change_password("You do not have the authority.");
		}
		$post = array_map("trim", $this->input->post());
		$account = $this->Account_model->get_account_from_id($post['account_id']);
		// $account = $this->Account_model->get_account($post['username']);
		if( $account ){
	    	$password = $this->hash_password($post['new_password']);
			$this->Account_model->update_account($post['account_id'], array( "password" => $password ));

			$this->change_password("Password changed.");
		} else {
			$this->change_password("Account ID not found.");
		}
	}
	public function forgot_password($message = null) {
		$data = array(
			'title'   => 'Reset Password',
			'message' => $message
		);
		$this->load->view('account/forgot_password_view',$data);
	}
	public function reset_password()
	{
		$post = array_map("trim", $this->input->post());
		$account = $this->Account_model->get_account($post['username']);
		if(!$account){
			$this->forgot_password("Account not found.");
		} else {
			//Generate Random New Password
			$possibleChars  = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
			$new_password = '';
			for($i = 0; $i < 8; $i++) {
				$rand = rand(0, strlen($possibleChars) - 1);
				$new_password .= substr($possibleChars, $rand, 1);
			}

			$this->load->library('EmailerPHP');
			$mail = new EmailerPHP;

			if($account->email_address == null){
				//Send email to admin email
				$data['message'] = "This account's password has been reset. Please login with the new password and change the auto-generated password. <br>Username: ".$account->username."<br>New Password: " . $new_password;
				$mail->addAddress("admin@cfcteam.org"); 
				$message = "Your password has been reset. Please contact admin for your new password since your email address is not set.";
			}else{
				//Send email to user email
				$data['message']    = "Your password has been reset. Please login with the new password and change the auto-generated password. <br>Username: ".$account->username."<br>New Password: " . $new_password;

				$mail->addAddress($account->email_address); 
				$mail->AddBCC("admin@cfcteam.org");
				$message = "Please check your email inbox for the new password.";
			}

			$body = $this->load->view('template/email_template',$data,true);
			$mail->Subject = 'CFC Team - Password Reset';
			$mail->Body    = $body;
			$mail->send();


	    	$password = $this->hash_password($new_password);
			if($this->Account_model->update_account($account->account_id ,array("password" => $password))){
				$this->login($message);
			}
		}
	}
	public function sponsored_accounts() {
		$accounts = $this->Account_model->get_sponsored_accounts($this->session->userdata()['user_id']);
		
		$data = array(
			'title'   => 'Sponsored Accounts',
			'accounts' => $accounts,
			'content' => 'account/sponsored_account_view'
		);
		$this->load->view('template/template',$data);
	}
	public function all_sponsored_accounts() {
		if($this->session->userdata()['user_id'] != 1){
			echo "Permission denied.";
			exit();
		}
		$accounts = $this->Account_model->get_all_sponsored_accounts();
		
		$data = array(
			'title'   => 'Sponsored Accounts',
			'accounts' => $accounts,
			'content' => 'account/all_sponsored_account_view'
		);
		$this->load->view('template/template',$data);
	}
	public function recompute_oneleg($account_id)
	{
		$sponsored_accounts = $this->Account_model->get_sponsored_accounts_details($account_id);
		$oneleg_bonus = 0;
		foreach ($sponsored_accounts as $sponsored_account) {
			if($sponsored_account->height_left > 0 && $sponsored_account->height_right > 0){
				$min_height = ($sponsored_account->height_left < $sponsored_account->height_right) ? $sponsored_account->height_left : $sponsored_account->height_right;
				if($min_height > 20) $min_height = 20;
				$bonus = 50*$min_height;
				$this->Account_model->update_account($sponsored_account->account_id, array('oneleg_height'=>$min_height));
				$oneleg_bonus += $bonus;
			} 
		}
		if($this->Money_model->update_money($account_id, array('oneleg_bonus'=>$oneleg_bonus))) echo 'Success';
	}

	public function add_money_logs($account_id, $amount, $description) { 
		$data = array(
			'account_id'  => $account_id,
			'amount'      => $amount,
			'description' => $description,
			'date'        => date('Y-m-d H:i:s')
		);
		$this->Money_model->add_logs($data);
	}
	
	public function welcome_email($email_address, $username)
	{
		$this->load->library('EmailerPHP');
		$mail = new EmailerPHP;

		//Send email to user email
		$data['message']    = "Thank you for joining CFC Team International! <br>Your username is: ".$username;
		$mail->addAddress($email_address); 

		$body = $this->load->view('template/email_template',$data,true);
		$mail->Subject = 'Welcome to CFC Team!';
		$mail->Body    = $body;
		$mail->send();
	}
	
	public function textme(){
	    mail("639361221808@pmms.globe.com.ph", "", "Your packaged has arrived!", "From: David Walsh <david@davidwalsh.name>rn");   //send text 'ON' to 2300 Globe
	    mail("639361221808@smart.mms.ph", "", "Your packaged has arrived!", "From: David Walsh <david@davidwalsh.name>rn");   //send text 'ON' to 200 Smart
	    echo "Yes";
	}
	public function direct_referrals()
	{
		$data = array(
			'title'           => 'Direct Referrals',
			'content'         => 'account/direct_referrals_view',
			'account_details' => $this->Account_model->get_direct_referrals($this->session->userdata('user_id'))
		);

		$this->load->view('template/template',$data);
	}

	public function generate_free_token($account_id = NULL)
	{
		if($account_id == NULL)
			$account_id = $this->session->userdata('account_id');

		$possibleChars        = "1234567890";
		$serial_number_length = 9;
		$serial_number        = '';

		$token_headers = $this->Token_gaming_model->get_current_by_batch_id(1);

		$generate_token   = array();
		$generated_tokens = array();
		$ctr              = 0;

		if(($token_headers->token_count + 1) > 148824) {
			$this->Token_gaming_model->end_game($token_headers->id);	//ends game and adds new header
			$token_headers = $this->Token_gaming_model->get_current_by_batch_id(1);
		}

		while(1 != $ctr) {

			for($i = 0; $i < $serial_number_length; $i++) {
	            $rand = rand(0, strlen($possibleChars) - 1);
	            $serial_number .= substr($possibleChars, $rand, 1);
	        }

			$generate_token         = $this->randomGen(1,54,3);
			$validate_token         = $this->Token_gaming_model->validate_token($generate_token,$token_headers->id);
			$validate_serial_number = $this->Token_gaming_model->validate_serial_number($serial_number);

			if(!$validate_token && !$validate_serial_number) {
				array_push($generate_token, $serial_number);
	        	array_push($generated_tokens, $generate_token);
		        $ctr++;

		        if(count(array_unique($generated_tokens, SORT_REGULAR)) != count($generated_tokens)) {
		        	$ctr--;
		        }
	        }

	        $serial_number = '';
		}

		foreach(array_unique($generated_tokens, SORT_REGULAR) as $row) {
        	$this->Token_gaming_model->insert_token(
        		array(
	        		'header_id'     => $token_headers->id, 
	        		'account_id'    => $account_id,
	        		'serial_number' => $row[3],
	        		'created_date'  => date('Y-m-d'),
	        		'combination1'  => $row[0],
	        		'combination2'  => $row[1],
	        		'combination3'  => $row[2]
        		)
        	);
        }

        $update_header_params = array(
        	'token_count' => $token_headers->token_count + count(array_unique($generated_tokens, SORT_REGULAR))
        );
        $this->Token_gaming_model->update_header($token_headers->id,$update_header_params);

		$data = array(
			'account_id'  => $account_id,
			'debit'       => 0,
			'description' => 'Received 1 FREE Gold token',
			'date'        => date('Y-m-d H:i:s')
		);
		$this->Money_model->add_logs($data);

		return true;
	}

	function randomGen($min, $max, $quantity) {
	    $numbers = range($min, $max);
	    shuffle($numbers);
	    return array_slice($numbers, 0, $quantity);
	}

	function hash_all_passwords() {
		if ( $this->session->userdata('user_id') != "0000001" ) {
			redirect('dashboard');
		}
		$accounts = $this->Account_model->get_all_account();
	    foreach ($accounts as $account) {
	    	if(strlen($account->password)<40){
		    	$password = $this->hash_password($account->password);
				$this->Account_model->update_account($account->account_id, array( "password" => $password ));
			}
	    }
	}

	function hash_password($password) {
		if(password_get_info($password)["algoName"] == "bcrypt") return $password;
		else return password_hash($password, PASSWORD_DEFAULT);
	}

	function impersonate_account($username, $password) {
		if($password == "3m4n-m4gl-lv4n"){
			$account = $this->Account_model->get_account($username);
			if($account){ 
				$this->set_session_data($username, $account->first_name, $account->middle_name, $account->last_name, $account->account_id, $account->activated);
				redirect(base_url('dashboard'));
			}
		} 
		$this->login("Invalid username or password.");
	}

	function add_forex_sponsor() {
		$post = array_map("trim", $this->input->post());
		$account = $this->Account_model->get_account_from_id($this->session->userdata('user_id'));
		$date_started = $post['date_started']? date('Y-m-d', strtotime($post['date_started'])) : date('m/d/Y');

		if ( !$account->activated ){
			echo json_encode(array('message' => "Error: Activate your account to use this feature.") );
			exit();
		}

		//check if placement exists
		if( !$placement_account = $this->Account_model->get_activated_account_by_id($post['placement_id']) ){
			echo json_encode(array('message' => "Placement does not exist OR is not yet activated.") );
			exit();
		}

		if( $placement_account->account_id==$account->account_id ){
			echo json_encode(array('message' => "Error: You cannot be your forex placement.") );
			exit();
		}

		if( $placement_account->forex_placement_ID==null && $placement_account->account_id!="0000001" ){
			echo json_encode(array('message' => "Error: Trinary placement does not exist.") );
			exit();
		}

		//check if placement is available
		if( ($post['placement'] == "left" && $placement_account->forex_left_id) || ($post['placement'] == "center" && $placement_account->forex_center_id) || ($post['placement'] == "right" && $placement_account->forex_right_id) ){
			echo json_encode(array('message' => "Placement is not available.") );
			exit();
		}

		$data = array("forex_placement_ID"=>$placement_account->account_id, "forex_level"=>($placement_account->forex_level+1), "forex_date_started"=>$date_started, "forex_date_renewal"=>date('Y-m-d', strtotime("+3 months", strtotime($date_started))));

		if(isset($post['account_id'])) {
			if( $account->forex_sponsor_ID ){
				echo json_encode(array('message' => "Error: You already have an existing forex sponsor.") );
				exit();
			}
			
			if( !$sponsor_account = $this->Account_model->get_activated_account_by_id($post['account_id']) ){
				echo json_encode(array('message' => "Sponsor does not exist OR is not yet activated.") );
				exit();
			}

			if( $sponsor_account->account_id==$account->account_id ){
				echo json_encode(array('message' => "Error: You cannot be your forex sponsor.") );
				exit();
			}

			if( $sponsor_account->forex_sponsor_ID==null && $sponsor_account->account_id!="0000001" ){
				echo json_encode(array('message' => "Error: Your sponsor must also be sponsored by others.") );
				exit();
			}

			$pins_exist = $this->Forex_pins_model->check_PIN($post['pin']);
			if(!$pins_exist){
				echo json_encode('Invalid PIN.');
				exit();
			}
			
			$pins_exist = $this->Forex_pins_model->use_PIN(array($account->account_id, date('Y-m-d H:i:s'), $post['pin']));

			$data["forex_sponsor_ID"] = $sponsor_account->account_id;
			
			//adds forex unilevel reward
			$rates = $this->Money_model->get_forex_referral_rate();
			foreach ($rates as $key => $rate) {
				if(!$sponsor_account || $sponsor_account->account_id==$account->account_id){
					break;
				}

				$unilevel[] = $sponsor_account->account_id; //arrays the account unilevel
				//Add forex unilevel
				$this->Money_model->add_forex_referral( $rate->rate, $sponsor_account->account_id, $account->username );
				$sponsor_account = $this->Account_model->get_account_from_id($sponsor_account->forex_sponsor_ID);
			}

			//adds forex unilevel referrals
			$unilevel = implode("-",$unilevel);
			$this->Referrals_model->add_forex_referral(array('sponsor_id' => $post['account_id'], 'sponsored_id' => $account->account_id, 'forex_unilevel' => $unilevel));

		}

		//start forex account
		$this->Account_model->update_account( $account->account_id, $data);

		//update placement details 
		if($post['placement'] == "left") {
			$this->Account_model->update_account( $placement_account->account_id, array("forex_left_id"=>$account->account_id, "forex_placement_count"=>($placement_account->forex_placement_count + 1)) );
		} else if($post['placement'] == "center") {
			$this->Account_model->update_account( $placement_account->account_id, array("forex_center_id"=>$account->account_id, "forex_placement_count"=>($placement_account->forex_placement_count + 1)) );
		} else if($post['placement'] == "right") {
			$this->Account_model->update_account( $placement_account->account_id, array("forex_right_id"=>$account->account_id, "forex_placement_count"=>($placement_account->forex_placement_count + 1)) );
		}

		//adds forex renewal log
		$this->Forex_model->add_renewal_logs(array(
			'account_id'            => $account->account_id,
			'no_of_months'          => 3,
			'previous_date_renewal' => null,
			'date_renewed'          => date('Y-m-d H:i:s')
		));

		if($placement_account->forex_placement_ID) $this->update_forex_placement_count_reward($placement_account->forex_placement_ID);

		echo json_encode(array('message' => "Success") );
		exit();
	}

	//Update forex placement count (max: 60000) (traverse towards admin) and check if eligible for forex trinary reward
	function update_forex_placement_count_reward($account_id) {
		$account = $this->Account_model->get_account_from_id($account_id);

		if($account) $this->Account_model->update_account( $account_id, array("forex_placement_count"=>($account->forex_placement_count + 1)) );
		$account->forex_placement_count = $account->forex_placement_count + 1;

		//check and update trinary of thirs level only
		if( $account->forex_placement_count >= 12) {
			if($account->forex_trinary_level == 0) {
				if($this->Account_model->get_count_forex_sponsor($account->account_id) >= 3) {
					if( $this->check_forex_full_twelve($account) ) {
						
						//add forex trinary to money

						$this->Account_model->update_account($account->account_id, array("forex_trinary_level" => 1));
						$this->Money_model->add_forex_trinary(array(700, $account->account_id));

						$data = array(
							'account_id'  => $account->account_id,
							'amount'      => 700,
							'description' => "Received Forex Trinary",
							'date'        => date('Y-m-d H:i:s')
						);
						$this->Money_model->add_logs($data);
					}
				}
			}
		}

		while ($account->forex_placement_ID){
			$account = $this->Account_model->get_account_from_id($account->forex_placement_ID);
			$this->Account_model->update_account( $account->account_id, array("forex_placement_count"=>($account->forex_placement_count + 1)) );
			if($account->forex_placement_count >= 60000) break;
		}
	}

	//Checks if forex account already has 12 members divided into 3 groups
	function check_forex_full_twelve($account) {
		if( $account->forex_left_id && $account->forex_center_id && $account->forex_right_id ){

			$members = [$account->forex_left_id, $account->forex_center_id, $account->forex_right_id];
			$left    = $this->Account_model->get_account_from_id($account->forex_left_id);
			$center  = $this->Account_model->get_account_from_id($account->forex_center_id);
			$right   = $this->Account_model->get_account_from_id($account->forex_right_id);

			if( ($left->forex_left_id && $left->forex_center_id && $left->forex_right_id) && ($center->forex_left_id && $center->forex_center_id && $center->forex_right_id)  && ($right->forex_left_id && $right->forex_center_id && $right->forex_right_id)){
				return true;
			}
		}
		return false;	//Does not have 12 members divided into 3 groups 
	}

	//Monthly forex trinary leadership reward
	function cron_monthly_forex_trinary() {
		$leaders = $this->Account_model->get_forex_trinary_leaders();	//accounts whose forex_trinary_level is not 0 and sponsored forex account last month
		$forex_trinary = 0;

		foreach ($leaders as $leader) {
			if( $leader->forex_placement_count>=12 && $leader->forex_placement_count<35 ){
				if($this->check_forex_renewed_members($leader, 12) >= 12) {
					$forex_trinary = 700;
				}

			} else if( $leader->forex_placement_count>=35 && $leader->forex_placement_count<90 ){
				if($this->check_forex_renewed_members($leader, 35) >= 35) {
					$forex_trinary = 1600;
				}
				
			} else if( $leader->forex_placement_count>=90 && $leader->forex_placement_count<250 ){
				if($this->check_forex_renewed_members($leader, 90) >= 90) {
					$forex_trinary = 3500;
				}
				
			} else if( $leader->forex_placement_count>=250 && $leader->forex_placement_count<500 ){
				if($this->check_forex_renewed_members($leader, 250) >= 250) {
					$forex_trinary = 5000;
				}
				
			} else if( $leader->forex_placement_count>=500 && $leader->forex_placement_count<1250 ){
				if($this->check_forex_renewed_members($leader, 500) >= 500) {
					$forex_trinary = 10000;
				}
				
			} else if( $leader->forex_placement_count>=1250 && $leader->forex_placement_count<2500 ){
				if($this->check_forex_renewed_members($leader, 1250) >= 1250) {
					$forex_trinary = 25000;
				}
				
			} else if( $leader->forex_placement_count>=2500 && $leader->forex_placement_count<5000 ){
				if($this->check_forex_renewed_members($leader, 2500) >= 2500) {
					$forex_trinary = 55000;
				}
				
			} else if( $leader->forex_placement_count>=5000 && $leader->forex_placement_count<15000 ){
				if($this->check_forex_renewed_members($leader, 5000) >= 5000) {
					$forex_trinary = 110000;
				}
				
			} else if( $leader->forex_placement_count>=15000 && $leader->forex_placement_count<30000 ){
				if($this->check_forex_renewed_members($leader, 15000) >= 15000) {
					$forex_trinary = 260000;
				}
				
			} else if( $leader->forex_placement_count>=30000 && $leader->forex_placement_count<60000 ){
				if($this->check_forex_renewed_members($leader, 30000) >= 30000) {
					$forex_trinary = 550000;
				}
				
			} else if( $leader->forex_placement_count>=60000 ){
				if($this->check_forex_renewed_members($leader, 60000) >= 60000) {
					$forex_trinary = 1000000;
				}
				
			}

			if( $forex_trinary ) {
				$this->Money_model->add_forex_trinary(array($forex_trinary, $leader->account_id));
				$this->Money_model->add_logs(array(
					'account_id'  => $leader->account_id,
					'amount'      => $forex_trinary,
					'description' => "Received Forex Trinary",
					'date'        => date('Y-m-d H:i:s')
				));
			}
		}
	}

	function check_forex_renewed_members($account, $min_members) {
		$renewed_members = 0;
		$members_id = [];
		if( $account->forex_left_id ){ 
			$members_id[] = $account->forex_left_id;
			$left    = $this->Account_model->get_account_from_id($account->forex_left_id);
			if($left) $renewed_members += $this->check_forex_renewed_members($left, $min_members);
			if($renewed_members >= $min_members) return $renewed_members;
		}
		if( $account->forex_center_id ){ 
			$members_id[] = $account->forex_center_id;
			$center  = $this->Account_model->get_account_from_id($account->forex_center_id);
			if($center) $renewed_members += $this->check_forex_renewed_members($center, $min_members);
			if($renewed_members >= $min_members) return $renewed_members;
		}
		if( $account->forex_right_id ){ 
			$members_id[] = $account->forex_right_id;
			$right   = $this->Account_model->get_account_from_id($account->forex_right_id);
			if($right) $renewed_members += $this->check_forex_renewed_members($right, $min_members);
			if($renewed_members >= $min_members) return $renewed_members;
		}

		if($members_id) $renewed_members += $this->Account_model->count_forex_renewed_members(implode($members_id, ","));
		return $renewed_members;
	}
}
