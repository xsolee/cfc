<div class="kt-container  kt-container--fluid  kt-grid__item kt-grid__item--fluid">
	<div class="row">
		<div class="col-md-5">
			<div class="kt-portlet">
				<div class="kt-portlet__head">
					<div class="kt-portlet__head-label">
						<h3 class="kt-portlet__head-title">
							Edit Bank Information
						</h3>
					</div>
				</div>
				<form class="kt-form kt-form--label-right" id="sub_register_form">
					<div class="kt-portlet__body">
						<div class="form-group">
							<label for="bank_name">Bank Name</label>
							<select class="form-control selectpicker" tabindex="-1" name="bank_name" required>
								<option value="Banco de Oro">Banco de Oro</option>
							</select>
						</div>
						<div class="form-group">
							<label for="account_name">Account Name</label>
							
							<input type="text" class="form-control" name="account_name" value="<?php echo $bank->account_name; ?>" readonly>
						</div>
						<div class="form-group">
							<label for="account_number">Account Number</label>
							
							<input type="text" class="form-control" name="account_number" value="<?php echo $bank->account_number; ?>">
						</div>
						<div class="form-group">
							<label for="account_type">Account Type</label>
							
							<select class="form-control selectpicker" tabindex="-1" name="account_type" required>
								<option value="Savings">Savings</option>
								<option value="Checking">Checking</option>
							</select>
						</div>
						<input type="text" name="bank_id" value="<?php echo $bank->bank_id; ?>" hidden>
					</div>
					<div class="kt-portlet__foot kt-align-right">
						<button type="button" class="btn btn-sm btn-label-success btn-bold btn-upper" id="btn_register">Update</button>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>

<!-- <section class="content">
	<div class="register-box-body col-md-6" style="float: none; ">
		<div class="alert alert-warning alert-dismissible" hidden>
			<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
			<h4><i class="icon fa fa-warning"></i> Alert!</h4>
			<p id="message"></p>
		</div>
		<form id="sub_register_form" class="form-horizontal" id="register_form" method="post">
			<div class="box-body">
				<div class="form-group">
					<label for="bank_name" class="col-sm-3 control-label">Bank Name</label>
					<div class="col-sm-9">
						<select class="form-control selectpicker" tabindex="-1" name="bank_name" required>
							<option value="Banco de Oro">Banco de Oro</option>
						</select>
					</div>
				</div>
				<div class="form-group">
					<label for="account_name" class="col-sm-3 control-label">Account Name</label>
					<div class="col-sm-9">
						<input type="text" class="form-control" name="account_name" value="<?php echo $bank->account_name; ?>" readonly>
					</div>
				</div>
				<div class="form-group">
					<label for="account_number" class="col-sm-3 control-label">Account Number</label>
					<div class="col-sm-9">
						<input type="text" class="form-control" name="account_number" value="<?php echo $bank->account_number; ?>">
					</div>
				</div>
				<div class="form-group">
					<label for="account_type" class="col-sm-3 control-label">Account Type</label>
					<div class="col-sm-9">
						<select class="form-control selectpicker" tabindex="-1" name="account_type" required>
							<option value="Savings">Savings</option>
							<option value="Checking">Checking</option>
						</select>
					</div>
				</div>
				<input type="text" name="bank_id" value="<?php echo $bank->bank_id; ?>" hidden>
			</div>
			<div class="box-footer">
				<div class="col-md-6" style="float: none; margin: 0 auto; ">
					<button type="button" class="btn btn-danger btn-block btn-flat" id="btn_register">Update</button>
				</div>
			</div>
		</form>
	</div>
</section> -->
<script type="text/javascript">
	$(document).ready(function(){
		$('#datepicker').datepicker({
			autoclose: true,
			format: 'yyyy-mm-dd'
		});
		$('body').on('click','#btn_register', function(){
			$.ajax({
                type: 'POST',
                url: '<?php echo base_url();?>Bank/update_bank',
                data: $('#sub_register_form').serialize(),
                success: function(data) 
                {
                    if (data.search("Success") != -1) {
                    	// $(".alert").attr("hidden",false);
                        swal.fire("Success!", "Bank Information Edited!", "success");
                        $("html, body").animate({ scrollTop: 0 }, "slow");
                    	window.location.replace('<?php echo base_url('bank/banks');?>');
                    } else {
                        // $(".alert").attr("hidden",false);
                        swal.fire("Error!", data, "error");
                        // $('#message').text(data);
                        $("html, body").animate({ scrollTop: 0 }, "slow");
                    }
                }
            });
		});
	});
</script>