<div class="kt-container kt-container--fluid kt-grid__item kt-grid__item--fluid">
	<div class="kt-portlet kt-portlet--mobile kt-portlet--height-fluid-">
		<div class="kt-portlet__head kt-portlet__head--lg">
			<div class="kt-portlet__head-label">
				<span class="kt-portlet__head-icon">
					<i class="kt-font-brand flaticon2-line-chart"></i>
				</span>
				<h3 class="kt-portlet__head-title">
					Banks Information
				</h3>
			</div>
			<div class="kt-portlet__head-toolbar">
				<button type="button" class="btn btn-sm btn-label-success btn-bold btn-upper" data-toggle="modal" data-target="#add_bank_modal">Add Bank</button>
			</div>
		</div>
		<div class="kt-portlet__body banks_table">
			<?php echo $this->load->view('bank/banks_table', NULL, TRUE); ?>
		</div>
	</div>
</div>

<div class="modal fade" id="add_bank_modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" >
	<div class="modal-dialog modal-dialog-centered">
		<div class="modal-content">
			<form id="add_bank_form" method="POST" enctype="multipart/form-data">
				<div class="modal-header">
					<h5 class="modal-title" id="myModalLabel">Add Bank Details</h5>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"></button>
				</div>
				<div class="modal-body">
					<div class="form-group">
						<label for="bank_name" class="col-md-3 control-label">Bank Name</label>
						<select class="form-control selectpicker" tabindex="-1" name="bank_name" required>
							<option value="BDO">BDO</option>
							<option value="BPI">BPI</option>
							<option value="Union Bank">Union Bank</option>
							<option value="Security Bank">Security Bank</option>
							<option value="AUB Bank">AUB Bank</option>
							<option value="RCBC">RCBC</option>
							<option value="UCPB">UCPB</option>
							<option value="Samba">Samba</option>
							<option value="Sab">Sab</option>
						</select>
					</div>
					<div class="form-group">
						<label for="account_name">Account Name</label>
						<input type="text" class="form-control" name="account_name" value="<?php echo ucwords($this->session->userdata()['firstname']).' '.ucwords($this->session->userdata()['lastname']); ?>" readonly>
					</div>
					<div class="form-group">
						<label for="account_number">Account Number</label>
						<input type="text" class="form-control" name="account_number">
					</div>
					<div class="form-group">
						<label for="account_type">Account Type</label>
						<select class="form-control selectpicker" tabindex="-1" name="account_type" required>
							<option value="Savings">Savings</option>
							<option value="Checking">Checking</option>
						</select>
					</div>
					<input type="hidden" name="account_id" value="<?php echo $this->session->userdata()['user_id']; ?>">
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
					<button type="submit" class="btn btn-primary">Add Bank</button>
				</div>
			</form>
		</div>
	</div>
</div>


<script type="text/javascript">

	$(document).ready(function(){
		$('#banks_table').DataTable({
            "order": [1, 'desc'],
			responsive: true
        });
        $('#add_bank_modal').modal('hide');


        $('body').on('submit','#add_bank_form', function(){
            event.preventDefault();

            $.ajax({
				type: 'POST',
				url: "<?php echo base_url('Bank/add_bank'); ?>",
				data: $('#add_bank_form').serialize(),

				success: function(data) {
					data = JSON.parse(data);
					if(data.message == 'Success') {
						notifyme('glyphicon glyphicon-exclamation-sign','Success','success');
						$('#add_bank_modal').modal('hide');
						$('.banks_table').html(data.table);
						$('#banks_table').DataTable({
				            "order": [1, 'desc']
				        });
					} else {
						notifyme('glyphicon glyphicon-exclamation-sign','Bank account already exist!','danger');
					}
					
				}
			});
        });

	});

	function remove_bank(id, currentElement) {
		$.ajax({
			type: 'POST',
			url: "<?php echo base_url('Bank/remove_bank'); ?>",
			data: {id: id},

			success: function(data) {
				currentElement.closest('tr').remove();
				data = JSON.parse(data);
				$(".alert").attr('hidden', false);
				$("#message").text(data.message);
				$("html, body").animate({ scrollTop: 0 }, "slow");
			}
		});
	}

	function loader()
    {
        $(document).ajaxStart(
            $.blockUI({ 
                message: '<img src="<?php echo base_url('resources/images/ajax-loader.gif');?>"/>Please wait..',
                css: {
                    border:          'none',
                    backgroundColor: 'transparent'
                }
            })
        ).ajaxStop($.unblockUI);
    }

    function notifyme(icon,message,type)
    {
        $.notify({
            icon: icon,
            message: message 
        },{
            type: type,
            animate: {
                enter: 'animated bounceInDown',
                exit: 'animated bounceOutUp'
            },
            z_index: 2000,
            delay: 2000,
            timer: 1000,
            allow_dismiss: false
        });
    }

</script>