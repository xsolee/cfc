<table id="banks_table" class="table table-striped table-hover nowrap table-bordered" style="width:100%;">
	<thead>
		<tr>
			<th>Action</th>
			<th>ID</th>
			<th>Bank Name</th>
			<th>Account Name</th>
			<th>Account Number</th>
			<th>Account Type</th>
			
		</tr>
	</thead>
	<tbody>
		<?php foreach($banks as $bank) { ?>
			<tr>
				<td class="actions">
					<a class="btn btn-sm btn-label-danger" href="<?php echo base_url('Bank/edit_bank') . '/' . $bank->bank_id; ?>" title="Edit"><i class="fa fa-pencil-alt"></i></a>
					<!-- <a class="btn btn-danger btn" onclick="remove_bank(<?php echo $bank->bank_id; ?>, this)" title="Delete"><i class="fa fa-trash"></i></a> -->
				</td>
				<td><?php echo $bank->bank_id; ?></td>
				<td><?php echo $bank->bank_name; ?></td>
				<td><?php echo $bank->account_name; ?></td>
				<td><?php echo $bank->account_number; ?></td>
				<td><?php echo $bank->account_type; ?></td>
				
			</tr>
		<?php } ?>
	</tbody>
</table>