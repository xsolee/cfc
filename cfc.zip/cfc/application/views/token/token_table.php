<table id="token_table" class="table table-striped table-hover nowrap table-bordered" style="width:100%;">
    <thead>
        <tr>
            <th>ID</th>
            <?php if($this->session->userdata()['user_id'] == "0000001") {?>
                <th>Account ID</th>
                <th>Username</th>
                <th>Mobile No</th>
            <?php } ?>
            <th>Token Type</th>
            <th>Serial Number</th>
            <th>Combination</th>
            <th>Status</th>
            <th>Created Date</th>
        </tr>
    </thead>
    <tbody>
        <?php $ctr = 1; foreach($result as $row) { ?>
            <tr class="tr-hover">
                <td><?php echo $ctr++; ?></td>
                <?php if($this->session->userdata()['user_id'] == "0000001") {?>
                    <td><?php echo $row->account_id; ?></td>
                    <td><?php echo $row->username; ?></td>
                    <td><?php echo $row->mobile_number; ?></td>
                <?php } ?>
                <td><?php echo ($row->batch_id == 1)? 'Gold' : 'Diamond'; ?></td>
                <td><?php echo $row->serial_number; ?></td>
                <td><?php echo $row->combination1 . '-' . $row->combination2 . '-' . $row->combination3; ?></td>
                <td><?php echo $row->winner_combination1? "Ended": ($row->date_drawn? "To be drawn": "Ongoing"); ?></td>
                <td><?php echo $row->created_date; ?></td>
            </tr>
        <?php } ?>
    </tbody>
</table>