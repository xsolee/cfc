<div class="kt-container kt-container--fluid kt-grid__item kt-grid__item--fluid">
    <div class="kt-portlet kt-portlet--mobile kt-portlet--height-fluid-">
        <div class="kt-portlet__head kt-portlet__head--lg">
            <div class="kt-portlet__head-label">
                <span class="kt-portlet__head-icon">
                    <i class="kt-font-brand flaticon2-line-chart"></i>
                </span>
                <h3 class="kt-portlet__head-title">
                    CFC Exclusive
                </h3>
            </div>
        </div>
        <div class="kt-portlet__body">
            <?php echo $this->load->view('token/token_gaming_table', NULL, TRUE); ?>
        </div>
    </div>
</div>

<div class="modal fade" id="end_game_modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" >
    <div class="modal-dialog modal-sm modal-dialog-centered">
        <div class="modal-content">
            <form id="end_game_form" method="POST">
                <input type="hidden" class="form-control" id="header_id" name="header_id">
                <div class="modal-header">
                    <h5 class="modal-title" id="myModalLabel">Are you sure you want to end this?</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    </button>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">No</button>
                    <button type="submit" class="btn btn-primary" id="btn_end_game">Yes</button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="add_winner_combination_modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" >
    <div class="modal-dialog modal-sm modal-dialog-centered">
        <div class="modal-content">
            <form id="add_winner_combination_form" method="POST">
                <div class="modal-header">
                    <h5 class="modal-title" id="myModalLabel">Enter winner combination</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"> </button>
                </div>
                <div class="modal-body">
                    <input type="hidden" id="header_id" name="header_id">
                    <div class="form-group">
                        <label for="winner_combination1" class="form-control-label">1st Digit</label>
                        <input type="number" class="form-control" id="winner_combination1" name="winner_combination1" placeholder="1" required max="42" min="1">
                    </div>
                    <div class="form-group">
                        <label for="winner_combination2" class="form-control-label">2nd Digit</label>
                        <input type="number" class="form-control" id="winner_combination2" name="winner_combination2" placeholder="1" required max="42" min="1">
                    </div>
                    <div class="form-group">
                        <label for="winner_combination3" class="form-control-label">3rd Digit</label>
                        <input type="number" class="form-control" id="winner_combination3" name="winner_combination3" placeholder="1" required max="42" min="1">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">No</button>
                    <button type="submit" class="btn btn-primary" id="btn_add_winner_combination">Yes</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script type="text/javascript">
    $(document).ready(function(){
        $('#token_gaming_table').DataTable({
            "order": [0, 'desc'],
            "iDisplayLength": 25,
            responsive: true
        });

        $('body').on('click','#end_game', function(){
            $('#end_game_modal #header_id').val($(this).attr('data-header_id'));
            $('#end_game_modal').modal('show'); 
        });

        $('body').on('click','#add_winner_combination', function(){
            $('#add_winner_combination_modal #header_id').val($(this).attr('data-header_id'));
            $('#add_winner_combination_modal').modal('show'); 
        });

        toastr.options = {
          "closeButton": false,
          "debug": false,
          "newestOnTop": false,
          "progressBar": false,
          "positionClass": "toast-top-right",
          "preventDuplicates": false,
          "onclick": null,
          "showDuration": "300",
          "hideDuration": "1000",
          "timeOut": "5000",
          "extendedTimeOut": "1000",
          "showEasing": "swing",
          "hideEasing": "linear",
          "showMethod": "fadeIn",
          "hideMethod": "fadeOut"
        };

        $( "#end_game_form" ).validate({
            // define validation rules
            rules: {
                header_id : {
                    required: true
                }
            },
            
            invalidHandler: function(event, validator) {     
                swal.fire("Error!", "Please fill all required fields and try submitting again.", "warning");
            },

            submitHandler: function (form) {
                $.ajax({
                    type: 'POST',
                    url: '<?php echo base_url();?>token_gaming/end_game',
                    data: $('#end_game_form').serialize(),
                    success: function(data) 
                    {
                        $('.token_gaming_table').html(data);
                        token_gaming_table = $('#token_gaming_table').DataTable({
                            "order": [0, 'desc'],
                            "iDisplayLength": 25,
                            responsive: true
                        });

                        $('#end_game_modal').modal('toggle');

                        toastr.success("Successfully stopped!");
                    }
                });
            }
        });

        $( "#add_winner_combination_form" ).validate({
            // define validation rules
            rules: {
                header_id : {
                    required: true
                },
                winner_combination1 : {
                    required: true
                },
                winner_combination2 : {
                    required: true
                },
                winner_combination3 : {
                    required: true
                }
            },
            
            invalidHandler: function(event, validator) {     
                swal.fire("Error!", "Please fill all required fields and try submitting again.", "warning");
            },

            submitHandler: function (form) {
                if(check_valid_combination()) {
                    $.ajax({
                        type: 'POST',
                        url: '<?php echo base_url();?>token_gaming/add_winner_combination',
                        data: $('#add_winner_combination_form').serialize(),
                        success: function(data) 
                        {
                            $('.token_gaming_table').html(data);
                            token_gaming_table = $('#token_gaming_table').DataTable({
                                "order": [0, 'desc'],
                                "iDisplayLength": 25,
                                responsive: true
                            });

                            $('#add_winner_combination_modal').modal('toggle');

                            toastr.success("Successfully added winner combination!");
                        }
                    });
                } else {
                    toastr.error("Not valid combination!");
                }
            }
        });

        function check_valid_combination()
        {
            $1st = $('#winner_combination1').val();
            $2nd = $('#winner_combination2').val();
            $3rd = $('#winner_combination3').val();
            if($1st>0 && $1st<54 && $2nd>0 && $2nd<54 && $3rd>0 && $3rd<54 && $1st!=$2nd && $2nd!=$3rd && $1st!=$3rd) return true;
            else return false;
        }

    });

</script>