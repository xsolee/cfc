<table id="token_gaming_table" class="table table-striped table-hover nowrap table-bordered" style="width:100%;">
    <thead>
        <tr>
            <th>Action</th>
            <th>No.</th>
            <th>Type</th>
            <th>Tokens</th>
            <th>Created Date</th>
            <th>Winner Combination</th>
            <th>Winner</th>
            <th>Date Drawn</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach($result as $row) { ?>
            <tr class="tr-hover">
                <td>
                    <?php if ($row->date_drawn == NULL) { ?>
                        <button id="end_game" class="btn btn-sm btn-clean btn-icon btn-icon-lg" data-toggle="tooltip" title="Stop to draw Winner" data-header_id ="<?php echo $row->id; ?>">
                            <i class="flaticon2-close-cross"></i>
                        </button>
                    <?php } ?>
                    <?php if($row->winner_combination1 == NULL && $row->date_drawn != NULL) { ?>
                        <button id="add_winner_combination" class="btn btn-sm btn-clean btn-icon btn-icon-lg" data-toggle="tooltip" title="Add Winner Combination" data-header_id ="<?php echo $row->id; ?>">
                            <i class="flaticon-trophy"></i>
                        </button>
                    <?php } ?>
                </td>
                <td><?php echo $row->id; ?></td>
                <td><?php echo $row->batch_id==1? "Gold":"Diamond"; ?></td>
                <td><?php echo $row->token_count; ?></td>
                <td><?php echo $row->created_date; ?></td>
                <td><?php echo $row->winner_combination1 . '-' . $row->winner_combination2 . '-' . $row->winner_combination3; ?></td>
                <td><?php echo $row->username; ?></td>
                <td><?php echo $row->date_drawn; ?></td>
            </tr>
        <?php } ?>
    </tbody>
</table>