<div class="kt-container kt-container--fluid kt-grid__item kt-grid__item--fluid">
    <?php if(!$this->session->userdata()['activated']) { ?>
        <div class="row col-md-6">
            <div class="alert alert-warning alert-elevate fade show" role="alert">
                <div class="alert-icon"><i class="flaticon-warning"></i></div>
                <div class="alert-text">
                    To use this feature, please activate your account!
                </div>
            </div>
        </div>
    <?php } ?>
    <div class="kt-portlet kt-portlet--mobile kt-portlet--height-fluid-">
        <div class="kt-portlet__head kt-portlet__head--lg">
            <div class="kt-portlet__head-label">
                <span class="kt-portlet__head-icon">
                    <i class="kt-font-brand flaticon2-line-chart"></i>
                </span>
                <h3 class="kt-portlet__head-title">
                    CFC Exclusive Tokens
                </h3>
            </div>
            <div class="kt-portlet__head-toolbar">
                <?php if($this->session->userdata()['activated']) { ?>
                    <div class="row">
                        <button type="button" class="btn btn-sm btn-label-success btn-bold btn-upper" data-toggle="modal" data-target="#token_game">Add token </button>
                    </div>
                <?php } ?>
            </div>
        </div>
        <div class="kt-portlet__body token_table">
            <?php echo $this->load->view('token/token_table', NULL, TRUE); ?>
        </div>
    </div>
</div>

<div class="modal fade" id="token_game" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" >
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <form id="token_game_form" method="POST" enctype="multipart/form-data">
                <div class="modal-header">
                    <h5 class="modal-title" id="myModalLabel">CFC Exclusive</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="accordion accordion-light  accordion-svg-icon" id="accordionExample7">
                        <div class="card">
                            <div class="card-header" id="headingOne7">
                                <div class="card-title collapsed" data-toggle="collapse" data-target="#collapseOne7" aria-expanded="false" aria-controls="collapseOne7">
                                    <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="24px" height="24px" viewBox="0 0 24 24" version="1.1" class="kt-svg-icon">
                                        <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                                            <polygon id="Shape" points="0 0 24 0 24 24 0 24" />
                                            <path d="M12.2928955,6.70710318 C11.9023712,6.31657888 11.9023712,5.68341391 12.2928955,5.29288961 C12.6834198,4.90236532 13.3165848,4.90236532 13.7071091,5.29288961 L19.7071091,11.2928896 C20.085688,11.6714686 20.0989336,12.281055 19.7371564,12.675721 L14.2371564,18.675721 C13.863964,19.08284 13.2313966,19.1103429 12.8242777,18.7371505 C12.4171587,18.3639581 12.3896557,17.7313908 12.7628481,17.3242718 L17.6158645,12.0300721 L12.2928955,6.70710318 Z" id="Path-94" fill="#000000" fill-rule="nonzero" />
                                            <path d="M3.70710678,15.7071068 C3.31658249,16.0976311 2.68341751,16.0976311 2.29289322,15.7071068 C1.90236893,15.3165825 1.90236893,14.6834175 2.29289322,14.2928932 L8.29289322,8.29289322 C8.67147216,7.91431428 9.28105859,7.90106866 9.67572463,8.26284586 L15.6757246,13.7628459 C16.0828436,14.1360383 16.1103465,14.7686056 15.7371541,15.1757246 C15.3639617,15.5828436 14.7313944,15.6103465 14.3242754,15.2371541 L9.03007575,10.3841378 L3.70710678,15.7071068 Z" id="Path-94" fill="#000000" fill-rule="nonzero" opacity="0.3" transform="translate(9.000003, 11.999999) rotate(-270.000000) translate(-9.000003, -11.999999) " />
                                        </g>
                                    </svg> Available Funds
                                </div>
                            </div>
                            <div id="collapseOne7" class="collapse" aria-labelledby="headingOne7" data-parent="#accordionExample7">
                                <div class="card-body">
                                    <p id="p_current_free_token">Free Token: <?php echo amount_format( $current_free_token ,2); ?></p> 
                                    <p id="p_current_rewards">Rewards: <?php echo amount_format( $current_rewards ,2); ?></p> 
                                    <p id="p_current_cfc_ws">CFC WS: <?php echo amount_format( $current_cfc_ws ,2); ?></p> 
                                    <p id="p_current_cfc_exclusive">CFC Exclusive: <?php echo amount_format( $current_cfc_exclusive ,2); ?></p> 
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="rewards_type" class="form-control-label">Rewards Type: </label>
                        <select class="form-control selectpicker" tabindex="-1" id="rewards_type" name="rewards_type" required>
                            <option value="Free Token">Free Token</option>
                            <option value="Rewards">Rewards</option>
                            <option value="CFC WS">CFC WS</option>
                            <option value="CFC Exclusive">CFC Exclusive</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="token_type" class="form-control-label">Type</label>
                        <select class="form-control selectpicker" tabindex="-1" id="token_type" name="token_type" required>
                            <?php foreach($token_headers as $row) { ?>
                                <option value="<?php echo $row->batch_id; ?>"><?php echo ($row->batch_id == 1)? 'Gold' : 'Diamond'; ?></option>
                            <?php } ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="no_of_token" class="form-control-label">No of token</label>
                        <input type="number" class="form-control" id="no_of_token" name="no_of_token" placeholder="No of token" value = "5" required>
                    </div>
                    <div class="form-group">
                        <label for="total_amount" class="form-control-label">Total Amount</label>
                        <input type="text" class="form-control" id="total_amount" name="total_amount" placeholder="Total Amount" value="5" readonly>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Generate Token</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script type="text/javascript">
    $(document).ready(function(){
        var token_table = $('#token_table').DataTable({
            "order": [0, 'desc'],
            "responsive": true
        });

        $('#token_type').on('change', function(){
            var token_type = $(this).val();
            var no_of_token = $('#no_of_token').val();
            if(token_type == 2) {
                no_of_token = no_of_token * 10;
            }
            $('#total_amount').val(numberWithCommas(no_of_token));
        });

        $('#no_of_token').on('input', function(){
            var no_of_token = $(this).val();
            var token_type = $('#token_type').val();
            if(token_type == 2) {
                no_of_token = no_of_token * 10;
            }

            $('#total_amount').val(numberWithCommas(no_of_token));
        });

        function numberWithCommas(number) {
            var parts = number.toString().split(".");
            parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
            return parts.join(".");
        }

        toastr.options = {
          "closeButton": false,
          "debug": false,
          "newestOnTop": false,
          "progressBar": false,
          "positionClass": "toast-top-right",
          "preventDuplicates": false,
          "onclick": null,
          "showDuration": "300",
          "hideDuration": "1000",
          "timeOut": "5000",
          "extendedTimeOut": "1000",
          "showEasing": "swing",
          "hideEasing": "linear",
          "showMethod": "fadeIn",
          "hideMethod": "fadeOut"
        };

        $( "#token_game_form" ).validate({
            // define validation rules
            rules: {
                token_type : {
                    required: true
                },
                rewards_type : {
                    required: true
                },
                no_of_token : {
                    required: true
                },
                total_amount : {
                    required: true
                }
            },
            
            invalidHandler: function(event, validator) {     
                swal.fire("Error!", "Please fill all required fields and try submitting again.", "warning");
            },

            submitHandler: function (form) {
                if( $('#no_of_token').val() < 5 && $('#rewards_type').val() != "Free Token" ){
                    toastr.error("Minimum is 5 Tokens!");
                } else {
                    $.ajax({
                        type: 'POST',
                        url: "<?php echo base_url('token_gaming/generate_token'); ?>",
                        data: $('#token_game_form').serialize(),
                        success: function(data) 
                        {
                            var data = JSON.parse(data);
                            if(data.message == 'Success') {
                                $('.token_table').html(data.table);

                                token_table = $('#token_table').DataTable({
                                    "order": [0, 'desc'],
                                    "responsive": true
                                });

                                $('.modal-body #p_current_free_token').text("Available Free Token: "+data.current_free_token);
                                $('.modal-body #p_current_rewards').text("Available Rewards: "+data.current_rewards);
                                $('.modal-body #p_current_cfc_ws').text("Available CFC WS: "+data.current_cfc_ws);
                                $('.modal-body #p_current_cfc_exclusive').text("Available CFC Exclusive: "+data.current_cfc_exclusive);


                                $('#token_game').modal('hide');
                                toastr.success("Success!");
                            } else {
                                toastr.error(data.message);
                            }
                        }
                    });
                }
            }
        });

    });

</script>