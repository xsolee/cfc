<section class="content">

    <div class="row">

        <div class="col-md-4">

            <div class="box box-darkbrown" id="content">

                

                <form id="generate_pins_form" role="form" method="POST" enctype="multipart/form-data">

                    <div class="box-body">

                        <div class="alert alert-warning alert-dismissible" hidden>
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                            <h4><i class="icon fa fa-warning"></i> Alert!</h4>
                            <p id="message"></p>
                        </div>

                        <div class="col-md-12">
                            <div class="form-group">
                                <label for="pin">Pin</label>
                                <input type="text" class="form-control" id="pin" name="pin">
                            </div>
                        </div>

                        <div class="col-md-12">
                            <div class="form-group">
                                <label for="no_of_share">No of Share</label>
                                <input type="text" class="form-control" id="no_of_share" name="no_of_share">
                            </div>
                        </div>

                        <div class="col-md-12">
                            <div class="form-group">
                                <label for="shares_amount">Shares Amount</label>
                                <input type="text" class="form-control" id="shares_amount" name="shares_amount" readonly>
                            </div>
                        </div>

                        <div class="col-md-12">
                            <div class="form-group">
                                <label for="daily_profit">Daily Profit</label>
                                <input type="text" class="form-control" id="daily_profit" name="daily_profit" readonly>
                            </div>
                        </div>

                        <div class="col-md-12">
                            <div class="form-group">
                                <label for="total_income">Total Income (After 480 Days)</label>
                                <input type="text" class="form-control" id="total_income" name="total_income" readonly>
                            </div>
                        </div>


                    </div>

                    <div class="box-footer">
                        <button type="button" class="btn btn-success btn-flat pull-right" id="btn_save">Invest</button>
                    </div>

                </form>

            </div>

        </div>

    </div>

</section>



<script type="text/javascript">

    $(document).ready(function() {


        $('#no_of_share').on('input', function(){
            var no_of_share = $(this).val();
            $('#shares_amount').val(numberWithCommas(no_of_share * 2000));
            $('#daily_profit').val(numberWithCommas(no_of_share * 8.50));
            $('#total_income').val(numberWithCommas((no_of_share * 8.50) * 480));
        });

        $('#btn_save').on('click', function(){
            $.ajax({
                type: 'POST',
                url: '<?php echo base_url();?>affiliate_shares/save_affiliate_shares',
                data: $('#generate_pins_form').serialize(),

                success: function(data) 
                {
                    if(data == 1) {
                        $(".alert").attr("hidden",false);
                        $('#message').text('Invalid Pin');
                    } else {
                        window.location.href = "<?php echo base_url('affiliate_shares/investment'); ?>";
                    }
                }
            });
        });

        function numberWithCommas(number) {
            var parts = number.toString().split(".");
            parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
            return parts.join(".");
        }

    });

</script>