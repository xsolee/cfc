<div class="kt-container kt-container--fluid kt-grid__item kt-grid__item--fluid">
    <?php if(!$this->session->userdata()['activated']) { ?>
        <div class="row col-md-6">
            <div class="alert alert-warning alert-elevate fade show" role="alert">
                <div class="alert-icon"><i class="flaticon-warning"></i></div>
                <div class="alert-text">
                    To use this feature, please activate your account!
                </div>
            </div>
        </div>
    <?php } ?>
    <div class="kt-portlet kt-portlet--mobile kt-portlet--height-fluid-">
        <div class="kt-portlet__head kt-portlet__head--lg">
            <div class="kt-portlet__head-label">
                <span class="kt-portlet__head-icon">
                    <i class="kt-font-brand flaticon2-line-chart"></i>
                </span>
                <h3 class="kt-portlet__head-title">
                    Cfc WS Rewards
                </h3>
            </div>
            <div class="kt-portlet__head-toolbar">
                <?php if($this->session->userdata()['activated']) { ?>
                    <div class="row">
                        <button type="button" class="btn btn-sm btn-label-success btn-bold btn-upper" data-toggle="modal" data-target="#invest_modal">Add CFC WS </button>
                    </div>
                <?php } ?>
            </div>
        </div>
        <div class="kt-portlet__body">
            <div class="kt-widget kt-widget--user-profile-2">
                <div class="kt-widget__body">
                    <div class="kt-widget__content">
                        <div class="col-md-12">
                            <div class="row">
                                <div class="col-md-3">
                                    <div class="kt-widget__stats">
                                        <div class="kt-widget__icon">
                                            <i class="flaticon-piggy-bank"></i>
                                        </div>
                                        <div class="kt-widget__details">
                                            <span class="kt-widget__title">Total</span>
                                            <span class="kt-widget__value"><?php echo amount_format($money->total_affiliate_share); ?></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="kt-widget__stats">
                                        <div class="kt-widget__icon">
                                            <i class="flaticon-piggy-bank"></i>
                                        </div>
                                        <div class="kt-widget__details">
                                            <span class="kt-widget__title">Re-purchase</span>
                                            <span class="kt-widget__value"><?php echo amount_format($money->reinvest_affiliate_shares); ?></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="kt-widget__stats">
                                        <div class="kt-widget__icon">
                                            <i class="flaticon-piggy-bank"></i>
                                        </div>
                                        <div class="kt-widget__details">
                                            <span class="kt-widget__title">Withdrawn</span>
                                            <span class="kt-widget__value"><?php echo amount_format($money->withdrawn_affiliate_share); ?></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="kt-widget__stats">
                                        <div class="kt-widget__icon">
                                            <i class="flaticon-piggy-bank"></i>
                                        </div>
                                        <div class="kt-widget__details">
                                            <span class="kt-widget__title">Transfered</span>
                                            <span class="kt-widget__value"><?php echo amount_format($money->transfered_affiliate_shares); ?></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="kt-widget__stats">
                                        <div class="kt-widget__icon">
                                            <i class="flaticon-piggy-bank"></i>
                                        </div>
                                        <div class="kt-widget__details">
                                            <span class="kt-widget__title">Received</span>
                                            <span class="kt-widget__value"><?php echo amount_format($money->received_affiliate_shares); ?></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="kt-widget__stats">
                                        <div class="kt-widget__icon">
                                            <i class="flaticon-piggy-bank"></i>
                                        </div>
                                        <div class="kt-widget__details">
                                            <span class="kt-widget__title">Withdrawn Received</span>
                                            <span class="kt-widget__value"><?php echo amount_format($money->withdrawn_affiliate_share_2); ?></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="kt-widget__stats">
                                        <div class="kt-widget__icon">
                                            <i class="flaticon-piggy-bank"></i>
                                        </div>
                                        <div class="kt-widget__details">
                                            <span class="kt-widget__title">Transfered Received</span>
                                            <span class="kt-widget__value"><?php echo amount_format($money->transfered_affiliate_shares_2); ?></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="kt-widget__stats">
                                        <div class="kt-widget__icon">
                                            <i class="flaticon-piggy-bank"></i>
                                        </div>
                                        <div class="kt-widget__details">
                                            <span class="kt-widget__title">Current</span>
                                            <span class="kt-widget__value"><?php echo amount_format(($money->total_affiliate_share + $money->received_affiliate_shares) - ($money->reinvest_affiliate_shares + $money->withdrawn_affiliate_share + $money->withdrawn_affiliate_share_2 + $money->transfered_affiliate_shares + $money->transfered_affiliate_shares_2)); ?></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="investment_table">
                <?php echo $this->load->view('affiliate_share/investment_table', NULL, TRUE); ?>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="invest_modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" >
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <form id="invest_form" method="POST" enctype="multipart/form-data">
                <div class="modal-body">
                    <div class="modal-header">
                        <h5 class="modal-title" id="myModalLabel">Add Cfc WS Products</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="col-md-12">
                            <div class="form-group">
                                <label for="pin">Pin</label>
                                <input type="text" class="form-control" id="pin" name="pin">
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group">
                                <label for="no_of_share">No of Accounts</label>
                                <input type="number" class="form-control" id="no_of_share" name="no_of_share" min="0">
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group">
                                <label for="shares_amount">Funds</label>
                                <input type="text" class="form-control" id="shares_amount" name="shares_amount" readonly>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group">
                                <label for="daily_profit">Daily Reward</label>
                                <input type="text" class="form-control" id="daily_profit" name="daily_profit" readonly>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group">
                                <label for="total_income">Total Rewards (After 365 Days)</label>
                                <input type="text" class="form-control" id="total_income" name="total_income" readonly>
                            </div>
                        </div>
                    </div>
                    <input type="hidden" name="account_id" value="<?php echo $this->session->userdata()['user_id']; ?>">
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Escrow</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script type="text/javascript">
    $(document).ready(function(){

        $('#invest_modal').modal('hide');

        $('#investment_table').DataTable({
            "order": [8, 'desc'],
            "iDisplayLength": 25,
            responsive: true
        });

        $('#no_of_share').on('input', function(){
            var no_of_share = $(this).val();
            if(no_of_share == 0) {
                no_of_share = 0.5;
            }
            $('#shares_amount').val(numberWithCommas(no_of_share * 100));
            $('#daily_profit').val(numberWithCommas(no_of_share * 1.5));
            $('#total_income').val(numberWithCommas((no_of_share * 1.50) * 365));
        });

        function numberWithCommas(number) {
            var parts = number.toString().split(".");
            parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
            return parts.join(".");
        }


        $( "#invest_form" ).validate({
            // define validation rules
            rules: {
                pin : {
                    required: true
                },
                no_of_share : {
                    required: true
                }
            },
            
            invalidHandler: function(event, validator) {     
                swal.fire("Error!", "Please fill all required fields and try submitting again.", "warning");
            },

            submitHandler: function (form) {
                $.ajax({
                    type: 'POST',
                    url: "<?php echo base_url('affiliate_shares/invest'); ?>",
                    data: $('#invest_form').serialize(),

                    success: function(data) {

                        var data = JSON.parse(data);
                        if(data.message == 'Success') {

                            $('.investment_table').html(data.table);

                            buy_pincodes_table = $('#investment_table').DataTable({
                                "order": [8, 'desc'],
                                "iDisplayLength": 25,
                                responsive: true
                            });
                            $('#invest_modal').modal('hide');
                            toastr.success("Success!");
                        } else {
                            toastr.error(data.message);
                        }
                    }
                });
            }
        });

    });

    function loader()
    {
        $(document).ajaxStart(
            $.blockUI({ 
                message: '<img src="<?php echo base_url('resources/images/ajax-loader.gif');?>"/>Please wait..',
                css: {
                    border:          'none',
                    backgroundColor: 'transparent'
                }
            })
        ).ajaxStop($.unblockUI);
    }

</script>