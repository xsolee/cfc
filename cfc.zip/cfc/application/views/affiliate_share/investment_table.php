<table id="investment_table" class="table table-striped table-hover nowrap table-bordered" style="width:100%;">
    <thead>
        <tr>
            <th>No of Accounts</th>
            <th>WS Products</th>
            <th>Daily Reward</th>
            <th>Current Reward</th>
            <th>Maturity Reward</th>
            <th>PIN</th>
            <th>Maturity Date</th>
            <th>Type</th>
            <th>Created Date</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach($result as $row) { ?>
            <tr>
                <td style="text-align: right;"><?php echo $row->no_of_share; ?></td>
                <td style="text-align: right;"><?php echo amount_format($row->shares_amount); ?></td>
                <td style="text-align: right;"><?php echo amount_format($row->daily_profit); ?></td>
                <td style="text-align: right;"><?php echo amount_format($row->total_income_per_day); ?></td>
                <td style="text-align: right;"><?php echo amount_format($row->total_income); ?></td>
                <td><?php echo $row->pin; ?></td>
                <td><?php echo $row->due_date; ?></td>
                <td><?php echo ($row->invest_type != 'Automated')? 'Manual' : 'Automated'; ?></td>
                <td><?php echo (new DateTime($row->created_date))->format('Y-m-d'); ?></td>
            </tr>
        <?php } ?>
    </tbody>
</table>