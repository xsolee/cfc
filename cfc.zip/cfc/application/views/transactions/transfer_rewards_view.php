<div class="kt-container  kt-container--fluid  kt-grid__item kt-grid__item--fluid">
    <div class="row">
		<div class="col-md-6">
    		<div class="kt-portlet kt-portlet--mobile kt-portlet--height-fluid-">
	            <div class="kt-portlet__head kt-portlet__head--lg" >
	                <div class="kt-portlet__head-label">
	                    <h3 class="kt-portlet__head-title">
	                        Transfer Rewards
	                    </h3>
	                </div>
	            </div>
				<form class="form-horizontal" id="transfer_form" method="post">
	            	<div class="kt-portlet__body">
						<div class="col-md-12">
							<div class="form-group">
								<label for="receiver_id">Receiver's Account ID</label>
								<input type="text" class="form-control" name="receiver_id" id="receiver_id" pattern="\d*" maxlength="8">
							</div>
						</div>
						<div class="col-md-12">
							<div class="form-group">
								<label for="amount">Amount</label>
								<input type="number" class="form-control" id="amount" name="amount" min="100">
							</div>
						</div>
						<div class="col-md-12">
							<div class="form-group">
								<label for="transfer_from">Transfer From</label>
								<select class="form-control selectpicker" tabindex="-1" name="transfer_from">
									<option value="Rewards">Rewards</option>
									<option value="CFC Exclusive">CFC Exclusive</option>
									<option value="CFC WS Rewards">CFC WS Rewards</option>
									<option value="CFC WS Received Rewards">CFC WS Received Rewards</option>
									<option value="Forex Unilevel">Forex Unilevel</option>
								</select>
							</div>
						</div>
						<div class="col-md-12">
							<div class="form-group">
								<label for="password">Transfer Password 
									<?php if($hasTransferPassword) echo "<a href='#' data-toggle='modal' data-target='#forgot_transfer_password'>(Forgot Password?)</a>";
										else echo "<a href='#' data-toggle='modal' data-target='#set_transfer_password'>(Set Transfer Password)</a>";
									?>
								</label>
								<input type="password" class="form-control" id="password" name="password">
							</div>
						</div>
					</div>
					<div class="kt-portlet__foot kt-align-right">
						<button type="submit" class="btn btn-brand">Transfer Now</button>
					</div>
				</form>
	        </div>
	     </div>
    </div>
</div>

<div class="modal fade" id="set_transfer_password" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" >
	<div class="modal-dialog modal-sm modal-dialog-centered">
		<div class="modal-content">
			<form id="set_transfer_password_form" method="POST">
				<div class="modal-header">
                    <h5 class="modal-title" id="myModalLabel">Set Transfer Password</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"> </button>
				</div>
				<div class="modal-body">
					<div class="form-group">
						<label for="new_password" class="form-control-label">New Password</label>
						<input type="password" class="form-control" id="new_password" name="new_password" required>
					</div>
					<div class="form-group">
						<label for="confirm_password" class="form-control-label">Retype Password</label>
						<input type="password" class="form-control" id="confirm_password" name="confirm_password" data-rule-equalTo="#new_password" required>
					</div>
				</div>
				<div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary" id="btn_set_transfer_password">Save</button>
				</div>
			</form>
		</div>
	</div>
</div>

<div class="modal fade" id="forgot_transfer_password" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" >
	<div class="modal-dialog modal-sm modal-dialog-centered">
		<div class="modal-content">
			<div class="modal-header">
                <h5 class="modal-title" id="myModalLabel">Forgot Password?</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"> </button>
			</div>
			<div class="modal-body">
				<p>
					Click button below to reset tranfer password.
				</p>
			</div>
			<div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                <button type="submit" class="btn btn-primary" id="btn_reset_transfer_password">Reset Password</button>
			</div>
		</div>
	</div>
</div>

<script type="text/javascript">
	$(document).ready(function(){

        toastr.options = {
          "closeButton": false,
          "debug": false,
          "newestOnTop": false,
          "progressBar": false,
          "positionClass": "toast-top-right",
          "preventDuplicates": false,
          "onclick": null,
          "showDuration": "300",
          "hideDuration": "1000",
          "timeOut": "5000",
          "extendedTimeOut": "1000",
          "showEasing": "swing",
          "hideEasing": "linear",
          "showMethod": "fadeIn",
          "hideMethod": "fadeOut"
        };

		$( "#transfer_form" ).validate({
            // define validation rules
            rules: { 
                amount : {
                    required: true,
                    min: 100
                },
                receiver_id : {
                    required: true,
					maxlength: 8
                },
                transfer_from : {
                    required: true
                },
                password : {
                    required: true
                }
            },
            
            invalidHandler: function(event, validator) {     
                swal.fire("Error!", "Please fill all required fields and try submitting again.", "warning");
            },

            submitHandler: function (form) {
                $.ajax({
                    type: 'POST',
					url: "<?php echo base_url('transaction/transfer'); ?>",
                    data: $('#transfer_form').serialize(),
                    success: function(data) 
                    {
                    	if(data.search("Error") != -1){
							toastr.error(data);
						} else {
							window.location.replace("<?php echo base_url('transaction/history'); ?>");
						}
                    }
                });
            }
        });

		$( "#set_transfer_password_form" ).validate({
            // define validation rules
            rules : {
				new_password : {
                    required: true,
					minlength : 5
				},
				confirm_password : {
                    required: true,
					minlength : 5,
					equalTo : "#new_password"
				}
			},
            
            invalidHandler: function(event, validator) {     
                swal.fire("Error!", "Please fill all required fields and try submitting again.", "warning");
            },

            submitHandler: function (form) {
                $.ajax({
                    type: 'POST',
					url: '<?php echo base_url();?>transaction/set_transfer_password',
                    data: $('#set_transfer_password_form').serialize(),
                    success: function(data) 
                    {
						$('#set_transfer_password').modal('toggle');
						toastr.success('Successfully set up transfer password');
                    }
                });
            }
        });

        $('body').on('click','#btn_reset_transfer_password', function(){
            $.ajax({
                type: 'POST',
                url: '<?php echo base_url();?>transaction/reset_transfer_password',
                data: {},

                success: function(data) 
                {
                    $('#forgot_transfer_password').modal('toggle');
					toastr.success('Success. Please contact admin for the password.');
                } 
            });
        });
	});

</script>