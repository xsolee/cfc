<table id="encash_history_table" class="table table-striped table-hover nowrap table-bordered" style="width:100%;">
    <thead>
        <tr>
            <th>ID</th>
            <th>Amount in Dollars</th>
            <th>Service Charge</th>
            <th>Maintenance</th>
            <th>Amount in Dollars (Final Amount)</th>
            <th>Currency</th>
            <th>Currency Amount</th>
            <th>Cashback From</th>
            <th>Receiver</th>
            <th>Transfered By</th>
            <th>Status</th>
            <th>Request Type</th>
            <th>Date Recorded</th>

            <th>Account Name</th>
            <th>Account Number</th>
            <th>Account Type</th>
            <th>Phone Number</th>
            <th>Bank Name</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach($result as $row) {

            if($row->currency == 'USD') {
                $currency_service_charge = 5 * 1;
            }

            if($row->currency == 'PHP') {
                $currency_service_charge = 5 * 50;
            }

            if($row->currency == 'Dirham') {
                $currency_service_charge = 5 * 3.60;
            }

            if($row->currency == 'SAR') {
                $currency_service_charge = 5 * 3.70;
            }

            if($row->currency == 'Bangladeshi Taka') {
                $currency_service_charge = 5 * 80;
            }

            if($row->currency == 'Indian Rupee') {
                $currency_service_charge = 5 * 68;
            }

            if($row->encash_from == "Rewards" || $row->encash_from == "Crowd Funding Rewards" || $row->encash_from == "CFC WS Rewards" || $row->encash_from == "CFC Exclusive" || $row->encash_from == "Forex Unilevel" || $row->encash_from == "Forex Trinary" || $row->encash_from == "CFC WS Rewards Received") {
                $service_charge        = 5;
                $maintenance           = $row->amount*0.10;
                $final_amount          = $row->amount-(($row->amount*0.10) + 5);
                $final_amount_currency = $row->currency_amount-(($row->currency_amount*0.10) + $currency_service_charge);
            }
            else if($row->encash_from=="Received Rewards" || $row->encash_from=="Transfer Rewards" || $row->encash_from=="Received CFC Exclusive" || $row->encash_from=="Transfer CFC Exclusive" || $row->encash_from=="Received CFC WS Rewards" || $row->encash_from=="Received CFC WS Rewards [2]" || $row->encash_from=="Transfer CFC WS Rewards" || $row->encash_from=="Transfer CFC WS Rewards [2]" || $row->encash_from=="Received Forex Unilevel" || $row->encash_from=="Transfer Forex Unilevel" ) {
                if($row->maintenance){
                    $maintenance           = $row->maintenance;
                    $final_amount          = $row->amount-( 5+$maintenance );
                } else {
                    $maintenance           = 0;
                    $final_amount          = $row->amount-5;
                }

                $service_charge        = 5;
                $final_amount_currency = 0;
            }


            else {
                $service_charge        = 0;
                $maintenance           = 0;
                $final_amount          = $row->amount;
                $final_amount_currency = 0;
            }

        ?>
            <tr class="tr-hover">
                <td><?php echo $row->id; ?></td>

                <td style="text-align: right;"><?php echo amount_format($row->amount); ?></td>
                <td style="text-align: right;"><?php echo amount_format($service_charge); ?></td>
                <td style="text-align: right;"><?php echo amount_format($maintenance); ?></td>
                <td style="text-align: right;"><?php echo amount_format($final_amount); ?></td>
                <td><?php echo $row->currency; ?></td>
                <td style="text-align: right;"><?php echo amount_format($final_amount_currency); ?></td>

                <td><?php echo $row->encash_from; ?></td>
                <td><?php echo (in_array($row->encash_from, array('Transfer Rewards','Transfer CFC Exclusive','Transfer CFC WS Rewards')))? get_account_details($row->receiver_name)->username : $row->receiver_name; ?></td>
                <td><?php echo (in_array($row->encash_from, array('Received Rewards','Received CFC Exclusive','Received CFC WS Rewards')))? get_account_details($row->transfered_by)->username : $row->transfered_by; ?></td>
                <td><?php echo ucwords($row->status); 
                    if($row->status=='pending' && $this->session->userdata()['user_id'] == "0000002") { ?>
                        <button id="update_status" class="btn btn-sm btn-clean btn-icon btn-icon-lg" data-toggle="tooltip" title="Update Status" data-header_id ="<?php echo $row->id; ?>">
                            <i class="flaticon-edit"></i>
                        </button>
                    <?php } ?>
                </td>
                <td><?php echo $row->request_type; ?></td>
                <td><?php echo $row->date_created; ?></td>
                
                <td><?php echo $row->account_name; ?></td>
                <td><?php echo $row->account_number; ?></td>
                <td><?php echo $row->account_type; ?></td>
                <td><?php echo $row->mobile_number; ?></td>
                <td><?php echo $row->bank_name; ?></td>
            </tr>
        <?php } ?>
    </tbody>
</table>