<div class="kt-container  kt-container--fluid  kt-grid__item kt-grid__item--fluid">
    <div class="row">
		<div class="col-md-6">
    		<div class="kt-portlet kt-portlet--mobile kt-portlet--height-fluid-">
	            <div class="kt-portlet__head kt-portlet__head--lg" >
	                <div class="kt-portlet__head-label">
	                    <h3 class="kt-portlet__head-title">
	                        Cashback
	                    </h3>
	                </div>
	            </div>
				<form class="form-horizontal" id="encash_form" method="post">
	            	<div class="kt-portlet__body">
						<div class="form-group">
							<label for="amount" class="form-control-label">Amount in Rewards</label>
							<input type="number" class="form-control" id="amount" name="amount" min="1000">
						</div>
						<div class="form-group">
							<label for="currency" class="form-control-label">To Currency</label>
							<select class="form-control selectpicker" tabindex="-1" name="currency" id="currency">
								<option value="USD">USD (1)</option>
								<option value="PHP">PHP (50)</option>
								<option value="Dirham">Dirham (3.60)</option>
								<option value="SAR">SAR (3.70)</option>
								<option value="Bangladeshi Taka">Bangladeshi Taka (80)</option>
								<option value="Indian Rupee">Indian Rupee (68)</option>
							</select> 
						</div>
						<div class="form-group">
							<label for="amount" class="form-control-label">Currency Amount</label>
							<input type="number" class="form-control" id="currency_amount" name="currency_amount" readonly>
						</div>
						<div class="form-group">
							<label for="encash_from" class="form-control-label">Cashback From</label>
							<select class="form-control selectpicker" tabindex="-1" name="encash_from" id="encash_from" onchange="minamount(this.value);">
								<option value="Rewards">Rewards</option>
								<option value="CFC WS Rewards">CFC WS Rewards</option>
								<option value="CFC Exclusive">CFC Exclusive</option>
								<option value="CFC WS Rewards Received">CFC WS Rewards Received</option>
								<option value="Forex Unilevel">Forex Unilevel</option>
								<option value="Forex Trinary">Forex Trinary</option>
							</select>
						</div>
						<div class="form-group">
							<label for="request_type" class="form-control-label">Request Type</label>
							<select class="form-control selectpicker" tabindex="-1" name="request_type" id="request_type" onchange="checktype(this.value);">
								<option value="">Nothing Selected</option>
								<option value="BDO">BDO</option>
								<option value="Union Bank">Union Bank</option>
								<option value="Security Bank">Security Bank</option>
								<option value="AUB">AUB</option>
								<option value="BPI">BPI</option>
								<option value="RCBC">RCBC</option>
								<option value="UCPB">UCPB</option>
								<option value="GCash">GCash</option>
							</select>
						</div>
						<div class="form-group" id="banks">
							<label for="bank_id" class="form-control-label">Bank Account</label>
							<select class="form-control selectpicker" tabindex="-1" name="bank_id" id="bank_id">

							</select>
						</div>
						<div class="form-group" id="palawan_name">
							<label for="receiver_name" class="form-control-label">Receiver's Name</label>
							<input type="text" class="form-control" name="receiver_name" id="receiver_name" value="<?php echo ucwords($this->session->userdata()['firstname']).' '.ucwords($this->session->userdata()['lastname']); ?>" readonly>
						</div>
						<div class="form-group" id="palawan_number">
							<label for="receiver_mobile_number" class="form-control-label">Mobile Number</label>
							<input type="text" class="form-control" name="receiver_mobile_number" placeholder="09xxxxxxxxx" maxlength="11">
						</div>
		            	<input type="hidden" name="account_id" value="<?php echo $this->session->userdata()['user_id']; ?>">
					</div>
					<div class="kt-portlet__foot kt-align-right">
						<button type="submit" class="btn btn-brand">Cashback</button>
					</div>
				</form>
	        </div>
	     </div>
    </div>
</div>

<script type="text/javascript">
	$(document).ready(function(){
		$("#palawan_name").hide();
		$("#palawan_number").hide();

        toastr.options = {
          "closeButton": false,
          "debug": false,
          "newestOnTop": false,
          "progressBar": false,
          "positionClass": "toast-top-right",
          "preventDuplicates": false,
          "onclick": null,
          "showDuration": "300",
          "hideDuration": "1000",
          "timeOut": "5000",
          "extendedTimeOut": "1000",
          "showEasing": "swing",
          "hideEasing": "linear",
          "showMethod": "fadeIn",
          "hideMethod": "fadeOut"
        };

        $( "#encash_form" ).validate({
            // define validation rules
            rules: {
                amount : {
                    required: true
                },
                currency : {
                    required: true
                },
                currency_amount : {
                    required: true
                },
                encash_from : {
                    required: true
                },
                request_type : {
                    required: true
                },
                account_id : {
                    required: true
                },
                receiver_mobile_number : {
					maxlength: 11
                }
            },
            
            invalidHandler: function(event, validator) {     
                swal.fire("Error!", "Please fill all required fields and try submitting again.", "warning");
            },

            submitHandler: function (form) {
                $.ajax({
                    type: 'POST',
					url: "<?php echo base_url('transaction/encash'); ?>",
                    data: $('#encash_form').serialize(),
                    success: function(data) 
                    {
                    	if(data.search("Error") != -1){
							toastr.error(data);
						} else {
							window.location.replace("<?php echo base_url('transaction/history'); ?>");
						}
                    }
                });
            }
        });

		$('#amount').on('keyup', function(){
			var value = $(this).val();
            var currency        = $('#currency').val();
			var currency_amount = 0;	 

			if(currency == 'USD') {
				currency_amount = value * 1;
			}

			if(currency == 'PHP') {
				currency_amount = value * 50;
			}

			if(currency == 'Dirham') {
				currency_amount = value * 3.60;
			}

			if(currency == 'SAR') {
				currency_amount = value * 3.70;
			}

			if(currency == 'Bangladeshi Taka') {
				currency_amount = value * 80;
			}

			if(currency == 'Indian Rupee') {
				currency_amount = value * 68;
			}

			$('#currency_amount').val(currency_amount);
        });


        $('#currency').on('change', function(){
		
			var currency = $(this).val();
	        var value = $('#amount').val();
			var currency_amount = 0;	 

			if(currency == 'USD') {
				currency_amount = value * 1;
			}

			if(currency == 'PHP') {
				currency_amount = value * 50;
			}

			if(currency == 'Dirham') {
				currency_amount = value * 3.60;
			}

			if(currency == 'SAR') {
				currency_amount = value * 3.70;
			}

			if(currency == 'Bangladeshi Taka') {
				currency_amount = value * 80;
			}

			if(currency == 'Indian Rupee') {
				currency_amount = value * 68;
			}

			$('#currency_amount').val(currency_amount);
		});
	});

	function checktype(rtype){
		if(rtype!="GCash"){
			$("#palawan_name").hide();
			$("#palawan_number").hide();
			$("#banks").show();


			$.ajax({
				type: 'POST',
				url: "<?php echo base_url('transaction/get_bank_list'); ?>",
				data: {bank_name: $('#request_type').val()},

				success: function(data) {
					$('#bank_id').html('');
					$('#bank_id').html(data);
                    $('#bank_id').selectpicker('refresh');
				}
			});
			
		}else if(rtype=="GCash"){
			$("#palawan_name").show();
			$("#palawan_number").show();
			$("#banks").hide();
		}
	}

	function minamount(encash){
		if(encash=="Rewards"){ $("#amount").attr({"min" : 1000}); }
		else { $("#amount").attr({"min" : 50}); }
	}
</script>