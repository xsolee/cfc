<div class="kt-container  kt-container--fluid  kt-grid__item kt-grid__item--fluid">
    <div class="row">
        <div class="col-md-9">
            <div class="kt-portlet kt-portlet--mobile kt-portlet--height-fluid-">
                <div class="kt-portlet__head kt-portlet__head--lg" >
                    <div class="kt-portlet__head-label">
                        <h3 class="kt-portlet__head-title">
                            Account Pincodes
                        </h3>
                    </div>
                </div>
                <div class="kt-portlet__body buy_account_pincodes_table nowrap">
                <?php if(!$this->session->userdata()['activated']){ ?>
                    <button type="button" class="btn btn-label-danger btn-md btn-upper btn-bold kt-margin-10" data-toggle="modal" data-target="#activate_account_modal">Activate Account</button>
                <?php } ?>

                    <?php echo $this->load->view('transactions/buy_account_pincodes_table', NULL, TRUE); ?>
                </div>
            </div>
            <div class="kt-portlet kt-portlet--mobile kt-portlet--height-fluid-">
                <div class="kt-portlet__head kt-portlet__head--lg" >
                    <div class="kt-portlet__head-label">
                        <h3 class="kt-portlet__head-title">
                            CFC Pincodes
                        </h3>
                    </div>
                </div>
                <div class="kt-portlet__body buy_cfc_pincodes_table nowrap">
                    <?php echo $this->load->view('transactions/buy_cfc_pincodes_table', NULL, TRUE); ?>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="kt-portlet kt-portlet--mobile kt-portlet--height-fluid-">
                <div class="kt-portlet__head kt-portlet__head--lg" >
                    <div class="kt-portlet__head-label">
                        <h3 class="kt-portlet__head-title">
                            Buy Pincodes
                        </h3>
                    </div>
                </div>
                <div class="kt-portlet__body">
                    <?php if( $money->current_bonus >= 50 || $money->total_affiliate_share - $money->withdrawn_affiliate_share > 0 || $money->maintenance - $money->withdrawn_maintenance > 0 ){ ?>
                        <div class="form-group">
                            <?php echo $money->current_bonus>=50? '<button style="margin-bottom: 5px;" class="btn btn-label-success btn-block" id="btn_rewards">Using Rewards</button>': ''; ?>
                            <?php echo $money->total_affiliate_share - $money->withdrawn_affiliate_share>0? '<button style="margin-bottom: 5px;" class="btn btn-label-success btn-block" id="btn_cfc">Using CFC</button>': ''; ?>
                            <?php echo $money->maintenance-$money->withdrawn_maintenance>0? '<button style="margin-bottom: 5px;" class="btn btn-label-success btn-block" id="btn_maintenance">Using Maintenance</button>': ''; ?>
                        </div>
                    <?php } else { ?>
                        <h4 class="kt-portlet__head-title kt-align-center">
                            No available withdrawal
                        </h4>
                    <?php } ?>
                </div>
            </div>
            <div class="kt-portlet kt-portlet--mobile kt-portlet--height-fluid-">
                <div class="kt-portlet__head kt-portlet__head--lg" >
                    <div class="kt-portlet__head-label">
                        <h3 class="kt-portlet__head-title">
                            Transfer Pincodes
                        </h3>
                    </div>
                </div>
                <div class="kt-portlet__body">
                    <div class="form-group">
                        <label>Transfer To (Account ID): </label>
                        <select class="form-control select2" name="transfer_to" id="transfer_to" data-live-search="true" required>
                            <option value="">Nothing Selected</option>
                            <?php foreach($transfer_list as $row) { ?>
                                <option value="<?php echo $row['account_id']; ?>"><?php echo $row['name'] . ' [' . $row['username'] . ']' . ' [' . $row['account_id'] . ']'; ?></option>
                            <?php } ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <button <?php echo ($this->session->userdata('activated') == 0)? 'disabled' : '' ?> class="btn btn-label-success btn-block" id="transfer_pincodes">Transfer Pincodes</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="buy_pincode_modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" >
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <form id="buy_pincodes_form" method="POST" enctype="multipart/form-data">
                <div class="modal-header">
                    <h5 class="modal-title" id="myModalLabel">Buy Pincodes</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"> </button>
                </div>
                <div class="modal-body">
                    <div class="kt-widget kt-widget--user-profile-2">
                        <div class="kt-widget__body">
                            <div class="kt-widget__content">
                                <div class="kt-widget__stats kt-margin-r-20">
                                    <div class="kt-widget__icon">
                                        <i class="flaticon-piggy-bank"></i>
                                    </div>
                                    <div class="kt-widget__details">
                                        <span class="kt-widget__title">Available to withdraw</span>
                                        <span class="kt-widget__value" id="p_withdrawal_amount"><?php echo amount_format( $money->current_bonus ,2); ?> Dollars</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <select class="selectpicker form-control" id="pincode_type" name="pincode_type">
                            <option value="Account">Account Pincodes</option>
                            <option value="CFC" selected>CFC Pincodes</option>
                        </select>
                    </div>
                    <input type="hidden" class="form-control" id="withdraw_from" name="withdraw_from">
                    <div class="form-group">
                        <label for="no_of_pin" class="form-control-label">No of Pins</label>
                        <input type="number" class="form-control" id="no_of_pin" name="no_of_pin" placeholder="No of Pins" value = "1" min="1">
                    </div>
                    <div class="form-group" id="no_of_accounts_div">
                        <label for="no_of_accounts" class="form-control-label">No of Accounts</label>
                        <input type="number" class="form-control" id="no_of_accounts" name="no_of_accounts" placeholder="No of Accounts" value="1" min="0">
                    </div>
                    <div class="form-group">
                        <label for="total_amount" class="form-control-label">Total Amount</label>
                        <input type="text" class="form-control" id="total_amount" name="total_amount" placeholder="Total Amount" value="100" readonly>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Buy Pincodes</button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="activate_account_modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-modal="true">
    <div class="modal-dialog modal-sm modal-dialog-centered" role="document">
        <div class="modal-content">
            <form id="activate_account_form" method="POST">
                <div class="modal-header">
                    <h5 class="modal-title" id="myModalLabel">Activate Account</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    </button>
                </div>
                <div class="modal-body">
                        <div class="form-group">
                            <label for="pin1" class="form-control-label">Pincode 1</label>
                            <input type="text" class="form-control" id="pin1" name="pin1" placeholder="Enter Pincode 1">
                        </div>
                        <div class="form-group">
                            <label for="pin2" class="form-control-label">Pincode 2</label>
                            <input type="text" class="form-control" id="pin2" name="pin2" placeholder="Enter Pincode 2">
                        </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Activate</button>
                </div>
            </form>
        </div>
    </div>
</div>
<script type="text/javascript">
    $(document).ready(function() {
        $('.select2').select2({
            //minimumInputLength: 3
        });
        var available_rewards     = "<?php echo $money->current_bonus; ?>";
        var available_cfc         = "<?php echo $money->total_affiliate_share - $money->withdrawn_affiliate_share; ?>";
        var available_maintenance = "<?php echo $money->maintenance - $money->withdrawn_maintenance; ?>";
        var buy_pincodes_table = $('#buy_account_pincodes_table').DataTable({
            "order": [1, 'desc'],
            "iDisplayLength": 25,
            responsive: true
        });
        var buy_cfc_pincodes_table = $('#buy_cfc_pincodes_table').DataTable({
            "order": [1, 'desc'],
            "iDisplayLength": 25,
            responsive: true
        });
        $('.selectpicker').selectpicker('refresh');
        $('#pincode_type').on('change', function(){
            $('#no_of_accounts_div').toggle();
            compute_total();
        });
        $('#no_of_pin, #no_of_accounts').on('keyup', function(){
            compute_total();
        });
        $('#btn_rewards').on('click', function(){
            $('#withdraw_from').val("from rewards");
            get_money();
        });
        $('#btn_cfc').on('click', function(){
            $('#withdraw_from').val("from cfc");
            get_money();
        });
        $('#btn_maintenance').on('click', function(){
            $('#withdraw_from').val("from maintenance");
            get_money();
        });

        $( "#buy_pincodes_form" ).validate({
            // define validation rules
            rules: { 
                no_of_pin : {
                    required: true,
                    min: 1
                },
                total_amount : {
                    required: true,
                },
                withdraw_from : {
                    required: true
                },
                no_of_accounts : {
                    min: 0
                },
                pincode_type : {
                    required: true
                }
            },
            
            invalidHandler: function(event, validator) {     
                swal.fire("Error!", "Please fill all required fields and try submitting again.", "warning");
            },

            submitHandler: function (form) {
                compute_total();
                $.ajax({
                    type: 'POST',
                    url: "<?php echo base_url('transaction/bought_pincodes'); ?>",
                    data: {no_of_pin : $('#no_of_pin').val(),no_of_accounts : $('#no_of_accounts').val(), total_amount: $('#total_amount').val(), withdraw_from: $('#withdraw_from').val(), pincode_type: $('#pincode_type').val()},
                    success: function(data) 
                    {
                        var data = JSON.parse(data);
                        if(data.message == "Success"){
                            if($('#pincode_type').find(":selected").val() == "Account"){
                                $('.buy_account_pincodes_table').html(data.table);
                                buy_pincodes_table = $('#buy_account_pincodes_table').DataTable({
                                    "order": [1, 'desc'],
                                    "iDisplayLength": 25,
                                    responsive: true
                                });
                            } if($('#pincode_type').find(":selected").val() == "CFC"){
                                $('.buy_cfc_pincodes_table').html(data.table);
                                buy_cfc_pincodes_table = $('#buy_cfc_pincodes_table').DataTable({
                                    "order": [1, 'desc'],
                                    "iDisplayLength": 25,
                                    responsive: true
                                });
                            }
                            $('.selectpicker').selectpicker('refresh');
                            $('.modal-body #p_withdrawal_amount').text("Available to withdraw: "+data.available_withdrawal+" Dollars");
                            toastr.success('Success');
                        }else{
                            toastr.error(data.message);
                        }
                    }
                });
            }
        });

        $( "#activate_account_form" ).validate({
            // define validation rules
            rules: {
                pin1 : {
                    required: true
                },
                pin2 : {
                    required: true
                }
            },
            
            invalidHandler: function(event, validator) {     
                swal.fire("Error!", "Please fill all required fields and try submitting again.", "warning");
            },

            submitHandler: function (form) {
                $.ajax({
                    type: 'POST',
                    url: '<?php echo base_url();?>account/activate_account',
                    data: $('#activate_account_form').serialize(),
                    success: function(data) 
                    {
                        if(data.search('Success') != -1) {
                            $('#activate_account_modal').modal('toggle');
                            swal.fire({
                                title: 'Successful activation!',
                                text: 'To fully activate this account, you will be logged out in 3 seconds.',
                                timer: 3000,
                                onOpen: function() {
                                    swal.showLoading();
                                }
                            }).then(function(result) {
                                if (result.dismiss === 'timer') {
                                    window.location = "<?php echo base_url('account/logout'); ?>";
                                }
                            });
                        } else {
                            swal.fire("Error!", data, "error");
                        }
                    }
                });
            }
        });

        $('#transfer_pincodes').click(function(){

            loader();

            var account_id = '';
            buy_pincodes_table.rows().nodes().to$().find(':checkbox:checked').each(function(i){
                account_id += $(this).val() + '-';
            });

            var cfc_id = '';
            buy_cfc_pincodes_table.rows().nodes().to$().find(':checkbox:checked').each(function(i){
                cfc_id += $(this).val() + '-';
            });

            var transfer_to = $('#transfer_to').val();

            $.ajax({
                type: 'POST',
                url: '<?php echo base_url();?>transaction/transfer_pincodes',
                data: {transfer_to: transfer_to, account_id: account_id, cfc_id: cfc_id},

                success: function(data) 
                {
                    var data = JSON.parse(data);
                    
                    $('.buy_account_pincodes_table').html(data.account_table);
                    $('.buy_cfc_pincodes_table').html(data.cfc_table);

                    buy_pincodes_table = $('#buy_account_pincodes_table').DataTable({
                        "order": [1, 'desc'],
                        "iDisplayLength": 25,
                        responsive: true
                    });
                    buy_cfc_pincodes_table = $('#buy_cfc_pincodes_table').DataTable({
                        "order": [1, 'desc'],
                        "iDisplayLength": 25,
                        responsive: true
                    });

                    if(data.message_type == "success") toastr.success(data.message);
                    else toastr.error(data.message);
                }
            });
        });

        function compute_total()
        {
            if($('#pincode_type').find(":selected").val() == "Account"){
                $('#total_amount').val($('#no_of_pin').val() * 100);
            } if($('#pincode_type').find(":selected").val() == "CFC"){
                var no_of_accounts = $('#no_of_accounts').val();
                if($('#no_of_accounts').val() == 0) {
                    no_of_accounts = 0.5;
                }
                $('#total_amount').val($('#no_of_pin').val() * no_of_accounts * 100);
            }
        }
        function get_money()
        {
            $.ajax({
                type: 'POST',
                url: '<?php echo base_url();?>transaction/get_money',
                data: {withdraw_from : $('#withdraw_from').val()},
                success: function(data) 
                {
                    var data = JSON.parse(data);
                    $('.modal-body #p_withdrawal_amount').text(data.available_withdrawal+" Dollars");
                    $('#buy_pincode_modal').modal('show');
                } 
            });
        }
        function loader()
        {
            $(document).ajaxStart(
                $.blockUI({ 
                    message: '<img src="<?php echo base_url('resources/images/ajax-loader.gif');?>"/>Please wait..',
                    css: {
                        border:          'none',
                        backgroundColor: 'transparent'
                    }
                })
            ).ajaxStop($.unblockUI);
        }
    });
</script>