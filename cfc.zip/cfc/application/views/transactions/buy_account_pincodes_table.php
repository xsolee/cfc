<table id="buy_account_pincodes_table" class="table table-striped table-hover nowrap table-bordered" style="width:100%;">
    <thead>
        <tr>
            <!-- <th></th> -->
            <th>For Transfer</th>
            <!-- <th>ID</th> -->
            <th>Pin 1</th>
            <th>Pin 2</th>
            <!-- <th>Account ID</th>
            <th>Account Username</th>
            <th>Account Name</th>
            <th>Transfer To</th>
            <th>Date Used</th> -->
            <th>Date</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach($bought_account_pincodes as $row) { ?>
            <tr class="tr-hover">
                <!-- <td></td> -->
                <td style="text-align: center; width: 10px;"><input <?php echo ((($row->transfer_to == $this->session->userdata('user_id')) || $row->transfer_to == null) && $row->account_id == null)? '' : 'disabled'; ?> type="checkbox" name="check[]" id="check" value="<?php echo $row->PIN_id; ?>"></td>
                <!-- <td><?php echo $row->PIN_id; ?></td> -->
                <td><?php echo $row->PIN1; ?></td>
                <td><?php echo $row->PIN2; ?></td>
                <!-- <td><?php echo $row->account_id; ?></td>
                <td><?php echo $row->username; ?></td>
                <td><?php echo ucwords($row->first_name . " " . $row->last_name); ?></td>
                <td><?php echo $row->transfer_to; ?></td>
                <td><?php echo $row->date_used!=null?(new DateTime($row->date_used))->format('Y-m-d'):""; ?></td> -->
                <td><?php echo (new DateTime($row->date_created))->format('Y-m-d'); ?></td>
            </tr>
        <?php } ?>
    </tbody>
</table>