<div class="kt-container kt-container--fluid kt-grid__item kt-grid__item--fluid">
	<div class="kt-portlet kt-portlet--mobile kt-portlet--height-fluid-">
        <div class="kt-portlet__head kt-portlet__head--lg" >
            <div class="kt-portlet__head-label">
                <h3 class="kt-portlet__head-title">
                    Requests History
                </h3>
            </div>
        </div>
        <div class="kt-portlet__body">
        	<div class="row">
	        	<div class="col-md-3">
	                <div class="form-group">
	                    <label for="ttype">Filter by transaction type</label>
	                    <select class="selectpicker form-control filter_transactions" id="ttype" name="ttype" data-live-search="true">
                            <option value="None">Nothing Selected</option>
                            <option value="All Cashbacks">All Cashbacks</option>
	                        <option value="All Transfers">All Transfers Received</option>
	                        <?php foreach($ttype as $row) { ?>
	                            <option value="<?php echo $row->encash_from; ?>"><?php echo $row->encash_from; ?></option>
	                        <?php } ?>
	                    </select>
	                </div>
	            </div>
	            <div class="col-md-3">
	                <div class="form-group">
	                    <label for="status">Filter by status</label>
	                    <select class="selectpicker form-control filter_transactions" id="status" name="status" data-live-search="true">
	                        <option value="None">Nothing Selected</option>
	                        <option value="paid">Paid</option>
	                        <option value="pending">Pending</option>
	                        <option value="success">Success</option>
	                    </select>
	                </div>
	            </div>
            </div>
        	<div class="encash_history_table">
            	<?php echo $this->load->view('transactions/all_requests_table', NULL, TRUE); ?>
			</div>
		</div>
	</div>
</div>

<div class="modal fade" id="update_status_modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" >
    <div class="modal-dialog modal-sm modal-dialog-centered">
        <div class="modal-content">
            <form id="update_status_form" method="POST">
                <input type="hidden" class="form-control" id="header_id" name="header_id">
                <div class="modal-header">
                    <h5 class="modal-title" id="myModalLabel">Are you sure you want to change the status to paid?</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    </button>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">No</button>
                    <button type="submit" class="btn btn-primary" id="btn_end_game">Yes</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script type="text/javascript">
	$(document).ready(function(){
		$('#encash_history_table').DataTable({
			"order": [0, 'desc'],
			responsive: true
		});

        toastr.options = {
          "closeButton": false,
          "debug": false,
          "newestOnTop": false,
          "progressBar": false,
          "positionClass": "toast-top-right",
          "preventDuplicates": true,
          "onclick": null,
          "showDuration": "300",
          "hideDuration": "300",
          "timeOut": "3000",
          "extendedTimeOut": "1000",
          "showEasing": "swing",
          "hideEasing": "linear",
          "showMethod": "fadeIn",
          "hideMethod": "fadeOut"
        };

        $('.filter_transactions').on('change', function(){
            $.ajax({
                type: 'POST',
                url: '<?php echo base_url();?>transaction/get_filtered_transactions',
                data: {ttype : $('#ttype').val(), status: $('#status').val()},

                success: function(data) 
                {
                    $('.encash_history_table').html(data);
                    $('#encash_history_table').DataTable({
                        "order": [0, 'desc'],
                        responsive: true
                    });
					toastr.success("Success!");
                }
            });
        });

        $('body').on('click','#update_status', function(){
            $('#update_status_modal #header_id').val($(this).attr('data-header_id'));
            $('#update_status_modal').modal('show'); 
        });

        $( "#update_status_form" ).validate({
            // define validation rules
            rules: {
                header_id : {
                    required: true
                }
            },
            
            invalidHandler: function(event, validator) {     
                swal.fire("Error!", "Please fill all required fields and try submitting again.", "warning");
            },

            submitHandler: function (form) {
                $.ajax({
                    type: 'POST',
                    url: '<?php echo base_url();?>transaction/update_status',
                    data: $('#update_status_form').serialize(),
                    success: function(data) 
                    {
                        $('.encash_history_table').html(data);
						$('#encash_history_table').DataTable({
							"order": [0, 'desc'],
							responsive: true
						});
						$(".filter_transactions").val("None").change();
                        $('#update_status_modal').modal('toggle');
                        // toastr.success("Successfully updated!");
                    }
                });
            }
        });
	});
</script>