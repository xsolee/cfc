<div class="kt-container kt-container--fluid kt-grid__item kt-grid__item--fluid">
	<div class="kt-portlet kt-portlet--mobile kt-portlet--height-fluid-">
        <div class="kt-portlet__head kt-portlet__head--lg" >
            <div class="kt-portlet__head-label">
                <h3 class="kt-portlet__head-title">
                    Money Logs
                </h3>
            </div>
        </div>
        <div class="kt-portlet__body money_logs_table">
            <table id="money_logs_table" class="table table-striped table-hover nowrap table-bordered" style="width:100%;">
                <thead>
                    <tr>
                        <th>Date Recorded</th>
                        <th>Description</th>
                        <th>Credit</th>
                        <th>Debit</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($result as $row) { ?>
                        <tr class="tr-hover">
                            <td><?php echo $row->date; ?></td>
                            <td><?php echo $row->description; ?></td>
                            <td><?php echo $row->amount; ?></td>
                            <td><?php echo $row->debit; ?></td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
		</div>
	</div>
</div>

<script type="text/javascript">
	$(document).ready(function(){
		$('#money_logs_table').DataTable({
			"order": [0, 'desc'],
			responsive: true
		});
	});
</script>