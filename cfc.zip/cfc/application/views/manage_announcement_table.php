<table id="manage_announcement_table" class="table table-bordered table-striped table-hover">
    <thead>
        <tr>
            <th>Action</th>
            <th>ID</th>
            <th>Title</th>
            <th>Subtitle</th>
            <!-- <th>Background Image</th> -->
            <th>Date Created</th>
            <th>Visible</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach($result as $row) { ?>
            <tr>
                <td>
                    <button id="btn_update" class="btn btn-sm btn-label-danger" data-toggle="tooltip" title="Update Announcement" data-announcement_id ="<?php echo $row->id; ?>">
                        <i class="fa fa-pencil-alt"></i>
                    </button>
                </td>
                <td><?php echo $row->id; ?></td>
                <td><?php echo $row->title; ?></td>
                <td><?php echo $row->subtitle; ?></td>
                <!-- <td><?php echo $row->bg_img; ?></td> -->
                <td><?php echo $row->date_created; ?></td>
                <td><?php echo $row->visible?"Yes":"No"; ?></td>
                
            </tr>
        <?php } ?>
    </tbody>
</table>