<div class="kt-container kt-container--fluid kt-grid__item kt-grid__item--fluid">
    <div class="kt-portlet kt-portlet--mobile kt-portlet--height-fluid-">
        <div class="kt-portlet__head kt-portlet__head--lg">
            <div class="kt-portlet__head-label">
                <span class="kt-portlet__head-icon">
                    <i class="kt-font-brand flaticon2-line-chart"></i>
                </span>
                <h3 class="kt-portlet__head-title">
                    Manage Announcement
                </h3>
            </div>
            <div class="kt-portlet__head-toolbar">
                <button type="button" class="btn btn-sm btn-label-success btn-bold btn-upper" id="btn_new" data-toggle="modal" data-target="#update_announcement">New Announcement</button>
            </div>
        </div>
        <div class="kt-portlet__body manage_announcement_table">
            <?php echo $this->load->view('manage_announcement_table', NULL, TRUE); ?>
        </div>
    </div>
</div>

<div class="modal fade" id="update_announcement" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" >
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <form id="update_announcement_form" method="POST" enctype="multipart/form-data">
                <div class="modal-header">
                    <h5 class="modal-title" id="myModalLabel">New Announcement</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" class="form-control" id="id" name="id">
                    <div class="form-group">
                        <label>Title</label>
                        <input type="text" class="form-control" id="title" name="title" placeholder="Title">
                    </div>
                    <div class="form-group">
                        <label>Subtitle</label>
                        <input type="text" class="form-control" id="subtitle" name="subtitle" placeholder="Subtitle">
                    </div>
                    <!-- <div class="form-group hidden">
                        <label>Attachment</label>
                        <label class="customUpload btnUpload btnM"> <span id="span">Browse</span>
                            <input type="file" class="upload" id="uploaded_file" name="uploaded_file"/>
                        </label>
                    </div> -->
                    <div class="form-group">
                        <label>Visible</label>
                        <select class="selectpicker form-control" id="visible" name="visible">
                            <option value="1">Yes</option>
                            <option value="0">No</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Announce</button>
                </div>
            </form>
        </div>
    </div>
</div>


<script type="text/javascript">

    $(document).ready(function() {

        $('#manage_announcement_table').DataTable({
            "order": [0, 'desc'],
            "iDisplayLength": 25,
            responsive: true
        });

        $( "#update_announcement_form" ).validate({
            // define validation rules
            rules: {
                title : {
                    required: true
                },
                subtitle : {
                    required: true
                },
                visible : {
                    required: true
                }
            },
            
            invalidHandler: function(event, validator) {     
                swal.fire("Error!", "Please fill all required fields and try submitting again.", "warning");
            },

            submitHandler: function (form) {

                var form = $('#update_announcement_form')[0];
                var formData = new FormData(form);

                $.ajax({
                    type: 'POST',
                    url: '<?php echo base_url();?>dashboard/update_announcement',
                    data: formData,
                    contentType: false,       
                    cache: false,             
                    processData:false,

                    success: function(data) 
                    {
                        $('#update_announcement').modal('toggle');
                        $('.manage_announcement_table').html(data);
                        manage_announcement_table = $('#manage_announcement_table').DataTable({
                            "order": [0, 'desc'],
                            "iDisplayLength": 25,
                            responsive: true
                        });

                        toastr.success("Success in saving new announcement!");
                    }
                });
            }
        });

        // $('body').on('click','#btn_save_new_announcement', function(){

        //     loader();
        //     var form = $('#update_announcement_form')[0];
        //     var formData = new FormData(form);
        //     $.ajax({
        //         type: 'POST',
        //         url: '<?php echo base_url();?>dashboard/update_announcement',
        //         data: formData,
        //         contentType: false,       
        //         cache: false,             
        //         processData:false,

        //         success: function(data) 
        //         {
        //             $('#update_announcement').modal('toggle');
        //             $('.manage_announcement_table').html(data);
        //             manage_announcement_table = $('#manage_announcement_table').DataTable({
        //                 "order": [0, 'desc'],
        //                 "iDisplayLength": 25,
        //                 responsive: true
        //             });

        //             notifyme('glyphicon glyphicon-exclamation-sign',' Success in saving new announcement','success');
        //         } 
        //     });
        // });

        $('body').on('click','#btn_update', function(){

            var announcement_id = $(this).attr('data-announcement_id');

            $.ajax({
                type: 'POST',
                url: '<?php echo base_url();?>dashboard/update_announcement_modal',
                data: {announcement_id:announcement_id},

                success: function(data) 
                {
                    var data = JSON.parse(data);
                    $('#update_announcement').modal('show');
                    $('#title').val(data.title);
                    $('#subtitle').val(data.subtitle);
                    $('#visible').val(data.visible);
                    $('#span').text(data.bg_img);
                    $('#id').val(data.id);

                    $(".selectpicker").selectpicker("refresh");
                } 
            });
        });

        $('body').on('click','#btn_new', function(){

            $('#title').val("");

            $('#subtitle').val("");

            $('#visible').val("");

            $('#span').text("Browse");

            $('#id').removeAttr("value");

            $(".selectpicker").selectpicker("refresh");

        });

        $('#uploaded_file').on("change", function(){
            var input = $('#uploaded_file'),
            numFiles = input.get(0).files ? input.get(0).files.length : 1,
            label = input.val().replace(/\\/g, '/').replace(/.*\//, ''); 
            $('#span').text(label);
        });

        function loader()
        {
            $(document).ajaxStart(
                $.blockUI({ 
                    message: '<img src="<?php echo base_url('resources/images/ajax-loader.gif');?>"/>Please wait..',
                    css: {
                        border:          'none',
                        backgroundColor: 'transparent'
                    }
                })
            ).ajaxStop($.unblockUI);
        }

        function notifyme(icon,message,type)
        {
            $.notify({
                icon: icon,
                message: message 
            },{
                type: type,
                animate: {
                    enter: 'animated bounceInDown',
                    exit: 'animated bounceOutUp'
                },
                z_index: 2000,
                delay: 2000,
                timer: 1000,
                allow_dismiss: false
            });
        }

    });

</script>