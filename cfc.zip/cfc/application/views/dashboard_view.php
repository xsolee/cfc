<div class="kt-container kt-container--fluid kt-grid__item kt-grid__item--fluid">
	<div class="row">
		<div class="col-md-8">
			<?php if($this->session->userdata()['activated']){ ?>
			<div class="row">
				<div class="col-md-4">
					<div class="kt-portlet kt-iconbox kt-iconbox--success kt-iconbox--animate-fast" style="padding: 0px !important;">
						<div class="kt-portlet__body">
							<div class="kt-iconbox__body">
								<div class="kt-iconbox__icon">
									<i class="fas fa-money-bill-alt fa-3x"></i>
								</div>
								<div class="kt-iconbox__desc">
									<h3 class="kt-iconbox__title">
										<a class="kt-link"><?php echo amount_format($money->signup_bonus); ?></a>
									</h3>
									<div class="kt-iconbox__content">
										Sign-up Rewards
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-4">
					<div class="kt-portlet kt-iconbox kt-iconbox--danger kt-iconbox--animate-fast" style="padding: 0px !important;">
						<div class="kt-portlet__body">
							<div class="kt-iconbox__body">
								<div class="kt-iconbox__icon">
									<i class="fas fa-money-bill-alt fa-3x"></i>
								</div>
								<div class="kt-iconbox__desc">
									<h3 class="kt-iconbox__title">
										<a class="kt-link"><?php echo amount_format($money->pairing_bonus); ?></a>
									</h3>
									<div class="kt-iconbox__content">
										Matching Rewards
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-4">
					<div class="kt-portlet kt-iconbox kt-iconbox--warning kt-iconbox--animate-fast" style="padding: 0px !important;">
						<div class="kt-portlet__body">
							<div class="kt-iconbox__body">
								<div class="kt-iconbox__icon">
									<i class="fas fa-money-bill-alt fa-3x"></i>
								</div>
								<div class="kt-iconbox__desc">
									<h3 class="kt-iconbox__title">
										<a class="kt-link"><?php echo amount_format($money->direct_referral); ?></a>
									</h3>
									<div class="kt-iconbox__content">
										Direct Referral
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-md-4">
					<div class="kt-portlet kt-iconbox kt-iconbox--primary kt-iconbox--animate-fast" style="padding: 0px !important;">
						<div class="kt-portlet__body">
							<div class="kt-iconbox__body">
								<div class="kt-iconbox__icon">
									<i class="fas fa-money-bill-alt fa-3x"></i>
								</div>
								<div class="kt-iconbox__desc">
									<h3 class="kt-iconbox__title">
										<a class="kt-link"><?php echo amount_format($money->total_affiliate_share_unilevel); ?></a>
									</h3>
									<div class="kt-iconbox__content">
										CFC WS Unilevel
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-4">
					<div class="kt-portlet kt-iconbox kt-iconbox--success kt-iconbox--animate-fast" style="padding: 0px !important;">
						<div class="kt-portlet__body">
							<div class="kt-iconbox__body">
								<div class="kt-iconbox__icon">
									<i class="fas fa-money-bill-alt fa-3x"></i>
								</div>
								<div class="kt-iconbox__desc">
									<h3 class="kt-iconbox__title">
										<a class="kt-link"><?php echo amount_format($money->leadership_rewards); ?></a>
									</h3>
									<div class="kt-iconbox__content">
										Leadership Rewards
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-4">
					<div class="kt-portlet kt-iconbox kt-iconbox--warning kt-iconbox--animate-fast" style="padding: 0px !important;">
						<div class="kt-portlet__body">
							<div class="kt-iconbox__body">
								<div class="kt-iconbox__icon">
									<i class="fas fa-money-bill-alt fa-3x"></i>
								</div>
								<div class="kt-iconbox__desc">
									<h3 class="kt-iconbox__title">
										<a class="kt-link"><?php echo amount_format($money->maintenance - $money->withdrawn_maintenance); ?></a>
									</h3>
									<div class="kt-iconbox__content">
										Maintenance
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-md-4">
					<div class="kt-portlet kt-iconbox kt-iconbox--primary kt-iconbox--animate-fast" style="padding: 0px !important;">
						<div class="kt-portlet__body">
							<div class="kt-iconbox__body">
								<div class="kt-iconbox__icon">
									<i class="fas fa-money-bill-alt fa-3x"></i>
								</div>
								<div class="kt-iconbox__desc">
									<h3 class="kt-iconbox__title">
										<a class="kt-link"><?php echo amount_format($money->total_bonus); ?></a>
									</h3>
									<div class="kt-iconbox__content">
										Total Rewards
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-4">
					<div class="kt-portlet kt-iconbox kt-iconbox--success kt-iconbox--animate-fast" style="padding: 0px !important;">
						<div class="kt-portlet__body">
							<div class="kt-iconbox__body">
								<div class="kt-iconbox__icon">
									<i class="fas fa-money-bill-alt fa-3x"></i>
								</div>
								<div class="kt-iconbox__desc">
									<h3 class="kt-iconbox__title">
										<a class="kt-link"><?php echo amount_format($money->current_bonus); ?></a>
									</h3>
									<div class="kt-iconbox__content">
										Available Rewards
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<?php } else { ?>
				<div class="alert alert-warning" role="alert">
					<strong class="kt-margin-r-5">Note!</strong> Activate your account for more exciting rewards!
				</div>
			<?php } ?>
			<div class="row">
				<div class="col-md-4">
					<div class="kt-portlet kt-iconbox kt-iconbox--warning kt-iconbox--animate-fast" style="padding: 0px !important;">
						<div class="kt-portlet__body">
							<div class="kt-iconbox__body">
								<div class="kt-iconbox__icon">
									<i class="fas fa-money-bill-alt fa-3x"></i>
								</div>
								<div class="kt-iconbox__desc">
									<h3 class="kt-iconbox__title">
										<a class="kt-link"><?php echo amount_format(($money->total_affiliate_share-$money->reinvest_affiliate_shares) + $money->received_affiliate_shares); ?></a>
									</h3>
									<div class="kt-iconbox__content">
										Total CFC WS
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-4">
					<div class="kt-portlet kt-iconbox kt-iconbox--primary kt-iconbox--animate-fast" style="padding: 0px !important;">
						<div class="kt-portlet__body">
							<div class="kt-iconbox__body">
								<div class="kt-iconbox__icon">
									<i class="fas fa-money-bill-alt fa-3x"></i>
								</div>
								<div class="kt-iconbox__desc">
									<h3 class="kt-iconbox__title">
										<a class="kt-link"><?php echo amount_format(($money->total_affiliate_share + $money->received_affiliate_shares) - ($money->reinvest_affiliate_shares + $money->withdrawn_affiliate_share + $money->withdrawn_affiliate_share_2 + $money->transfered_affiliate_shares + $money->transfered_affiliate_shares_2)); ?></a>
									</h3>
									<div class="kt-iconbox__content">
										Available CFC WS
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-md-4">
					<div class="kt-portlet kt-iconbox kt-iconbox--success kt-iconbox--animate-fast" style="padding: 0px !important;">
						<div class="kt-portlet__body">
							<div class="kt-iconbox__body">
								<div class="kt-iconbox__icon">
									<i class="fas fa-money-bill-alt fa-3x"></i>
								</div>
								<div class="kt-iconbox__desc">
									<h3 class="kt-iconbox__title">
										<a class="kt-link"><?php $total_cfc_exclusive = $money->cfc_exclusive + $money->cfc_exclusive_referral + $money->received_cfc_exclusive; echo amount_format($total_cfc_exclusive); ?></a>
									</h3>
									<div class="kt-iconbox__content">
										Total CFC Exclusive
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-4">
					<div class="kt-portlet kt-iconbox kt-iconbox--danger kt-iconbox--animate-fast" style="padding: 0px !important;">
						<div class="kt-portlet__body">
							<div class="kt-iconbox__body">
								<div class="kt-iconbox__icon">
									<i class="fas fa-money-bill-alt fa-3x"></i>
								</div>
								<div class="kt-iconbox__desc">
									<h3 class="kt-iconbox__title">
										<a class="kt-link"><?php $available_cfc_exclusive = ($money->cfc_exclusive + $money->cfc_exclusive_referral + $money->received_cfc_exclusive) - ($money->withdrawn_cfc_exclusive + $money->transfered_cfc_exclusive); echo amount_format($available_cfc_exclusive); ?></a>
									</h3>
									<div class="kt-iconbox__content">
										Available CFC Exclusive
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-md-4">
					<div class="kt-portlet kt-iconbox kt-iconbox--success kt-iconbox--animate-fast" style="padding: 0px !important;">
						<div class="kt-portlet__body">
							<div class="kt-iconbox__body">
								<div class="kt-iconbox__icon">
									<i class="fas fa-money-bill-alt fa-3x"></i>
								</div>
								<div class="kt-iconbox__desc">
									<h3 class="kt-iconbox__title">
										<a class="kt-link"><?php $total_forex_referral = $money->forex_referral + $money->received_forex_referral; echo amount_format($total_forex_referral); ?></a>
									</h3>
									<div class="kt-iconbox__content">
										Total Forex Unilevel
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-4">
					<div class="kt-portlet kt-iconbox kt-iconbox--danger kt-iconbox--animate-fast" style="padding: 0px !important;">
						<div class="kt-portlet__body">
							<div class="kt-iconbox__body">
								<div class="kt-iconbox__icon">
									<i class="fas fa-money-bill-alt fa-3x"></i>
								</div>
								<div class="kt-iconbox__desc">
									<h3 class="kt-iconbox__title">
										<a class="kt-link"><?php $available_forex_referral = $total_forex_referral-$money->transferred_forex_referral-$money->withdrawn_forex_referral; echo amount_format( $total_forex_referral ); ?></a>
									</h3>
									<div class="kt-iconbox__content">
										Available Forex Unilevel
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-md-4">
					<div class="kt-portlet kt-iconbox kt-iconbox--success kt-iconbox--animate-fast" style="padding: 0px !important;">
						<div class="kt-portlet__body">
							<div class="kt-iconbox__body">
								<div class="kt-iconbox__icon">
									<i class="fas fa-money-bill-alt fa-3x"></i>
								</div>
								<div class="kt-iconbox__desc">
									<h3 class="kt-iconbox__title">
										<a class="kt-link"><?php $total_cfc_coins = $money->purchased_cfc_coins + $money->received_cfc_coins; echo amount_format($total_cfc_coins); ?></a>
									</h3>
									<div class="kt-iconbox__content">
										Total CFC Coins
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-4">
					<div class="kt-portlet kt-iconbox kt-iconbox--danger kt-iconbox--animate-fast" style="padding: 0px !important;">
						<div class="kt-portlet__body">
							<div class="kt-iconbox__body">
								<div class="kt-iconbox__icon">
									<i class="fas fa-money-bill-alt fa-3x"></i>
								</div>
								<div class="kt-iconbox__desc">
									<h3 class="kt-iconbox__title">
										<a class="kt-link"><?php echo amount_format( $total_cfc_coins-$money->transferred_cfc_coins-$money->withdrawn_cfc_coins ); ?></a>
									</h3>
									<div class="kt-iconbox__content">
										Available CFC Coins
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="col-md-4">
			<div class="kt-portlet kt-portlet--height-fluid-">
				<div class="kt-portlet__head kt-portlet__head--noborder">
					<div class="kt-portlet__head-label">
						<h3 class="kt-portlet__head-title">
						</h3>
					</div>
				</div>
				<div class="kt-portlet__body">
					<div class="kt-widget kt-widget--user-profile-2">
						<div class="kt-widget__head">
							<div class="kt-widget__media">
								<img class="kt-widget__img kt-hidden-" src="<?php echo base_url('resources/metronic/media/users/default.jpg'); ?>" alt="image">
								<div class="kt-widget__pic kt-widget__pic--danger kt-font-danger kt-font-boldest kt-font-light kt-hidden">
									
								</div>
							</div>
							<div class="kt-widget__info">
								<a class="kt-widget__username">
									<?php echo $this->session->userdata()['firstname']." ".$this->session->userdata()['lastname']; ?>
								</a>
								<span class="kt-widget__desc">
									<?php echo $this->session->userdata()['username']; ?>
								</span>
							</div>
						</div>
						<div class="kt-widget__body">
							<div class="kt-widget__section">
								
							</div>
							<div class="kt-widget__item">
								<div class="kt-widget__contact">
									<span class="kt-widget__label">User ID:</span>
									<a class="kt-widget__data"><?php echo $this->session->userdata()['user_id']; ?></a>
								</div>
								<div class="kt-widget__contact">
									<span class="kt-widget__label">Email Address:</span>
									<a class="kt-widget__data"><?php echo $email_address; ?></a>
								</div>
								<div class="kt-widget__contact">
									<span class="kt-widget__label">Mobile Number:</span>
									<a class="kt-widget__data"><?php echo $mobile_number; ?></a>
								</div>
							</div>
							<?php if($this->session->userdata()['activated']){ ?>
								<div class="kt-widget__content">
									<div class="row">
										<div class="col-md-12">
											<div class="row">
												<div class="col-md-6">
													<div class="kt-widget__stats kt-margin-r-20">
														<div class="kt-widget__icon">
															<i class="flaticon-pie-chart"></i>
														</div>
														<div class="kt-widget__details">
															<span class="kt-widget__title">Points in Left</span>
															<span class="kt-widget__value"><?php echo number_format($points_left); ?></span>
														</div>
													</div>
												</div>
												<div class="col-md-6">
													<div class="kt-widget__stats">
														<div class="kt-widget__icon">
															<i class="flaticon-pie-chart"></i>
														</div>
														<div class="kt-widget__details">
															<span class="kt-widget__title">Points in Right</span>
															<span class="kt-widget__value"><?php echo number_format($points_right); ?></span>
														</div>
													</div>
												</div>
											</div>
										</div>
										<div class="col-md-12">
											<div class="row">
												<div class="col-md-6">
													<div class="kt-widget__stats kt-margin-r-20">
														<div class="kt-widget__icon">
															<i class="flaticon-pie-chart"></i>
														</div>
														<div class="kt-widget__details">
															<span class="kt-widget__title">Total Matching</span>
															<span class="kt-widget__value"><?php echo number_format($money->pairing_bonus / 10); ?></span>
														</div>
													</div>
												</div>
												<div class="col-md-6">
													<div class="kt-widget__stats">
														<div class="kt-widget__icon">
															<i class="flaticon-pie-chart"></i>
														</div>
														<div class="kt-widget__details">
															<span class="kt-widget__title">Total Direct Referral</span>
															<span class="kt-widget__value"><?php echo number_format($money->direct_referral / 10); ?></span>
														</div>
													</div>
												</div>
											</div>
										</div>

										<div class="col-md-12">
											<h4 class="kt-portlet__head-title kt-align-center">
												Rewards
											</h4>
											<hr>
											<div class="row">
												<div class="col-md-4">
													<div class="kt-widget__stats kt-margin-r-20">
														<div class="kt-widget__icon">
															<i class="flaticon-piggy-bank"></i>
														</div>
														<div class="kt-widget__details">
															<span class="kt-widget__title">Received</span>
															<span class="kt-widget__value"><?php echo amount_format($money->received_rewards); ?></span>
														</div>
													</div>
												</div>
												<div class="col-md-4">
													<div class="kt-widget__stats">
														<div class="kt-widget__icon">
															<i class="flaticon-piggy-bank"></i>
														</div>
														<div class="kt-widget__details">
															<span class="kt-widget__title">Transfered</span>
															<span class="kt-widget__value"><?php echo amount_format($money->transfered_rewards); ?></span>
														</div>
													</div>
												</div>
												<div class="col-md-4">
													<div class="kt-widget__stats">
														<div class="kt-widget__icon">
															<i class="flaticon-piggy-bank"></i>
														</div>
														<div class="kt-widget__details">
															<span class="kt-widget__title">Withdrawn</span>
															<span class="kt-widget__value"><?php echo amount_format($money->withdrawn_bonus); ?></span>
														</div>
													</div>
												</div>
											</div>
										</div>
										<div class="col-md-12">
											<div class="row">
												<div class="col-md-6">
													<div class="kt-widget__stats kt-margin-r-20">
														<div class="kt-widget__icon">
															<i class="flaticon-piggy-bank"></i>
														</div>
														<div class="kt-widget__details">
															<span class="kt-widget__title">Grand Total Rewards</span>
															<span class="kt-widget__value"><?php echo amount_format((($money->total_affiliate_share + $money->received_affiliate_shares)-$money->reinvest_affiliate_shares) + $money->total_bonus + $total_cfc_exclusive + $total_forex_referral); ?></span>
														</div>
													</div>
												</div>
												<div class="col-md-6">
													<div class="kt-widget__stats">
														<div class="kt-widget__icon">
															<i class="flaticon-piggy-bank"></i>
														</div>
														<div class="kt-widget__details">
															<span class="kt-widget__title">Current Total Rewards</span>
															<span class="kt-widget__value"><?php echo amount_format($money->current_bonus + ($money->total_affiliate_share + $money->received_affiliate_shares) - ($money->reinvest_affiliate_shares + $money->withdrawn_affiliate_share + $money->withdrawn_affiliate_share_2 + $money->transfered_affiliate_shares + $money->transfered_affiliate_shares_2) + $available_cfc_exclusive + $available_forex_referral); ?></span>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
								<div class="kt-widget__footer">
									<a href="<?php echo base_url('account/register/'.$this->session->userdata()['user_id']); ?>" class="btn btn-label-success btn-lg btn-upper">Referral Link</a>
								</div>
							<?php } else { ?>
								<div class="kt-widget__footer">
									<button type="button" class="btn btn-label-danger btn-lg btn-upper" data-toggle="modal" data-target="#activate_account_modal">Activate Account</button>
								</div>
							<?php } ?>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<div class="row">
		<div class="col-md-7">
			<div class="kt-portlet kt-portlet--mobile kt-portlet--height-fluid-">
				<div class="kt-portlet__head kt-portlet__head--lg">
					<div class="kt-portlet__head-label">
						<span class="kt-portlet__head-icon">
							<i class="kt-font-brand flaticon2-line-chart"></i>
						</span>
						<h3 class="kt-portlet__head-title">
							CFC WS Rewards
						</h3>
					</div>
				</div>
				<div class="kt-portlet__body">
					<table class="table table-striped table-bordered table-hover table-checkable" id="cfc_ws_rewards_table">
						<thead>
							<tr>
								<th>Type</th>
								<th>WS Products</th>
								<th>No. of Accounts</th>
								<!-- <th>Daily Reward</th> -->
								<th>Total Rewards / Day</th>
								<th>Days Before Maturity</th>
							</tr>
						</thead>
						<tbody>
							<?php foreach($affiliate_shares as $affiliate_share) { ?>
								<tr>
									<td><?php echo ($affiliate_share->invest_type != 'Automated')? 'Manual' : 'Automated'; ?></td>
									<td style="text-align: right;"><?php echo amount_format($affiliate_share->shares_amount); ?></td>
									<td style="text-align: right;"><?php echo ($affiliate_share->no_of_share == 0.5)? 0 : $affiliate_share->no_of_share; ?></td>
									<!-- <td style="text-align: right;"><?php echo amount_format($affiliate_share->daily_profit); ?></td> -->
									<td style="text-align: right;"> <?php echo amount_format($affiliate_share->total_income_per_day); ?> </td>
									<!-- <td style="text-align: right;"><?php echo $affiliate_share->total_income_per_day / $affiliate_share->daily_profit; ?></td> -->
									<td style="text-align: right;"><?php echo floor( ( strtotime($affiliate_share->due_date)-strtotime(date('Y-m-d')) )/3600/24 ); ?></td>
								</tr>
							<?php } ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
		<div class="col-md-5">
			<div class="kt-portlet">
				<div class="kt-portlet__head">
					<div class="kt-portlet__head-label">
						<h3 class="kt-portlet__head-title">
							CFC Exclusive Summary <small>Tokens Breakdown</small>
						</h3>
					</div>
				</div>
				<div class="kt-portlet__body">
					<div class="kt-widget16">
						<div class="kt-widget16__items">
							<div class="kt-widget16__item">
								<span class="kt-widget16__sceduled kt-font-bold">
									Type
								</span>
								<span class="kt-widget16__amount kt-font-bold">
									Amount
								</span>
							</div>
							<div class="kt-widget16__item">
								<span class="kt-widget16__date kt-font-bold">
									Gold
								</span>
								<span class="kt-widget16__price  kt-font-success">
									<?php echo $cfc_exclusive[0]->token_count; ?>
								</span>
							</div>
							<div class="kt-widget16__item">
								<span class="kt-widget16__date kt-font-bold">
									Diamond
								</span>
								<span class="kt-widget16__price  kt-font-danger">
									<?php echo $cfc_exclusive[1]->token_count; ?>
								</span>
							</div>
						</div>
						<div class="kt-widget16__stats">
							<div class="kt-widget16__visual">
								<div id="kt_chart_support_tickets" style="height: 160px; width: 160px;">
								</div>
							</div>
							<div class="kt-widget16__legends">
								<div class="kt-widget16__legend">
									<span class="kt-widget16__bullet kt-bg-success"></span>
									<span class="kt-widget16__stat"><?php echo round((($cfc_exclusive[0]->token_count/148824)*100), 4); ?>%</span>
								</div>
								<div class="kt-widget16__legend">
									<span class="kt-widget16__bullet kt-bg-danger"></span>
									<span class="kt-widget16__stat"><?php echo round((($cfc_exclusive[1]->token_count)/148824)*100, 4); ?>%</span>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- <div class="kt-portlet kt-portlet--mobile">
				<div class="kt-portlet__head">
					<div class="kt-portlet__head-label">
						<h3 class="kt-portlet__head-title">
							Recent Activities (For the month)
						</h3>
					</div>
				</div>
				<div class="kt-portlet__body">
					<div class="kt-scroll" data-scroll="true" data-height="200" data-mobile-height="120">
						<div class="kt-timeline-v2">
							<div class="kt-timeline-v2__items  kt-padding-top-25 kt-padding-bottom-30">
								<?php foreach($money_logs as $money_log) { ?>
									<div class="kt-timeline-v2__item">
										<span class="kt-timeline-v2__item-time"><?php echo date('m/d',strtotime($money_log->date));?></span>
										<div class="kt-timeline-v2__item-cricle">
											<i class="fa fa-genderless kt-font-danger"></i>
										</div>
										<div class="kt-timeline-v2__item-text  kt-padding-top-5">
											<?php echo $money_log->description; ?><br>
											<?php if($money_log->amount > 0) { ?>
												<?php echo 'Credit: ' . amount_format($money_log->amount); ?>
											<?php } ?>
											<?php if($money_log->debit > 0) { ?>
												<?php echo 'Debit: ' . amount_format($money_log->debit); ?>
											<?php } ?>
										</div>
									</div>
								<?php } ?>
							</div>
						</div>
					</div>
				</div>
			</div> -->
		</div>
		<div class="col-md-12">
			<div class="kt-portlet">
				<div class="kt-portlet__head">
					<div class="kt-portlet__head-label">
						<span class="kt-portlet__head-icon kt-hidden">
							<i class="la la-gear"></i>
						</span>
						<h3 class="kt-portlet__head-title">
							Membership Progress Report
						</h3>
					</div>
				</div>
				<div class="kt-portlet__body">
					<div id="kt_flotcharts_2" style="height: 300px;"></div>
				</div>
			</div>
		</div>
		<?php if($cfc_coins_report) { ?>
			<div class="col-md-12">
				<div class="kt-portlet">
					<div class="kt-portlet__head">
						<div class="kt-portlet__head-label">
							<span class="kt-portlet__head-icon kt-hidden">
								<i class="la la-gear"></i>
							</span>
							<h3 class="kt-portlet__head-title">
								CFC Coins
							</h3>
						</div>
					</div>
					<div class="kt-portlet__body">
						<div id="kt_amcharts_6" style="height: 500px;"></div>
					</div>
				</div>
			</div>
		<?php } ?>
	</div>
</div>

<div class="modal fade" id="activate_account_modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-modal="true">
    <div class="modal-dialog modal-sm modal-dialog-centered" role="document">
        <div class="modal-content">
			<form id="activate_account_form" method="POST">
	            <div class="modal-header">
	                <h5 class="modal-title" id="myModalLabel">Activate Account</h5>
	                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
	                </button>
	            </div>
	            <div class="modal-body">
	                    <div class="form-group">
							<label for="pin1" class="form-control-label">Pincode 1</label>
							<input type="text" class="form-control" id="pin1" name="pin1" placeholder="Enter Pincode 1">
	                    </div>
	                    <div class="form-group">
							<label for="pin2" class="form-control-label">Pincode 2</label>
							<input type="text" class="form-control" id="pin2" name="pin2" placeholder="Enter Pincode 2">
	                    </div>
	            </div>
	            <div class="modal-footer">
	                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
					<button type="submit" class="btn btn-primary">Activate</button>
	            </div>
			</form>
        </div>
    </div>
</div>

<div class="modal fade" id="announcement_modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<div class="modal-dialog modal-lg">
		<div class="modal-content" style="height:500px; overflow:auto;">
			<div class="modal-header">
				<h5 class="modal-title" id="myModalLabel">Announcement</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"></button>
			</div>
			<div class="modal-body">
				<div class="row">
					<div class="col-md-12">

						<div class="accordion accordion-solid accordion-toggle-plus" id="accordionExample6">
						<?php $ctr = 0; foreach($announcement_data as $row) { ?>
							<div class="card">
								<div class="card-header" id="heading<?php echo $ctr; ?>">
									<div class="<?php echo $ctr==0?"card-title":"card-title collapsed"; ?>" data-toggle="collapse" data-target="#card-<?php echo $row->id; ?>" aria-expanded="<?php echo $ctr==0?"true":"false"; ?>" aria-controls="card-<?php echo $row->id; ?>">
										<b><?php echo $row->title; ?></b>
									</div>
								</div>
								<div id="card-<?php echo $row->id; ?>" class="<?php echo $ctr==0?"collapse show":"collapse"; ?>" aria-labelledby="heading<?php echo $ctr; ?>" data-parent="#accordionExample6" style="">
									<div class="card-body">
										<?php echo $row->subtitle; ?>
									</div>
								</div>
							</div>
						<?php $ctr++; } ?>
					</div>
				</div>
			</div>
		</div>
		<div class="modal-footer">
			<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
		</div>
	</div>
</div>

<script src="//www.amcharts.com/lib/3/amcharts.js" type="text/javascript"></script>
<script src="//www.amcharts.com/lib/3/serial.js" type="text/javascript"></script>
<script src="//www.amcharts.com/lib/3/radar.js" type="text/javascript"></script>
<script src="//www.amcharts.com/lib/3/pie.js" type="text/javascript"></script>
<script src="//www.amcharts.com/lib/3/plugins/tools/polarScatter/polarScatter.min.js" type="text/javascript"></script>
<script src="//www.amcharts.com/lib/3/plugins/animate/animate.min.js" type="text/javascript"></script>
<script src="//www.amcharts.com/lib/3/plugins/export/export.min.js" type="text/javascript"></script>
<script src="//www.amcharts.com/lib/3/themes/light.js" type="text/javascript"></script>


<script src="<?php echo base_url('resources/metronic/vendors/custom/flot/flot.bundle.js')?>" type="text/javascript"></script>

<script type="text/javascript">
	var KTDashboard = function() {
		var revenueChange = function() {
			if ($('#kt_chart_support_tickets').length == 0) {
				return;
			}

			Morris.Donut({
				element: 'kt_chart_support_tickets',
				data: [{
					label: "Gold",
					value: <?php echo $cfc_exclusive[0]->token_count; ?>
				},
				{
					label: "Diamond",
					value: <?php echo $cfc_exclusive[1]->token_count; ?>
				}
				],
				colors: [
				KTApp.getStateColor('success'),
				KTApp.getStateColor('danger')
				],
			});
		}

		var cfc_ws_rewards_table = function() {
			$('#cfc_ws_rewards_table').DataTable({
				responsive: true,
				order: [4, 'desc']
			});
		}

		var demo6 = function() {
		var cfc_coins_report = <?php echo $cfc_coins_report?$cfc_coins_report:"[]"; ?>;

        var chart = AmCharts.makeChart("kt_amcharts_6", {
            "type": "serial",
            "theme": "light",
            "marginRight": 40,
            "marginLeft": 40,
            "autoMarginOffset": 20,
            "mouseWheelZoomEnabled": true,
            "dataDateFormat": "YYYY-MM-DD",
            "valueAxes": [{
                "id": "v1",
                "axisAlpha": 0,
                "position": "left",
                "ignoreAxisWidth": true
            }],
            "balloon": {
                "borderThickness": 1,
                "shadowAlpha": 0
            },
            "graphs": [{
                "id": "g1",
                "balloon": {
                    "drop": true,
                    "adjustBorderColor": false,
                    "color": "#ffffff"
                },
                "bullet": "round",
                "bulletBorderAlpha": 1,
                "bulletColor": "#FFFFFF",
                "bulletSize": 5,
                "hideBulletsCount": 50,
                "lineThickness": 2,
                "title": "red line",
                "useLineColorForBulletBorder": true,
                "valueField": "value",
                "balloonText": "<span style='font-size:18px;'>[[value]]</span>"
            }],
            "chartScrollbar": {
                "graph": "g1",
                "oppositeAxis": false,
                "offset": 30,
                "scrollbarHeight": 80,
                "backgroundAlpha": 0,
                "selectedBackgroundAlpha": 0.1,
                "selectedBackgroundColor": "#888888",
                "graphFillAlpha": 0,
                "graphLineAlpha": 0.5,
                "selectedGraphFillAlpha": 0,
                "selectedGraphLineAlpha": 1,
                "autoGridCount": true,
                "color": "#AAAAAA"
            },
            "chartCursor": {
                "pan": true,
                "valueLineEnabled": true,
                "valueLineBalloonEnabled": true,
                "cursorAlpha": 1,
                "cursorColor": "#258cbb",
                "limitToGraph": "g1",
                "valueLineAlpha": 0.2,
                "valueZoomable": true
            },
            "valueScrollbar": {
                "oppositeAxis": false,
                "offset": 50,
                "scrollbarHeight": 10
            },
            "categoryField": "date",
            "categoryAxis": {
                "parseDates": true,
                "dashLength": 1,
                "minorGridEnabled": true
            },
            "export": {
                "enabled": false
            },
            "dataProvider": cfc_coins_report
        });

        chart.addListener("rendered", zoomChart);

        zoomChart();

        function zoomChart() {
            chart.zoomToIndexes(chart.dataProvider.length - 40, chart.dataProvider.length - 1);
        }
    }

    var demo2 = function() {
		function randValue() {
			return (Math.floor(Math.random() * (1 + 40 - 20))) + 20;
		}
		var membership = [<?php echo $monthly_registered; ?>];

		var plot = $.plot($("#kt_flotcharts_2"), [{
			data: membership,
			label: "Membership",
			lines: {
				lineWidth: 1,
			},
			shadowSize: 0

		}, ], {
			series: {
				lines: {
					show: true,
					lineWidth: 2,
					fill: true,
					fillColor: {
						colors: [{
							opacity: 0.05
						}, {
							opacity: 0.01
						}]
					}
				},
				points: {
					show: true,
					radius: 3,
					lineWidth: 1
				},
				shadowSize: 2
			},
			grid: {
				hoverable: true,
				clickable: true,
				tickColor: "#eee",
				borderColor: "#eee",
				borderWidth: 1
			},
			colors: [KTApp.getStateColor("brand"), KTApp.getStateColor("danger")],
			xaxis: {
				ticks: [[1, "Jan"], [2, "Feb"], [3, "Mar"], [4, "Apr"], [5, "May"], [6, "Jun"], [7, "Jul"], [8, "Aug"], [9, "Sep"], [10, "Oct"], [11, "Nov"], [12, "Dec"]],
				tickDecimals: 0,
				tickColor: "#eee",
			},
			yaxis: {
				ticks: 11,
				tickDecimals: 0,
				tickColor: "#eee",
			}
		});

		function showTooltip(x, y, contents) {
			$('<div id="tooltip">' + contents + '</div>').css({
				position: 'absolute',
				display: 'none',
				top: y + 5,
				left: x + 15,
				border: '1px solid #333',
				padding: '4px',
				color: '#fff',
				'border-radius': '3px',
				'background-color': '#333',
				opacity: 0.80
			}).appendTo("body").fadeIn(200);
		}

		var previousPoint = null;
		$("#chart_2").bind("plothover", function(event, pos, item) {
			$("#x").text(pos.x.toFixed(2));
			$("#y").text(pos.y.toFixed(2));

			if (item) {
				if (previousPoint != item.dataIndex) {
					previousPoint = item.dataIndex;

					$("#tooltip").remove();
					var x = item.datapoint[0].toFixed(2),
						y = item.datapoint[1].toFixed(2);

					showTooltip(item.pageX, item.pageY, item.series.label + " of " + x + " = " + y);
				}
			} else {
				$("#tooltip").remove();
				previousPoint = null;
			}
		});
	}

		return {
	        // Init demos
	        init: function() {
	        	revenueChange();
	        	cfc_ws_rewards_table();
	        	demo6();
	        	demo2();
	        	var loading = new KTDialog({'type': 'loader', 'placement': 'top center', 'message': 'Loading ...'});
	        	loading.show();

	        	setTimeout(function() {
	        		loading.hide();
	        	}, 3000);
	        }
	    };
	}();

	jQuery(document).ready(function() {
		<?php if($announcement_data){ ?> $('#announcement_modal').modal('show'); <?php } ?>
		KTDashboard.init();

		toastr.options = {
		  "closeButton": false,
		  "debug": false,
		  "newestOnTop": false,
		  "progressBar": false,
		  "positionClass": "toast-top-right",
		  "preventDuplicates": false,
		  "onclick": null,
		  "showDuration": "300",
		  "hideDuration": "1000",
		  "timeOut": "5000",
		  "extendedTimeOut": "1000",
		  "showEasing": "swing",
		  "hideEasing": "linear",
		  "showMethod": "fadeIn",
		  "hideMethod": "fadeOut"
		};

		$('#get_referral_link').on('click', function(e) {
			var element = "<?php echo base_url('account/register/'.$this->session->userdata()['user_id']); ?>";

			var $temp = $("<input>");
			$("body").append($temp);
			$temp.val(element).select();
			document.execCommand("copy");
			$temp.remove();

			toastr.success("Referral Link Copied.", "Success!");
		});

		$( "#activate_account_form" ).validate({
            // define validation rules
            rules: {
				pin1 : {
					required: true
				},
				pin2 : {
					required: true
				}
            },
            
            invalidHandler: function(event, validator) {     
            	swal.fire("Error!", "Please fill all required fields and try submitting again.", "warning");
            },

            submitHandler: function (form) {
                $.ajax({
					type: 'POST',
					url: '<?php echo base_url();?>account/activate_account',
					data: $('#activate_account_form').serialize(),
					success: function(data) 
					{
						if(data.search('Success') != -1) {
							$('#activate_account_modal').modal('toggle');
							swal.fire({
				                title: 'Successful activation!',
				                text: 'To fully activate this account, you will be logged out in 3 seconds.',
				                timer: 3000,
				                onOpen: function() {
				                    swal.showLoading();
				                }
				            }).then(function(result) {
				                if (result.dismiss === 'timer') {
									window.location = "<?php echo base_url('account/logout'); ?>";
				                }
				            });
						} else {
							swal.fire("Error!", data, "error");
						}
					}
				});
            }
        });
	});
</script>