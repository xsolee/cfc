<!DOCTYPE html>
<html lang="en">
	<head>

		<!--begin::Base Path (base relative path for assets of this page) -->
		<base href="../../../../">

		<!--end::Base Path -->
		<meta charset="utf-8" />
		<title>CFC Team</title>
		<meta name="description" content="Login page example">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

		<!--begin::Fonts -->
		<script src="https://ajax.googleapis.com/ajax/libs/webfont/1.6.16/webfont.js"></script>
		<script>
			WebFont.load({
				google: {
					"families": ["Poppins:300,400,500,600,700", "Roboto:300,400,500,600,700"]
				},
				active: function() {
					sessionStorage.fonts = true;
				}
			});
		</script>

		<!--end::Fonts -->

		<!--begin::Page Custom Styles(used by this page) -->
		<link href="<?php echo base_url('resources/css/login-1.css'); ?>" rel="stylesheet" type="text/css" />
		<!-- <link href="<?php echo base_url('resources/metronic/css/demo1/pages/login/login-1.css'); ?>" rel="stylesheet" type="text/css" /> -->

		<!--end::Page Custom Styles -->

		<!--begin:: Global Mandatory Vendors -->
		<link href="<?php echo base_url('resources/metronic/vendors/general/perfect-scrollbar/css/perfect-scrollbar.css'); ?>" rel="stylesheet" type="text/css" />

		<!--end:: Global Mandatory Vendors -->

		<!--begin:: Global Optional Vendors -->
		<link href="<?php echo base_url('resources/metronic/vendors/general/animate.css/animate.css'); ?>" rel="stylesheet" type="text/css" />
		<link href="<?php echo base_url('resources/metronic/vendors/general/bootstrap-datepicker/dist/css/bootstrap-datepicker3.css'); ?>" rel="stylesheet" type="text/css" />

		<!--end:: Global Optional Vendors -->

		<!--begin::Global Theme Styles(used by all pages) -->
		<link href="<?php echo base_url('resources/metronic/css/demo1/style.bundle.css'); ?>" rel="stylesheet" type="text/css" />

		<!--end::Global Theme Styles -->

		<!--begin::Layout Skins(used by all pages) -->
		<link href="<?php echo base_url('resources/metronic/css/demo1/skins/header/base/light.css'); ?>" rel="stylesheet" type="text/css" />
		<link href="<?php echo base_url('resources/metronic/css/demo1/skins/header/menu/light.css'); ?>" rel="stylesheet" type="text/css" />
		<link href="<?php echo base_url('resources/metronic/css/demo1/skins/brand/dark.css'); ?>" rel="stylesheet" type="text/css" />
		<link href="<?php echo base_url('resources/metronic/css/demo1/skins/aside/dark.css'); ?>" rel="stylesheet" type="text/css" />

		<!--end::Layout Skins -->
		<link rel="shortcut icon" href="<?php echo base_url('resources/images/favicon.ico');?>">
	</head>
	<body class="kt-quick-panel--right kt-demo-panel--right kt-offcanvas-panel--right kt-header--fixed kt-header-mobile--fixed kt-subheader--enabled kt-subheader--fixed kt-subheader--solid kt-aside--enabled kt-aside--fixed kt-page--loading">
		<!-- begin:: Page -->
		<div class="kt-grid kt-grid--ver kt-grid--root">
			<div class="kt-grid kt-grid--hor kt-grid--root kt-login kt-login--v1 kt-login--signup" id="kt_login">
				<div class="kt-grid__item kt-grid__item--fluid kt-grid kt-grid--desktop kt-grid--ver-desktop kt-grid--hor-tablet-and-mobile">

					<!--begin::Aside-->
					<div class="kt-grid__item kt-grid__item--order-tablet-and-mobile-2 kt-grid kt-grid--hor kt-login__aside" style="background-image: url(<?php echo base_url('resources/metronic/media/bg/bg-2.jpg'); ?>);">
						<div class="kt-grid__item">
							<a href="#" class="kt-login__logo">
								<img alt="Logo" src="<?php echo base_url('resources/images/logo100x100.png');?>" >
							</a>
						</div>
						<div class="kt-grid__item kt-grid__item--fluid kt-grid kt-grid--ver">
							<div class="kt-grid__item kt-grid__item--middle">
								<h3 class="kt-login__title">Welcome to <b>CFC</b> Team!</h3>
								<h4 class="kt-login__subtitle">Enter your details to create your account.</h4>
							</div>
						</div>
						<div class="kt-grid__item">
							<div class="kt-login__info">
								<div class="kt-login__copyright">
									<strong>&copy; 2019. <a href="<?php echo base_url('dashboard');?>"> &nbsp; Crowd Funding Community Team.</a></strong> &nbsp;  All rights reserved.
								</div>
							</div>
						</div>
					</div>
					<!--end::Aside-->
					<!--begin::Content-->
					<div class="kt-grid__item kt-grid__item--fluid  kt-grid__item--order-tablet-and-mobile-1  kt-login__wrapper">
						<!--begin::Body-->
						<div class="kt-login__body">

							<!--begin::Signin-->
							<div class="kt-login__form">
								<div class="kt-login__title">
									<h3>Register</h3>
								</div>
								<!--begin::Form-->
								<form id="register_form" class="kt-form" method="post">
									<div class="form-group">
										<input type="text" class="form-control" id="username" name="username" placeholder="Username" autocomplete="off" required onkeydown="return (event.keyCode!=189 && event.keyCode!=32);">
									</div>
									<div class="form-group">
										<input type="password" class="form-control" id="password" name="password" placeholder="Password" autocomplete="off" required>
									</div>
									<div class="form-group">
										<input type="password" class="form-control" id="confirm_password" name="confirm_password" placeholder="Retype Password" autocomplete="off" data-rule-equalTo="#password" required>
									</div>
									<div class="form-group">
										<input type="text" class="form-control" id="firstname" name="firstname" placeholder="First Name" required>
									</div>
									<div class="form-group">
										<input type="text" class="form-control" id="middlename" name="middlename" placeholder="Middle Name" required>
									</div>
									<div class="form-group">
										<input type="text" class="form-control" id="lastname" name="lastname" placeholder="Last Name" required>
									</div>
									<div class="form-group">
										<input type="email" class="form-control" id="email_address" name="email_address" placeholder="Email Address" required>
									</div>
									<div class="form-group">
										<input type="text" class="form-control" id="mobile_number" name="mobile_number" placeholder="Mobile Number" required minlength="11" maxlength="13">
									</div>
									<div class="form-group">
										<div class="form-group date">
											<div class="form-group-addon">
												<i class="fa fa-calendar"></i>
											</div>
											<input type="text" class="form-control pull-right" id="datepicker" name="birthday" placeholder="Birthday">
										</div>
									</div>
									<div class="form-group">
										<select class="form-control selectpicker" tabindex="-1" name="gender">
											<option value="">Gender</option>
											<option value="Male">Male</option>
											<option value="Female">Female</option>
										</select>
									</div>
									<div class="form-group">
										<input type="text" class="form-control" id="country" name="country" placeholder="Country">
									</div>
									<div class="form-group">
										<input type="text" class="form-control" id="Address" name="address" placeholder="Address">
									</div>
									<div class="form-group">
										<input type="text" class="form-control" id="sponsor_ID" name="sponsor_ID" placeholder="Sponsor ID" value="<?php echo $sponsor_id; ?>" <?php echo $sponsor_id!=null?"readonly":""; ?>>
									</div>
									<div class="form-group">
										<input type="text" class="form-control" id="placement_ID" name="placement_ID" placeholder="Placement ID" required>
									</div>
									<div class="form-group">
										<select class="form-control selectpicker" tabindex="-1" name="placement" required>
											<option value="">Placement</option>
											<option value="Left">Left</option>
											<option value="Right">Right</option>
										</select>
									</div>
									<div class="form-group">
										<input type="text" class="form-control" id="pin1" name="pin1" placeholder="PIN1">
									</div>
									<div class="form-group">
										<input type="text" class="form-control" id="pin2" name="pin2" placeholder="PIN2">
									</div>
									<div class="kt-login__actions">
										<button id="kt_login_signup_submit" type="submit" class="btn btn-primary btn-elevate kt-login__btn-primary">Register</button>&nbsp;&nbsp;
									</div>
								</form>

								<!--end::Form-->
							</div>

							<!--end::Signin-->
						</div>

						<!--end::Body-->
					</div>
					<!--end::Content-->
				</div>
			</div>
		</div>

		<!-- end:: Page -->

		<!-- begin::Global Config(global config for global JS sciprts) -->
		<script>
			var KTAppOptions = {
				"colors": {
					"state": {
						"brand": "#5d78ff",
						"dark": "#282a3c",
						"light": "#ffffff",
						"primary": "#5867dd",
						"success": "#34bfa3",
						"info": "#36a3f7",
						"warning": "#ffb822",
						"danger": "#fd3995"
					},
					"base": {
						"label": ["#c5cbe3", "#a1a8c3", "#3d4465", "#3e4466"],
						"shape": ["#f0f3ff", "#d9dffa", "#afb4d4", "#646c9a"]
					}
				}
			};
		</script>

		<!-- end::Global Config -->

		<!--begin:: Global Mandatory Vendors -->
		<script src="<?php echo base_url('resources/metronic/vendors/general/jquery/dist/jquery.js'); ?>" type="text/javascript"></script>
		<script src="<?php echo base_url('resources/metronic/vendors/general/jquery-validation/dist/jquery.validate.js');?>" type="text/javascript"></script>
		<script src="<?php echo base_url('resources/metronic/vendors/general/jquery-form/dist/jquery.form.min.js');?>" type="text/javascript"></script>
		<script src="<?php echo base_url('resources/metronic/vendors/general/popper.js/dist/umd/popper.js'); ?>" type="text/javascript"></script>
		<script src="<?php echo base_url('resources/metronic/vendors/general/bootstrap/dist/js/bootstrap.min.js'); ?>" type="text/javascript"></script>
		<script src="<?php echo base_url('resources/metronic/vendors/general/js-cookie/src/js.cookie.js'); ?>" type="text/javascript"></script>
		<script src="<?php echo base_url('resources/metronic/vendors/general/moment/min/moment.min.js'); ?>" type="text/javascript"></script>
		<script src="<?php echo base_url('resources/metronic/vendors/general/tooltip.js/dist/umd/tooltip.min.js'); ?>" type="text/javascript"></script>
		<script src="<?php echo base_url('resources/metronic/vendors/general/perfect-scrollbar/dist/perfect-scrollbar.js'); ?>" type="text/javascript"></script>
		<script src="<?php echo base_url('resources/metronic/vendors/general/sticky-js/dist/sticky.min.js'); ?>" type="text/javascript"></script>
		<script src="<?php echo base_url('resources/metronic/vendors/general/wnumb/wNumb.js'); ?>" type="text/javascript"></script>

		<!--end:: Global Mandatory Vendors -->

		<!--begin:: Global Optional Vendors -->
		<script src="<?php echo base_url('resources/metronic/vendors/general/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js'); ?>" type="text/javascript"></script>

		<!--end:: Global Optional Vendors -->

		<!--begin::Global Theme Bundle(used by all pages) -->
		<script src="<?php echo base_url('resources/metronic/js/demo1/scripts.bundle.js'); ?>" type="text/javascript"></script>

		<!--end::Global Theme Bundle -->

		<!--begin::Page Scripts(used by this page) -->
		<script type="text/javascript">
			var KTLoginGeneral = function() {

			    var login = $('#kt_login');

			    var showErrorMsg = function(form, type, msg) {
			        var alert = $('<div class="kt-alert kt-alert--outline alert alert-' + type + ' alert-dismissible" role="alert">\
						<button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>\
						<span></span>\
					</div>');

			        form.find('.alert').remove();
			        alert.prependTo(form);
			        //alert.animateClass('fadeIn animated');
			        KTUtil.animateClass(alert[0], 'fadeIn animated');
			        alert.find('span').html(msg);
			    }

			    // Private Functions
			    var displaySignUpForm = function() {
			        login.removeClass('kt-login--forgot');
			        login.removeClass('kt-login--signin');

			        login.addClass('kt-login--signup');
			        KTUtil.animateClass(login.find('.kt-login__signup')[0], 'flipInX animated');
			    }

			    var handleFormSwitch = function() {
			        $('#kt_login_signup').click(function(e) {
			            e.preventDefault();
			            displaySignUpForm();
			        });
			    }

			    var handleSignUpFormSubmit = function() {
			    	$( "#register_form" ).validate({
			            rules: {
			            	sponsor_ID : {
			            		required: true
			            	},
							placement_ID : {
								required: true
							},
							placement : {
								required: true
							},
							pin1 : {
								required: true
							},
							pin2 : {
								required: true
							},
							username : {
								required: true
							},
							password : {
								required: true,
								minlength: 6
							},
							confirm_password : {
								required: true,
								minlength: 6,
								equalTo : "#password"
							},
							firstname : {
								required: true
							},
							middlename : {
								required: true
							},
							lastname : {
								required: true
							},
							mobile_number : {
								required: true
							},
							email_address : {
								required: true,
								email: true
							},
							country : {
								required: true
							},
							address : {
								required: true
							},
							birthday : {
								required: true
							},
							gender : {
								required: true
							}
			            },
			            
			            invalidHandler: function(event, validator) {     
				            showErrorMsg(signInForm, 'warning', "Error!", "Oh snap! Change a few things up and try submitting again.");
			            },

			            submitHandler: function (form) {
			                $.ajax({
								type: 'POST',
								url: '<?php echo base_url();?>Account/register_account',
								data: $('#register_form').serialize(),
								success: function(data) 
								{
									if (data.search("Success") != -1) {window.location.replace('<?php echo base_url();?>dashboard');}
				                	else {
					                    var signInForm = login.find('.kt-login__form form');
					                    signInForm.clearForm();
					                    signInForm.validate().resetForm();
				                   	 	showErrorMsg(signInForm, 'warning', data);
									}
								}
							});
			            }
			        });
			    }

			    // Public Functions
			    return {
			        // public functions
			        init: function() {
			            handleFormSwitch();
			            handleSignUpFormSubmit();
			        }
			    };
			}();

			// Class Initialization
			jQuery(document).ready(function() {
			    KTLoginGeneral.init();

		    	$('#datepicker').datepicker({
					autoclose: true,
					format: 'yyyy-mm-dd'
				});
			});
		</script>
		<!--end::Page Scripts -->
	</body>
</html>
