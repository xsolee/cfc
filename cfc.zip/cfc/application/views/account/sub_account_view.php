<section class="content">
    <div class="row">
        <div class="col-md-12">
            <div class="box box-darkbrown">
                <div class="box-body sub_account_table">
                    <table id="sub_account_table" class="table table-striped table-hover nowrap table-bordered" style="font-size: 100%;">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Sub Account ID</th>
                                <th>Sub Account Username</th>
                                <th>Sub Account Placement ID</th>
                                <th>Main Account ID</th>
                                <th>Date Created</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($result as $row) { ?>
                                <tr class="tr-hover">
                                    <td><?php echo $row->id; ?></td>
                                    <td><?php echo $row->sub_account_id ?></td>
                                    <td><?php echo $row->username ?></td>
                                    <td><?php echo $row->placement_ID ?></td>
                                    <td><?php echo $row->main_account_id; ?></td>
                                    <td><?php echo $row->date_created; ?></td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</section>

<script type="text/javascript">
    $(document).ready(function(){
        var sub_account_table = $('#sub_account_table').DataTable({
            "order": [0, 'asc']
        });

        $('#datepicker').datepicker({
            autoclose: true,
            format: 'yyyy-mm-dd'
        });
    });
</script>