<div class="kt-container kt-container--fluid kt-grid__item kt-grid__item--fluid">
	<div class="kt-portlet kt-portlet--mobile kt-portlet--height-fluid-">
		<div class="kt-portlet__head kt-portlet__head--lg">
			<div class="kt-portlet__head-label">
				<span class="kt-portlet__head-icon">
					<i class="kt-font-brand flaticon2-line-chart"></i>
				</span>
				<h3 class="kt-portlet__head-title">
					Accounts Information
				</h3>
			</div>
		</div>
		<div class="kt-portlet__body">
			<table class="table table-striped table-bordered table-hover table-checkable" id="accounts_table">
				<thead>
					<tr>
						<th>No</th>
						<th>Account ID</th>
						<th>Username</th>
						<th>Name</th>
						<th>Status</th>
						<th>Contact No</th>
						<th>Email</th>
						<th>Birthday</th>
						<th>Date Joined</th>
					</tr>
				</thead>
				<tbody>
					<?php foreach($account_details as $row) { ?>
						<tr class="tr-hover">
							<td><?php echo $row->id; ?></td>
							<td><?php echo $row->account_id; ?></td>
							<td><?php echo $row->username; ?></td>
							<td><?php echo $row->first_name . " " . $row->last_name; ?></td>
							<td><?php echo $row->activated? "Activated": "Guest"; ?></td>
							<td><?php echo $row->mobile_number; ?></td>
							<td><?php echo $row->email_address; ?></td>
							<td><?php echo $row->birthday; ?></td>
							<td><?php echo $row->date_created; ?></td>
						</tr>
					<?php } ?>
				</tbody>
			</table>
		</div>
	</div>
</div>

<script type="text/javascript">
	$(document).ready(function(){
		$('#accounts_table').DataTable({
			"order": [0, 'desc'],
			"iDisplayLength": 25,
			responsive: true
		});
	});
</script>