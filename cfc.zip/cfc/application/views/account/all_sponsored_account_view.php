<section class="content">
	<div class="row">
		<div class="col-sm-12">
			<div class="box box-primary">
				<div class="box-body">
					<table id="sponsors_table" class="table table-striped table-hover nowrap table-bordered" style="width:100%;">
    					<thead>
							<tr>
								<th>ID</th>
								<th>Sponsor ID</th>
								<th>Sponsor Username</th>
								<th>Sponsor Name</th>
								<th>Sponsored ID</th>
								<th>Sponsored Username</th>
								<th>Sponsored Name</th>
								<th>Date</th>
							</tr>
    					</thead>
						<tbody>
							<?php foreach($accounts as $account) { ?>
								<tr>
									<td><?php echo $account->referral_id; ?></td>
									<td><?php echo $account->sponsor_id; ?></td>
									<td><?php echo $account->sponsor_username; ?></td>
									<td><?php echo ucwords($account->sponsor_firstname." ".$account->sponsor_lastname); ?></td>
									<td><?php echo $account->sponsored_id; ?></td>
									<td><?php echo $account->sponsored_username; ?></td>
									<td><?php echo ucwords($account->sponsored_firstname." ".$account->sponsored_lastname); ?></td>
									<td><?php echo $account->date_created; ?></td>
								</tr>
							<?php } ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</section>
<script type="text/javascript">

    $(document).ready(function() {

        $('#sponsors_table').DataTable({
            "order": [0, 'desc']
        });
    });

</script>