<section class="content">
	<div class="row">
		<div class="col-md-12">
			<div class="box box-darkbrown">
				<div class="box-body accounts_table nowrap">
					<table id="accounts_table" class="table table-bordered table-striped">
						<thead>
							<tr>
								<th>No</th>
								<th>Account ID</th>
								<th>Username</th>
								<th>Name</th>
								<th>Status</th>
								<th>Date Joined</th>
							</tr>
						</thead>
						<tbody>
							<?php $i = 1;
								foreach($account_details as $row) { ?>
								<tr class="tr-hover">
									<td><?php echo $i++; ?></td>
									<td><?php echo $row->account_id; ?></td>
									<td><?php echo $row->username; ?></td>
									<td><?php echo ucwords($row->first_name . " " . $row->last_name); ?></td>
									<td><?php echo $row->activated? "Activated": "Guest"; ?></td>
									<td><?php echo $row->date_created; ?></td>
								</tr>
							<?php } ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</section>

<script type="text/javascript">
	$(document).ready(function(){
		$('#accounts_table').DataTable({
			"order": [0, 'asc'],
			"iDisplayLength": 25,
			responsive: true
		});
	});
</script>