<div class="kt-container  kt-container--fluid  kt-grid__item kt-grid__item--fluid">
	<div class="row">
		<div class="col-md-7">
			<div class="kt-portlet">
				<div class="kt-portlet__head">
					<div class="kt-portlet__head-label">
						<h3 class="kt-portlet__head-title">
							Profile View
						</h3>
					</div>
				</div>
				<form class="kt-form kt-form--label-right" id="register_form">
					<div class="kt-portlet__body">
						<div class="col-md-6">
							<div class="form-group row">
								<label class="col-sm-3 ">Sponsor ID</label>
								<div class="col-sm-9">
									<input type="text" class="form-control" disabled value="<?php echo $account->sponsor_ID; ?>">
								</div>
							</div>
							<div class="form-group row">
								<label class="col-sm-3 ">Placement ID</label>
								<div class="col-sm-9">
									<input type="text" class="form-control" disabled value="<?php echo $account->placement_ID; ?>">
								</div>
							</div>
							<div class="form-group row">
								<label for="pin1" class="col-sm-3 ">PIN1</label>
								<div class="col-sm-5">
									<input type="text" class="form-control" disabled value="<?php echo $account->PIN1; ?>">
								</div>
							</div>
							<div class="form-group row">
								<label for="pin2" class="col-sm-3 ">PIN2</label>
								<div class="col-sm-5">
									<input type="text" class="form-control" disabled value="<?php echo $account->PIN2; ?>">
								</div>
							</div>
							<div class="form-group row">
								<label class="col-sm-3 ">Username</label>
								<div class="col-sm-9">
									<input type="text" class="form-control" disabled value="<?php echo $account->username; ?>">
								</div>
							</div>
							<div class="form-group row">
								<label class="col-sm-3 ">Last Name</label>
								<div class="col-sm-9">
									<input type="text" class="form-control" disabled value="<?php echo $account->last_name; ?>">
								</div>
							</div>
							<div class="form-group row">
								<label class="col-sm-3 ">First Name</label>
								<div class="col-sm-9">
									<input type="text" class="form-control" disabled value="<?php echo $account->first_name; ?>">
								</div>
							</div>
						</div>
						<div class="col-md-6">
							<div class="form-group row">
								<label for="middle_name" class="col-sm-3 ">Middle Name</label>
								<div class="col-sm-9">
									<input type="text" class="form-control" name="middle_name" value="<?php echo $account->middle_name; ?>">
								</div>
							</div>
							<div class="form-group row">
								<label for="mobile_number" class="col-sm-3 ">Mobile Number</label>
								<div class="col-sm-9">
									<input type="text" class="form-control" id="mobile_number" name="mobile_number" required="" maxlength="11" value="<?php echo $account->mobile_number; ?>">
								</div>
							</div>
							<div class="form-group row">
								<label for="email_address" class="col-sm-3 ">Email Address</label>
								<div class="col-sm-9">
									<input type="email" class="form-control" id="email_address" name="email_address" value="<?php echo $account->email_address; ?>">
								</div>
							</div>
							<div class="form-group row">
								<label for="country" class="col-sm-3 ">Country</label>
								<div class="col-sm-9">
									<input type="text" class="form-control" id="country" name="country" value="<?php echo $account->country; ?>">
								</div>
							</div>
							<div class="form-group row">
								<label for="address" class="col-sm-3 ">Address</label>
								<div class="col-sm-9">
									<input type="text" class="form-control" id="Address" name="address" value="<?php echo $account->address; ?>">
								</div>
							</div>
							<div class="form-group row">
								<label for="birthday" class="col-sm-3 ">Birthday</label>
								<div class="date col-sm-9">
									<input type="text" class="form-control pull-right" id="datepicker" name="birthday" value="<?php echo $account->birthday; ?>">
								</div>
							</div>
							<div class="form-group row">
								<label for="gender" class="col-sm-3 ">Gender</label>
								<div class="col-sm-5">
									<select class="form-control selectpicker" tabindex="-1" name="gender">
										<option <?php echo ($account->gender == 'Male')? 'Selected' : '';?>>Male</option>
										<option <?php echo ($account->gender == 'Female')? 'Selected' : '';?>>Female</option>
									</select>
								</div>
							</div>
							<div class="form-group row" style="padding-left: 5%;">
								<button type="submit" class="btn btn-danger btn-block btn-flat">Update</button>
							</div>
						</div>
					</div>
					<input type="hidden" name="account_id" value="<?php echo $account->account_id; ?>">
				</form>
			</div>
		</div>
	</div>
</div>

<script>

	jQuery(document).ready(function() {   

		$('.kt-select2').select2({
			placeholder: "Select a state"
		});

		$('#datepicker').datepicker({
			todayHighlight: true,
			orientation: "bottom left",
			templates: {
				leftArrow: '<i class="la la-angle-left"></i>',
				rightArrow: '<i class="la la-angle-right"></i>'
			},
			autoclose: true,
			format: 'yyyy-mm-dd'
		});

		$( "#register_form" ).validate({
			rules: {

				middlename : {
					required: true
				},
				mobile_number : {
					required: true
				},
				email_address : {
					required: true,
					email: true
				},
				country : {
					required: true
				},
				address : {
					required: true
				},
				birthday : {
					required: true
				},
				gender : {
					required: true
				}
			},
			
			invalidHandler: function(event, validator) {     
				swal.fire("Error!", "Oh snap! Change a few things up and try submitting again.", "warning");
			},

			submitHandler: function (form) {
				$.ajax({
					type: 'POST',
					url: '<?php echo base_url();?>Account/update_account',
					data: $('#register_form').serialize(),
					success: function(data) 
					{
						swal.fire("Success!", "Account Updated!", "success");
					}
				});
			}
		});
	});
</script>