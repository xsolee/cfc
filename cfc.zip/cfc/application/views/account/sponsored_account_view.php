<section class="content">
	<div class="row">
		<div class="col-sm-12">
			<div class="box box-primary">
				<div class="box-body">
					<table class="table table-striped table-hover nowrap table-bordered" style="width:100%;">
						<tbody>
							<tr>
								<th>ID</th>
								<th>Account ID</th>
								<th>Account Username</th>
								<th>Account Name</th>
								<th>Date</th>
							</tr>
							<?php foreach($accounts as $account) { ?>
								<tr>
									<td><?php echo $account->referral_id; ?></td>
									<td><?php echo $account->sponsored_id; ?></td>
									<td><?php echo $account->username; ?></td>
									<td><?php echo ucwords($account->first_name." ".$account->last_name); ?></td>
									<td><?php echo $account->date_created; ?></td>
								</tr>
							<?php } ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</section>