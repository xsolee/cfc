<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<title>CFC Team<?php echo " | " . $title; ?></title>
		<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
		<link rel="stylesheet" href="<?php echo base_url('resources/bootstrap-3.3.7-dist/css/bootstrap.min.css');?>">
		<link rel="stylesheet" href="<?php echo base_url('resources/font-awesome-4.7.0/css/font-awesome.min.css');?>">
		<link rel="stylesheet" href="<?php echo base_url('resources/adminlte-2.3.11/dist/css/AdminLTE.min.css');?>">
		<style type="text/css">
		#myVideo {
			position: fixed;
			right: 0;
			bottom: 0;
			min-width: 100%; 
			min-height: 100%;
		}
		.background-overlay{
		    background-color: #262626;
		    opacity: 0.5;
		    height: 100%;
		    width: 100%;
		}
		.login-box{
			position: fixed;
			top:0; 
			left:0;
			right: 0;
			box-shadow: 1px 1px 2px black;
		}
		</style>
	</head>
	<body class="hold-transition login-page">
		<!-- The video -->
		<!-- <video autoplay muted loop id="myVideo">
		  <source src="<?php echo base_url('resources/video/NetworkingVid.mp4');?>" type="video/mp4">
		</video>
		<div class="background-overlay"></div> -->
		<div class="login-box">
			<div class="login-box-body">
				<div class="text-center">
					CFC Team<!--<img src="<?php echo base_url('resources/images/logo.jpg');?>" width="200">-->
				</div>
				<div class="text-center margin">
					<p>Forgot Password?<br>Please enter your username below to reset your password.</p>
				</div>
				<div class="row">
					<div class="message <?php if($message!=null){echo 'alert alert-danger margin'; }?>">
						<strong id="message"><?php echo $message; ?></strong>
					</div>
				</div>
				<form id="reset_password_form" action="<?php echo base_url('Account/reset_password'); ?>" method="post">
					<div class="form-group has-feedback">
						<input type="text" class="form-control" id="username" name="username" placeholder="Username" required>
						<span class="glyphicon glyphicon-user form-control-feedback"></span>
					</div>
					<div class="row">
						<div class="col-sm-6" style="float: none; margin: 0 auto; ">
							<button type="submit" class="btn btn-danger btn-block btn-flat">Reset Password</button>
						</div>
					</div>
				</form>
				<div class="text-center margin">
					<a href="<?php echo base_url('account/register');?>">Register a new account</a><br>
				</div>
			</div>
		</div>
		<script src="<?php echo base_url('resources/adminlte-2.3.11/plugins/jQuery/jquery-2.2.3.min.js');?>"></script>
		<script src="<?php echo base_url('resources/adminlte-2.3.11/bootstrap/js/bootstrap.min.js');?>"></script>
	</body>
</html>
