<div class="kt-container  kt-container--fluid  kt-grid__item kt-grid__item--fluid">
	<div class="row">
		<div class="col-md-7">
			<div class="kt-portlet">
				<div class="kt-portlet__head">
					<div class="kt-portlet__head-label">
						<h3 class="kt-portlet__head-title">
							New Account
						</h3>
					</div>
				</div>
				<form class="kt-form kt-form--label-right" id="register_form">
					<div class="kt-portlet__body">
						<div class="row">
							<div class="col-md-6">
								<div class="form-group row">
									<label class="col-form-label col-lg-3 col-sm-12">Sponsor ID</label>
									<div class="col-lg-9 col-md-9 col-sm-12">
										<input type="text" class="form-control" name="sponsor_ID" placeholder="Sponsor ID" value="<?php echo $this->session->userdata()['user_id']; ?>">
										
									</div>
								</div>
								<div class="form-group row">
									<label class="col-form-label col-lg-3 col-sm-12">Placement ID</label>
									<div class="col-lg-9 col-md-9 col-sm-12">
										<input type="text" class="form-control" name="placement_ID" placeholder="Placement ID">
										
									</div>
								</div>
								<div class="form-group row">
									<label class="col-form-label col-lg-3 col-sm-12">Placement</label>
									<div class="col-lg-9 col-md-9 col-sm-12 form-group-sub">
										<select class="form-control kt-select2" name="placement">
											<option value="Left">Left</option>
											<option value="Right">Right</option>
										</select>
										
									</div>
								</div>
								<div class="form-group row">
									<label class="col-form-label col-lg-3 col-sm-12">PIN 1</label>
									<div class="col-lg-9 col-md-9 col-sm-12">
										<input type="text" class="form-control" name="pin1" placeholder="Pin 1">
										
									</div>
								</div>
								<div class="form-group row">
									<label class="col-form-label col-lg-3 col-sm-12">PIN 2</label>
									<div class="col-lg-9 col-md-9 col-sm-12">
										<input type="text" class="form-control" name="pin2" placeholder="Pin 2">
										
									</div>
								</div>
								<div class="form-group row">
									<label class="col-form-label col-lg-3 col-sm-12">Username</label>
									<div class="col-lg-9 col-md-9 col-sm-12">
										<input type="text" class="form-control" name="username" placeholder="Username" autocomplete="off" onkeydown="return (event.keyCode!=189 && event.keyCode!=32);">
										
									</div>
								</div>
								<div class="form-group row">
									<label class="col-form-label col-lg-3 col-sm-12">Password</label>
									<div class="col-lg-9 col-md-9 col-sm-12">
										<input type="password" class="form-control" id="password" name="password" placeholder="Password" autocomplete="off">
										
									</div>
								</div>
								<div class="form-group row">
									<label class="col-form-label col-lg-3 col-sm-12">Confirm Password</label>
									<div class="col-lg-9 col-md-9 col-sm-12">
										<input type="password" class="form-control" name="confirm_password" placeholder="Confirm Password" autocomplete="off">
										
									</div>
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group row">
									<label class="col-form-label col-lg-3 col-sm-12">First Name</label>
									<div class="col-lg-9 col-md-9 col-sm-12">
										<input type="text" class="form-control" name="firstname" placeholder="First Name">
										
									</div>
								</div>
								<div class="form-group row">
									<label class="col-form-label col-lg-3 col-sm-12">Middle Name</label>
									<div class="col-lg-9 col-md-9 col-sm-12">
										<input type="text" class="form-control" name="middlename" placeholder="Middle Name">
										
									</div>
								</div>
								<div class="form-group row">
									<label class="col-form-label col-lg-3 col-sm-12">Last Name</label>
									<div class="col-lg-9 col-md-9 col-sm-12">
										<input type="text" class="form-control" name="lastname" placeholder="Last Name">
										
									</div>
								</div>
								<div class="form-group row">
									<label class="col-form-label col-lg-3 col-sm-12">Mobile Number</label>
									<div class="col-lg-9 col-md-9 col-sm-12">
										<input type="text" class="form-control" name="mobile_number" placeholder="09xxxxxxxxx" maxlength="13">
										
									</div>
								</div>
								<div class="form-group row">
									<label class="col-form-label col-lg-3 col-sm-12">Email Address</label>
									<div class="col-lg-9 col-md-9 col-sm-12">
										<input type="email" class="form-control" name="email_address" placeholder="Email Address">
										
									</div>
								</div>
								<div class="form-group row">
									<label class="col-form-label col-lg-3 col-sm-12">Country</label>
									<div class="col-lg-9 col-md-9 col-sm-12">
										<input type="text" class="form-control" name="country" placeholder="Country">
										
									</div>
								</div>
								<div class="form-group row">
									<label class="col-form-label col-lg-3 col-sm-12">Address</label>
									<div class="col-lg-9 col-md-9 col-sm-12">
										<input type="text" class="form-control" name="address" placeholder="Address">
										
									</div>
								</div>
								<div class="form-group row">
									<label class="col-form-label col-lg-3 col-sm-12">Birthday</label>
									<div class="col-lg-9 col-md-9 col-sm-12">
										<div class="input-group date">
											<input type="text" class="form-control kt_datepicker_2" readonly placeholder="Select date" name="birthday">
											<div class="input-group-append">
												<span class="input-group-text">
													<i class="la la-calendar-check-o"></i>
												</span>
											</div>
											
										</div>
									</div>
								</div>
								<div class="form-group row">
									<label class="col-form-label col-lg-3 col-sm-12">Gender</label>
									<div class="col-lg-9 col-md-9 col-sm-12 form-group-sub">
										<select class="form-control kt-select2" name="gender">
											<option value="Male">Male</option>
											<option value="Female">Female</option>
										</select>
										
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="kt-portlet__foot kt-align-right">
						<button type="submit" class="btn btn-sm btn-label-success btn-bold btn-upper">Register</button>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>

<script type="text/javascript">

	jQuery(document).ready(function() {   

		$('.kt-select2').select2({
			placeholder: "Select a state"
		});

		$('.kt_datepicker_2').datepicker({
			todayHighlight: true,
			orientation: "bottom left",
			templates: {
				leftArrow: '<i class="la la-angle-left"></i>',
				rightArrow: '<i class="la la-angle-right"></i>'
			}
		});

		$( "#register_form" ).validate({
			rules: {

				sponsor_ID : {
					required: true
				},
				placement_ID : {
					required: true
				},
				placement : {
					required: true
				},
				pin1 : {
					required: true
				},
				pin2 : {
					required: true
				},
				username : {
					required: true
				},
				password : {
					required: true,
					minlength: 6
				},
				confirm_password : {
					required: true,
					minlength: 6,
					equalTo : "#password"
				},
				firstname : {
					required: true
				},
				middlename : {
					required: true
				},
				lastname : {
					required: true
				},
				mobile_number : {
					required: true
				},
				email_address : {
					required: true,
					email: true
				},
				country : {
					required: true
				},
				address : {
					required: true
				},
				birthday : {
					required: true
				},
				gender : {
					required: true
				}
			},
			
			invalidHandler: function(event, validator) {     
				swal.fire("Error!", "Oh snap! Change a few things up and try submitting again.", "warning");
			},

			submitHandler: function (form) {
				$.ajax({
					type: 'POST',
					url: '<?php echo base_url();?>Account/register_new_account',
					data: $('#register_form').serialize(),
					success: function(data) 
					{
						if(data == 'Success') {
							swal.fire("Success!", "Account Registered!", "success");
						} else {
							swal.fire("Error!", data, "error");
						}
					}
				});
			}
		});
	});
</script>