<div class="kt-container  kt-container--fluid  kt-grid__item kt-grid__item--fluid">
	<div class="row">
		<div class="col-md-6">
			<div class="kt-portlet kt-portlet--mobile kt-portlet--height-fluid-">
				<div class="kt-portlet__head kt-portlet__head--lg">
					<div class="kt-portlet__head-label">
						<h3 class="kt-portlet__head-title">
							Reset Your Password
						</h3>
					</div>
				</div>
				<form class="form-horizontal" id="update_form" action="<?php echo base_url('Account/update_password'); ?>" method="post">
					<div class="kt-portlet__body">
						<input type="hidden" name="account_id" value="<?php echo $this->session->userdata()['user_id']; ?>">
						<div class="form-group">
							<label for="password" class="col-sm-3 control-label">Current Password</label>
							<input type="password" class="form-control" id="password" name="password" required>
						</div>
						<div class="form-group">
							<label for="new_password" class="col-sm-3 control-label">New Password</label>
							<input type="password" class="form-control" id="new_password" name="new_password" required>
						</div>
						<div class="form-group">
							<label for="confirm_password" class="col-sm-3 control-label">Retype Password</label>
							<input type="password" class="form-control" id="confirm_password" name="confirm_password" data-rule-equalTo="#new_password" required>
						</div>
					</div>
					<div class="kt-portlet__foot kt-align-right">
						<button type="submit" class="btn btn-label-success btn-upper btn-bold">Update Password</button>
					</div>
				</form>
			</div>
		</div>

		<?php if($this->session->userdata()['user_id'] == "0000001") {?>
			<div class="col-md-6">
				<div class="kt-portlet kt-portlet--mobile kt-portlet--height-fluid-">
					<div class="kt-portlet__head kt-portlet__head--lg">
						<div class="kt-portlet__head-label">
							<h3 class="kt-portlet__head-title">
								Reset Member's Password
							</h3>
						</div>
					</div>
					<form class="form-horizontal" id="update_member_form" action="<?php echo base_url('Account/update_member_password'); ?>" method="post">
						<div class="kt-portlet__body">
							<div class="form-group">
								<label for="account_id" class="col-sm-3 control-label">Account ID</label>
								<input type="number" class="form-control" name="account_id" required>
							</div>
							<div class="form-group">
								<label for="new_password1" class="col-sm-3 control-label">New Password</label>
								<input type="password" class="form-control" id="new_password1" name="new_password" required>
							</div>
							<div class="form-group">
								<label for="confirm_password1" class="col-sm-3 control-label">Retype Password</label>
								<input type="password" class="form-control" id="confirm_password1" name="confirm_password1" data-rule-equalTo="#new_password1" required>
							</div>
						</div>
						<div class="kt-portlet__foot kt-align-right">
							<button type="submit" class="btn btn-label-success btn-upper btn-bold">Update Member's Password</button>
						</div>
					</form>
				<?php } ?>
			</div>
		</div>
	</div>
</div>

<script type="text/javascript">

	$(document).ready(function(){
		<?php if($message) echo "toastr.warning('". $message ."');"; ?>

		$('#update_form').validate({
	        rules : {
	            new_password : {
	                minlength : 5
	            },
	            confirm_password : {
	                minlength : 5,
	                equalTo : "#new_password"
	            }
	        }
	    });
		$('#update_member_form').validate({
	        rules : {
	            new_password : {
	                minlength : 5
	            },
	            confirm_password1 : {
	                minlength : 5,
	                equalTo : "#new_password1"
	            }
	        }
	    });
	});
</script>