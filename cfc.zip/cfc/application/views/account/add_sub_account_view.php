<section class="content">
	<div class="register-box-body col-md-6" style="float: none; ">
		<div class="alert alert-warning alert-dismissible" hidden>
			<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
			<h4><i class="icon fa fa-warning"></i> Alert!</h4>
			<p id="message"></p>
		</div>
		<form id="sub_register_form" class="form-horizontal" id="register_form" method="post">
			<div class="box-body">
				<div >
					<div class="form-group">
						<label for="password" class="col-sm-3 control-label">Password</label>
						<div class="col-sm-9">
							<input type="password" class="form-control" id="password" name="password" autocomplete="off" required="" value="<?php echo get_account_details($this->session->userdata()['user_id'])->password; ?>" >
						</div>
					</div>
					<div class="form-group">
						<label for="placement_ID" class="col-sm-3 control-label">Placement ID</label>
						<div class="col-sm-9">
							<input type="text" class="form-control" id="placement_ID" name="placement_ID" required="">
						</div>
					</div>
					<div class="form-group">
						<label for="placement" class="col-sm-3 control-label">Placement</label>
						<div class="col-sm-5">
							<select class="form-control selectpicker" tabindex="-1" name="placement" required>
								<option>Left</option>
								<option>Right</option>
							</select>
						</div>
					</div>
					<div class="form-group">
						<label for="pin1" class="col-sm-3 control-label">PIN1</label>
						<div class="col-sm-5">
						<input type="text" class="form-control" id="pin1" name="pin1" required="">
						</div>
					</div>
					<div class="form-group">
						<label for="pin2" class="col-sm-3 control-label">PIN2</label>
						<div class="col-sm-5">
							<input type="text" class="form-control" id="pin2" name="pin2" required="">
						</div>
					</div>

					<div class="form-group" hidden>
                        <input type="text" class="form-control" id="username" name="username" value="<?php echo get_account_details(get_main_account_id($this->session->userdata()['user_id']))->username . '-' . get_sub_account_id($this->session->userdata()['user_id']); ?>" autocomplete="off">
					</div>
					<div class="form-group" hidden>
						<input type="text" class="form-control" id="sponsor_ID" name="sponsor_ID" required="" value="<?php echo $this->session->userdata()['user_id']; ?>">
                    </div>
					<div class="form-group" hidden>
                        <input type="text" class="form-control" id="firstname" name="firstname" placeholder="First Name" value="<?php echo get_account_details($this->session->userdata()['user_id'])->first_name; ?>" hidden>
                    </div>
                    <div class="form-group" hidden>
                        <input type="text" class="form-control" id="lastname" name="lastname" placeholder="Last Name" value="<?php echo get_account_details($this->session->userdata()['user_id'])->last_name; ?>" hidden>
                    </div>
                    <div class="form-group" hidden>
                        <input type="email" class="form-control" id="email_address" name="email_address" placeholder="Email Address" value="<?php echo get_account_details($this->session->userdata()['user_id'])->email_address; ?>" hidden>
                    </div>
                    <div class="form-group" hidden>
                        <input type="text" class="form-control" id="mobile_number" name="mobile_number" placeholder="Mobile Number" value="<?php echo get_account_details($this->session->userdata()['user_id'])->mobile_number; ?>" hidden minlength="11" maxlength="11">
                    </div>
				</div>

				<div hidden>
					<div class="form-group">
                        <input type="text" class="form-control" id="country" name="country" value="<?php echo get_account_details($this->session->userdata()['user_id'])->country; ?>" placeholder="Country">
                    </div>
                    <div class="form-group">
                        <input type="text" class="form-control" id="Address" name="address" value="<?php echo get_account_details($this->session->userdata()['user_id'])->address; ?>" placeholder="Address">
                    </div>
					<div class="form-group">
						<label for="birthday" class="col-sm-3 control-label">Birthday</label>
						<div class="date col-sm-9">
                            <input type="text" class="form-control pull-right" id="datepicker" name="birthday" value="<?php echo get_account_details($this->session->userdata()['user_id'])->birthday; ?>" placeholder="Birthday">
						</div>
					</div>
					<div class="form-group">
						<label for="gender" class="col-sm-3 control-label">Gender</label>
						<div class="col-sm-5">
							<select class="form-control selectpicker" tabindex="-1" name="gender">
								<option value="Male" <?php echo (get_account_details($this->session->userdata()['user_id'])->gender == 'Male')? 'selected' : null; ?>>Male</option>
                            	<option value="Female" <?php echo (get_account_details($this->session->userdata()['user_id'])->gender == 'Female')? 'selected' : null; ?>>Female</option>
							</select>
						</div>
					</div>
                	<input type="hidden" class="form-control" name="sub_account_flag" value="Y">
				</div>
			</div>
			<div class="box-footer">
				<div class="col-md-6" style="float: none; margin: 0 auto; ">
					<button type="button" class="btn btn-danger btn-block btn-flat" id="btn_register">Add Account</button>
				</div>
			</div>
		</form>
	</div>
</section>
<script type="text/javascript">
	$(document).ready(function(){
		$('#datepicker').datepicker({
			autoclose: true,
			format: 'yyyy-mm-dd'
		});
		$('body').on('click','#btn_register', function(){
			$.ajax({
                type: 'POST',
                url: '<?php echo base_url();?>Account/register_account',
                data: $('#sub_register_form').serialize(),
                success: function(data) 
                {
                    if (data.search("Success") != -1) {
                    	$(".alert").attr("hidden",false);
                        $('#message').text(data);
                        $("html, body").animate({ scrollTop: 0 }, "slow");
                    	window.location.replace('<?php echo base_url('dashboard');?>');
                    } else {
                        $(".alert").attr("hidden",false);
                        $('#message').text(data);
                        $("html, body").animate({ scrollTop: 0 }, "slow");
                    }
                }
            });
		});
	});
</script>