<footer class="main-footer">
	<strong>&copy; 2019. <a href="<?php echo base_url('dashboard');?>"> &nbsp; CFC Team.</a></strong> &nbsp;  All rights reserved.
</footer>