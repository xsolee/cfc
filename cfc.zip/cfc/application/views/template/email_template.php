<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <style type="text/css">
        .btn {
        box-sizing: border-box;
        width: 100%; }
        .btn > tbody > tr > td {
          padding-bottom: 15px; }
        .btn table {
          width: auto; }
        .btn table td {
          background-color: #ffffff;
          border-radius: 5px;
          text-align: center; }
        .btn a {
          background-color: #ffffff;
          border: solid 1px #dd4b39;
          border-radius: 5px;
          box-sizing: border-box;
          color: #dd4b39;
          cursor: pointer;
          display: inline-block;
          font-size: 14px;
          font-weight: bold;
          margin: 0;
          padding: 12px 25px;
          text-decoration: none;
          text-transform: capitalize; }

      .btn-primary table td {
        background-color: #dd4b39; }

      .btn-primary a {
        background-color: #dd4b39;
        border-color: #dd4b39;
        color: #ffffff; }
    </style>
</head>
    <body style=" margin: 0;padding: 0;background-color: #ecf0f5;">
        <table cellspacing="0" cellpadding="0" border="0" style="width:100%;background-color: #ecf0f5;font-family: arial,sans-serif;color: #333;border-collapse: collapse; ">
            <tbody>
                <tr>
                    <td width="375"></td>
                    <td width="375"></td>
                </tr>
                <tr>
                    <td align="center" valign="top" style="padding:30px 0;" colspan="2">
                        <!-- <h1 style="color: red;">NOTICE: <small>This is a <u>TEST EMAIL</u> only</small></h1> -->
                        <table style="font-family: arial,sans-serif;margin-left: auto;margin-right: auto;width: 544px;border-collapse: collapse; border-top: 4px solid #DD4B39; border-bottom: 0px none; border-left: 0px none; border-right: 0px none;" border="0" cellpadding="0" cellspacing="0" width="544">
                            <tbody>
                                <tr>
                                    <td style="background-color: #ffffff;padding: 15px;">
                                        <h1 style="text-align: center;font-size: 18px;">
                                            <span><?php echo $message; ?></span>
                                        </h1>
                                        <!-- <p align="center" style="">Click Attached file to download CWT</p> -->
                                    </td>
                                </tr>
                                <tr>
                                    <td class="bottomCorners">
                                        <table border="0" cellpadding="0" cellspacing="0" width="100%">
                                            <tbody>
                                                <tr>
                                                    <td>&nbsp;</td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="font-size: 12px;text-align: center;">Copyright &copy; <?php echo date('Y'); ?> CFC Team. All Rights Reserved.<br>
                                        <p>CFC Team Portal</p>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="font-size: 12px;text-align: center;">
                                        <hr>
                                        This is a system generated message, please do not reply.
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
            </tbody>
        </table>
    </body>
</html>