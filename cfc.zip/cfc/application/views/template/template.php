<?php if ( ! $this->session->userdata('user_id')) {redirect('account/login'); }?>
<!DOCTYPE html>

<html lang="en">

	<head>

		<base href="../../../">

		<!--end::Base Path -->
		<meta charset="utf-8" />
		<title>CFC Team</title>
		<meta name="description" content="Base portlet examples">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">



  		<script src="https://ajax.googleapis.com/ajax/libs/webfont/1.6.16/webfont.js"></script>
		<script>
			WebFont.load({
				google: {
					"families": ["Poppins:300,400,500,600,700", "Roboto:300,400,500,600,700"]
				},
				active: function() {
					sessionStorage.fonts = true;
				}
			});
		</script>

		<!--end::Fonts -->

		<!--begin:: Global Mandatory Vendors -->
		<link rel="stylesheet" type="text/css" href="<?php echo base_url('resources/metronic/vendors/general/perfect-scrollbar/css/perfect-scrollbar.css');?>">
		<!--end:: Global Mandatory Vendors -->

		<!--begin:: Global Optional Vendors -->
		<link rel="stylesheet" type="text/css" href="<?php echo base_url('resources/metronic/vendors/general/tether/dist/css/tether.css');?>">
		<link rel="stylesheet" type="text/css" href="<?php echo base_url('resources/metronic/vendors/general/bootstrap-datepicker/dist/css/bootstrap-datepicker3.css');?>">
		<link rel="stylesheet" type="text/css" href="<?php echo base_url('resources/metronic/vendors/general/bootstrap-datetime-picker/css/bootstrap-datetimepicker.css');?>">
		<link rel="stylesheet" type="text/css" href="<?php echo base_url('resources/metronic/vendors/general/bootstrap-timepicker/css/bootstrap-timepicker.css');?>">
		<link rel="stylesheet" type="text/css" href="<?php echo base_url('resources/metronic/vendors/general/bootstrap-daterangepicker/daterangepicker.css');?>">
		<link rel="stylesheet" type="text/css" href="<?php echo base_url('resources/metronic/vendors/general/bootstrap-touchspin/dist/jquery.bootstrap-touchspin.css');?>">
		<link rel="stylesheet" type="text/css" href="<?php echo base_url('resources/metronic/vendors/general/bootstrap-select/dist/css/bootstrap-select.css');?>">
		<link rel="stylesheet" type="text/css" href="<?php echo base_url('resources/metronic/vendors/general/bootstrap-switch/dist/css/bootstrap3/bootstrap-switch.css');?>">
		<link rel="stylesheet" type="text/css" href="<?php echo base_url('resources/metronic/vendors/general/select2/dist/css/select2.css');?>">
		<link rel="stylesheet" type="text/css" href="<?php echo base_url('resources/metronic/vendors/general/ion-rangeslider/css/ion.rangeSlider.css');?>">
		<link rel="stylesheet" type="text/css" href="<?php echo base_url('resources/metronic/vendors/general/nouislider/distribute/nouislider.css');?>">
		<link rel="stylesheet" type="text/css" href="<?php echo base_url('resources/metronic/vendors/general/owl.carousel/dist/assets/owl.carousel.css');?>">
		<link rel="stylesheet" type="text/css" href="<?php echo base_url('resources/metronic/vendors/general/owl.carousel/dist/assets/owl.theme.default.css');?>">
		<link rel="stylesheet" type="text/css" href="<?php echo base_url('resources/metronic/vendors/general/dropzone/dist/dropzone.css');?>">
		<link rel="stylesheet" type="text/css" href="<?php echo base_url('resources/metronic/vendors/general/summernote/dist/summernote.css');?>">
		<link rel="stylesheet" type="text/css" href="<?php echo base_url('resources/metronic/vendors/general/bootstrap-markdown/css/bootstrap-markdown.min.css');?>">
		<link rel="stylesheet" type="text/css" href="<?php echo base_url('resources/metronic/vendors/general/animate.css/animate.css');?>">
		<link rel="stylesheet" type="text/css" href="<?php echo base_url('resources/metronic/vendors/general/toastr/build/toastr.css');?>">
		<link rel="stylesheet" type="text/css" href="<?php echo base_url('resources/metronic/vendors/general/morris.js/morris.css');?>">
		<link rel="stylesheet" type="text/css" href="<?php echo base_url('resources/metronic/vendors/general/sweetalert2/dist/sweetalert2.css');?>">
		<link rel="stylesheet" type="text/css" href="<?php echo base_url('resources/metronic/vendors/general/socicon/css/socicon.css');?>">
		<link rel="stylesheet" type="text/css" href="<?php echo base_url('resources/metronic/vendors/custom/vendors/line-awesome/css/line-awesome.css');?>">
		<link rel="stylesheet" type="text/css" href="<?php echo base_url('resources/metronic/vendors/custom/vendors/flaticon/flaticon.css');?>">
		<link rel="stylesheet" type="text/css" href="<?php echo base_url('resources/metronic/vendors/custom/vendors/flaticon2/flaticon.css');?>">
		<link rel="stylesheet" type="text/css" href="<?php echo base_url('resources/metronic/vendors/general/@fortawesome/fontawesome-free/css/all.min.css');?>">

		<!--end:: Global Optional Vendors -->

		<link href="<?php echo base_url('resources/metronic/vendors/custom/datatables/datatables.bundle.min.css'); ?>" rel="stylesheet" type="text/css" />
		<link href="<?php echo base_url('resources/metronic/vendors/custom/jstree/jstree.bundle.css'); ?>" rel="stylesheet" type="text/css" />

		<!--begin::Global Theme Styles(used by all pages) -->
		<!-- <link rel="stylesheet" type="text/css" href="<?php echo base_url('resources/metronic/css/demo3/style.bundle.css');?>"> -->

		<link rel="stylesheet" type="text/css" href="<?php echo base_url('resources/metronic/css/demo6/style.bundle.css');?>">

		<!--end::Global Theme Styles -->

		<!--begin::Layout Skins(used by all pages) -->
		<!-- <link rel="stylesheet" type="text/css" href="<?php echo base_url('resources/metronic/css/demo1/skins/header/base/light.css');?>">
		<link rel="stylesheet" type="text/css" href="<?php echo base_url('resources/metronic/css/demo1/skins/header/menu/light.css');?>">
		<link rel="stylesheet" type="text/css" href="<?php echo base_url('resources/metronic/css/demo1/skins/brand/dark.css');?>">
		<link rel="stylesheet" type="text/css" href="<?php echo base_url('resources/metronic/css/demo1/skins/aside/dark.css');?>"> -->

		<!--end::Layout Skins -->
		<link rel="shortcut icon" href="<?php echo base_url('resources/images/favicon.ico');?>">
		<link rel="stylesheet" type="text/css" href="<?php echo base_url('resources/css/custom.css');?>">
		<!--start:: Global Mandatory Vendors -->
		<script src="<?php echo base_url('resources/metronic/vendors/general/jquery/dist/jquery.js')?>" type="text/javascript"></script>
		<script src="<?php echo base_url('resources/metronic/vendors/general/popper.js/dist/umd/popper.js')?>" type="text/javascript"></script>
		<script src="<?php echo base_url('resources/metronic/vendors/general/bootstrap/dist/js/bootstrap.min.js')?>" type="text/javascript"></script>
		<script src="<?php echo base_url('resources/metronic/vendors/general/js-cookie/src/js.cookie.js')?>" type="text/javascript"></script>
		<script src="<?php echo base_url('resources/metronic/vendors/general/moment/min/moment.min.js')?>" type="text/javascript"></script>
		<script src="<?php echo base_url('resources/metronic/vendors/general/tooltip.js/dist/umd/tooltip.min.js')?>" type="text/javascript"></script>
		<script src="<?php echo base_url('resources/metronic/vendors/general/perfect-scrollbar/dist/perfect-scrollbar.js')?>" type="text/javascript"></script>
		<script src="<?php echo base_url('resources/metronic/vendors/general/sticky-js/dist/sticky.min.js')?>" type="text/javascript"></script>
		<script src="<?php echo base_url('resources/metronic/vendors/general/wnumb/wNumb.js')?>" type="text/javascript"></script>
		<!--end:: Global Mandatory Vendors -->

		<!--begin:: Global Optional Vendors -->
		<script src="<?php echo base_url('resources/metronic/vendors/general/jquery-form/dist/jquery.form.min.js');?>" type="text/javascript"></script>
		<script src="<?php echo base_url('resources/metronic/vendors/general/block-ui/jquery.blockUI.js');?>" type="text/javascript"></script>
		<script src="<?php echo base_url('resources/metronic/vendors/general/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js');?>" type="text/javascript"></script>
		<script src="<?php echo base_url('resources/metronic/vendors/custom/js/vendors/bootstrap-datepicker.init.js');?>" type="text/javascript"></script>
		<script src="<?php echo base_url('resources/metronic/vendors/general/bootstrap-datetime-picker/js/bootstrap-datetimepicker.min.js');?>" type="text/javascript"></script>
		<script src="<?php echo base_url('resources/metronic/vendors/general/bootstrap-timepicker/js/bootstrap-timepicker.min.js');?>" type="text/javascript"></script>
		<script src="<?php echo base_url('resources/metronic/vendors/custom/js/vendors/bootstrap-timepicker.init.js');?>" type="text/javascript"></script>
		<script src="<?php echo base_url('resources/metronic/vendors/general/bootstrap-daterangepicker/daterangepicker.js');?>" type="text/javascript"></script>
		<script src="<?php echo base_url('resources/metronic/vendors/general/bootstrap-touchspin/dist/jquery.bootstrap-touchspin.js');?>" type="text/javascript"></script>
		<script src="<?php echo base_url('resources/metronic/vendors/general/bootstrap-maxlength/src/bootstrap-maxlength.js');?>" type="text/javascript"></script>
		<script src="<?php echo base_url('resources/metronic/vendors/custom/vendors/bootstrap-multiselectsplitter/bootstrap-multiselectsplitter.min.js');?>" type="text/javascript"></script>
		<script src="<?php echo base_url('resources/metronic/vendors/general/bootstrap-select/dist/js/bootstrap-select.js');?>" type="text/javascript"></script>
		<script src="<?php echo base_url('resources/metronic/vendors/general/bootstrap-switch/dist/js/bootstrap-switch.js');?>" type="text/javascript"></script>
		<script src="<?php echo base_url('resources/metronic/vendors/custom/js/vendors/bootstrap-switch.init.js');?>" type="text/javascript"></script>
		<script src="<?php echo base_url('resources/metronic/vendors/general/select2/dist/js/select2.full.js');?>" type="text/javascript"></script>
		<script src="<?php echo base_url('resources/metronic/vendors/general/ion-rangeslider/js/ion.rangeSlider.js');?>" type="text/javascript"></script>
		<script src="<?php echo base_url('resources/metronic/vendors/general/typeahead.js/dist/typeahead.bundle.js');?>" type="text/javascript"></script>
		<script src="<?php echo base_url('resources/metronic/vendors/general/handlebars/dist/handlebars.js');?>" type="text/javascript"></script>
		<script src="<?php echo base_url('resources/metronic/vendors/general/inputmask/dist/jquery.inputmask.bundle.js');?>" type="text/javascript"></script>
		<script src="<?php echo base_url('resources/metronic/vendors/general/inputmask/dist/inputmask/inputmask.date.extensions.js');?>" type="text/javascript"></script>
		<script src="<?php echo base_url('resources/metronic/vendors/general/inputmask/dist/inputmask/inputmask.numeric.extensions.js');?>" type="text/javascript"></script>
		<script src="<?php echo base_url('resources/metronic/vendors/general/nouislider/distribute/nouislider.js');?>" type="text/javascript"></script>
		<script src="<?php echo base_url('resources/metronic/vendors/general/owl.carousel/dist/owl.carousel.js');?>" type="text/javascript"></script>
		<script src="<?php echo base_url('resources/metronic/vendors/general/autosize/dist/autosize.js');?>" type="text/javascript"></script>
		<script src="<?php echo base_url('resources/metronic/vendors/general/clipboard/dist/clipboard.min.js');?>" type="text/javascript"></script>
		<script src="<?php echo base_url('resources/metronic/vendors/general/dropzone/dist/dropzone.js');?>" type="text/javascript"></script>
		<script src="<?php echo base_url('resources/metronic/vendors/general/summernote/dist/summernote.js');?>" type="text/javascript"></script>
		<script src="<?php echo base_url('resources/metronic/vendors/general/markdown/lib/markdown.js');?>" type="text/javascript"></script>
		<script src="<?php echo base_url('resources/metronic/vendors/general/bootstrap-markdown/js/bootstrap-markdown.js');?>" type="text/javascript"></script>
		<script src="<?php echo base_url('resources/metronic/vendors/custom/js/vendors/bootstrap-markdown.init.js');?>" type="text/javascript"></script>
		<script src="<?php echo base_url('resources/metronic/vendors/general/bootstrap-notify/bootstrap-notify.min.js');?>" type="text/javascript"></script>
		<script src="<?php echo base_url('resources/metronic/vendors/custom/js/vendors/bootstrap-notify.init.js');?>" type="text/javascript"></script>
		<script src="<?php echo base_url('resources/metronic/vendors/general/jquery-validation/dist/jquery.validate.js');?>" type="text/javascript"></script>
		<script src="<?php echo base_url('resources/metronic/vendors/general/jquery-validation/dist/additional-methods.js');?>" type="text/javascript"></script>
		<script src="<?php echo base_url('resources/metronic/vendors/custom/js/vendors/jquery-validation.init.js');?>" type="text/javascript"></script>
		<script src="<?php echo base_url('resources/metronic/vendors/general/toastr/build/toastr.min.js');?>" type="text/javascript"></script>
		<script src="<?php echo base_url('resources/metronic/vendors/general/raphael/raphael.js');?>" type="text/javascript"></script>
		<script src="<?php echo base_url('resources/metronic/vendors/general/morris.js/morris.js');?>" type="text/javascript"></script>
		<script src="<?php echo base_url('resources/metronic/vendors/general/chart.js/dist/Chart.bundle.js');?>" type="text/javascript"></script>
		<script src="<?php echo base_url('resources/metronic/vendors/custom/vendors/bootstrap-session-timeout/dist/bootstrap-session-timeout.min.js');?>" type="text/javascript"></script>
		<script src="<?php echo base_url('resources/metronic/vendors/custom/vendors/jquery-idletimer/idle-timer.min.js');?>" type="text/javascript"></script>
		<script src="<?php echo base_url('resources/metronic/vendors/general/waypoints/lib/jquery.waypoints.js');?>" type="text/javascript"></script>
		<script src="<?php echo base_url('resources/metronic/vendors/general/counterup/jquery.counterup.js');?>" type="text/javascript"></script>
		<script src="<?php echo base_url('resources/metronic/vendors/general/es6-promise-polyfill/promise.min.js');?>" type="text/javascript"></script>
		<script src="<?php echo base_url('resources/metronic/vendors/general/sweetalert2/dist/sweetalert2.min.js');?>" type="text/javascript"></script>
		<script src="<?php echo base_url('resources/metronic/vendors/custom/js/vendors/sweetalert2.init.js');?>" type="text/javascript"></script>
		<script src="<?php echo base_url('resources/metronic/vendors/general/jquery.repeater/src/lib.js');?>" type="text/javascript"></script>
		<script src="<?php echo base_url('resources/metronic/vendors/general/jquery.repeater/src/jquery.input.js');?>" type="text/javascript"></script>
		<script src="<?php echo base_url('resources/metronic/vendors/general/jquery.repeater/src/repeater.js');?>" type="text/javascript"></script>
		<script src="<?php echo base_url('resources/metronic/vendors/general/dompurify/dist/purify.js');?>" type="text/javascript"></script>
		<!--end:: Global Optional Vendors -->

		

		<!--begin::Global Theme Bundle(used by all pages) -->
		<!-- <script src="<?php echo base_url('resources/metronic/js/demo1/scripts.bundle.js');?>" type="text/javascript"></script> -->
		<script src="<?php echo base_url('resources/metronic/js/demo6/scripts.bundle.js');?>" type="text/javascript"></script>
		<script src="<?php echo base_url('resources/metronic/vendors/custom/datatables/datatables.bundle.min.js'); ?>" type="text/javascript"></script>
		<script src="<?php echo base_url('resources/metronic/vendors/custom/jstree/jstree.bundle.js'); ?>" type="text/javascript"></script>

	</head>

	<body class="kt-quick-panel--right kt-demo-panel--right kt-offcanvas-panel--right kt-header--fixed kt-header-mobile--fixed kt-subheader--enabled kt-subheader--solid kt-aside--enabled kt-aside--fixed kt-aside--minimize kt-page--loading">


		<div id="kt_header_mobile" class="kt-header-mobile  kt-header-mobile--fixed ">
			<div class="kt-header-mobile__logo">
				<a>
					<img alt="Logo" src="<?php echo base_url('resources/images/logo100x100.png');?>" style="width: 40px; ">
				</a>
			</div>
			<div class="kt-header-mobile__toolbar">
				<div class="kt-header-mobile__toolbar-toggler kt-header-mobile__toolbar-toggler--left" id="kt_aside_mobile_toggler"><span></span></div>
				<!-- <div class="kt-header-mobile__toolbar-toggler" id="kt_header_mobile_toggler"><span></span></div> -->
				<div class="kt-header-mobile__toolbar-topbar-toggler" id="kt_header_mobile_topbar_toggler"><i class="flaticon-more"></i></div>
			</div>
		</div>

		<div class="kt-grid kt-grid--hor kt-grid--root">
			<div class="kt-grid__item kt-grid__item--fluid kt-grid kt-grid--ver kt-page">
        
				<?php $this->load->view('template/sidebar_menu'); ?>

				<div class="kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor kt-wrapper" id="kt_wrapper">

					<?php $this->load->view('template/header'); ?>
					
					<div class="kt-content  kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor kt-margin-t-30" id="kt_content">
   						
							<?php $this->load->view($content); ?>
						
					</div>
					<div class="kt-footer  kt-grid__item kt-grid kt-grid--desktop kt-grid--ver-desktop" id="kt_footer">
						<div class="kt-container  kt-container--fluid ">
							<div class="kt-footer__copyright">
								2019&nbsp;&copy;&nbsp;<a href="<?php echo base_url('dashboard');?>"> &nbsp; CFC Team</a></strong> &nbsp;  All rights reserved.
							</div>
							<!-- <div class="kt-footer__menu">
								<a href="http://keenthemes.com/metronic" target="_blank" class="kt-footer__menu-link kt-link">About</a>
								<a href="http://keenthemes.com/metronic" target="_blank" class="kt-footer__menu-link kt-link">Team</a>
								<a href="http://keenthemes.com/metronic" target="_blank" class="kt-footer__menu-link kt-link">Contact</a>
							</div> -->
						</div>
					</div>
				</div>
			</div>
		</div>

		<script>
			var KTAppOptions = {
				"colors": {
					"state": {
						"brand": "#5d78ff",
						"dark": "#282a3c",
						"light": "#ffffff",
						"primary": "#5867dd",
						"success": "#34bfa3",
						"info": "#36a3f7",
						"warning": "#ffb822",
						"danger": "#fd3995"
					},
					"base": {
						"label": ["#c5cbe3", "#a1a8c3", "#3d4465", "#3e4466"],
						"shape": ["#f0f3ff", "#d9dffa", "#afb4d4", "#646c9a"]
					}
				}
			};
		</script>
		
	</body>

</html>



