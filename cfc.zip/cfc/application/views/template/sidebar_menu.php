<button class="kt-aside-close " id="kt_aside_close_btn"><i class="la la-close"></i></button>
<div class="kt-aside  kt-aside--fixed  kt-grid__item kt-grid kt-grid--desktop kt-grid--hor-desktop" id="kt_aside">
	<div class="kt-aside-menu-wrapper kt-grid__item kt-grid__item--fluid" id="kt_aside_menu_wrapper">
		<div id="kt_aside_menu" class="kt-aside-menu " data-ktmenu-vertical="1" data-ktmenu-scroll="1" data-ktmenu-dropdown-timeout="500">
			<ul class="kt-menu__nav ">
				<li class="kt-menu__item  <?php echo ($this->uri->uri_string() == 'dashboard') ? 'kt-menu__item--active' : ''; ?>" aria-haspopup="true">
					<a href="<?php echo base_url('dashboard'); ?>" class="kt-menu__link ">
						<i class="kt-menu__link-icon flaticon2-protection"></i>
						<span class="kt-menu__link-text">Dashboard</span>
					</a>
				</li>
				<?php if($this->session->userdata()['activated']) { ?>
					<li class="kt-menu__item  kt-menu__item--submenu <?php echo (in_array($this->uri->uri_string(), array('account/add_account','account/view_accounts'))) ? 'kt-menu__item--active kt-menu__item--open' : ''; ?>" aria-haspopup="true" data-ktmenu-submenu-toggle="hover">
						<a href="javascript:;" class="kt-menu__link kt-menu__toggle">
							<i class="kt-menu__link-icon flaticon-users-1"></i>
							<span class="kt-menu__link-text">Account</span>
							<i class="kt-menu__ver-arrow la la-angle-right"></i>
						</a>
						<div class="kt-menu__submenu ">
							<span class="kt-menu__arrow"></span>
							<ul class="kt-menu__subnav">
								<?php if($this->session->userdata()['user_id'] == "0000001") {?>
									<li class="kt-menu__item <?php echo ($this->uri->uri_string() == 'account/view_accounts')? 'kt-menu__item--active' : ''; ?>" aria-haspopup="true">
										<a href="<?php echo base_url('account/view_accounts'); ?>" class="kt-menu__link ">
											<i class="kt-menu__link-bullet kt-menu__link-bullet--dot">
												<span></span>
											</i>
											<span class="kt-menu__link-text">All Accounts</span>
										</a>
									</li>
								<?php } ?>
								<li class="kt-menu__item <?php echo ($this->uri->uri_string() == 'account/add_account')? 'kt-menu__item--active' : ''; ?>" aria-haspopup="true">
									<a href="<?php echo base_url('account/add_account'); ?>" class="kt-menu__link ">
										<i class="kt-menu__link-bullet kt-menu__link-bullet--dot">
											<span></span>
										</i>
										<span class="kt-menu__link-text">New Account</span>
									</a>
								</li>
							</ul>
						</div>
					</li>
				<?php } ?>
				<li class="kt-menu__item  kt-menu__item--submenu <?php echo (in_array($this->uri->uri_string(), array('network/genealogy_list','network/genealogy_tree','network/direct_referrals'))) ? 'kt-menu__item--active kt-menu__item--open' : ''; ?>" aria-haspopup="true" data-ktmenu-submenu-toggle="hover">
					<a href="javascript:;" class="kt-menu__link kt-menu__toggle">
						<i class="kt-menu__link-icon flaticon-network"></i>
						<span class="kt-menu__link-text">Network</span>
						<i class="kt-menu__ver-arrow la la-angle-right"></i>
					</a>
					<div class="kt-menu__submenu ">
						<span class="kt-menu__arrow"></span>
						<ul class="kt-menu__subnav">
							<li class="kt-menu__item <?php echo ($this->uri->uri_string() == 'network/genealogy_list')? 'kt-menu__item--active' : ''; ?>" aria-haspopup="true">
								<a href="<?php echo base_url('network/genealogy_list'); ?>" class="kt-menu__link ">
									<i class="kt-menu__link-bullet kt-menu__link-bullet--dot">
										<span></span>
									</i>
									<span class="kt-menu__link-text">Genealogy List</span>
								</a>
							</li>
							<li class="kt-menu__item <?php echo ($this->uri->uri_string() == 'network/genealogy_tree')? 'kt-menu__item--active' : ''; ?>" aria-haspopup="true">
								<a href="<?php echo base_url('network/genealogy_tree'); ?>" class="kt-menu__link ">
									<i class="kt-menu__link-bullet kt-menu__link-bullet--dot">
										<span></span>
									</i>
									<span class="kt-menu__link-text">Genealogy Tree</span>
								</a>
							</li>
							<li class="kt-menu__item <?php echo ($this->uri->uri_string() == 'network/direct_referrals')? 'kt-menu__item--active' : ''; ?>" aria-haspopup="true">
								<a href="<?php echo base_url('network/direct_referrals'); ?>" class="kt-menu__link ">
									<i class="kt-menu__link-bullet kt-menu__link-bullet--dot">
										<span></span>
									</i>
									<span class="kt-menu__link-text">Direct Referrals</span>
								</a>
							</li>
						</ul>
					</div>
				</li>
				<li class="kt-menu__item  <?php echo ($this->uri->uri_string() == 'affiliate_shares/investment') ? 'kt-menu__item--active' : ''; ?>" aria-haspopup="true">
					<a href="<?php echo base_url('affiliate_shares/investment'); ?>" class="kt-menu__link ">
						<i class="kt-menu__link-icon flaticon2-chart"></i>
						<span class="kt-menu__link-text">CFC WS Rewards</span>
					</a>
				</li>
				<li class="kt-menu__item  kt-menu__item--submenu <?php echo (in_array($this->uri->uri_string(), array('token_gaming/avail_token','token_gaming/view_games'))) ? 'kt-menu__item--active kt-menu__item--open' : ''; ?>" aria-haspopup="true" data-ktmenu-submenu-toggle="hover">
					<a href="javascript:;" class="kt-menu__link kt-menu__toggle">
						<i class="kt-menu__link-icon flaticon2-cup"></i>
						<span class="kt-menu__link-text">CFC Exclusive</span>
						<i class="kt-menu__ver-arrow la la-angle-right"></i>
					</a>
					<div class="kt-menu__submenu <?php echo ($this->uri->uri_string() == 'token_gaming/avail_token')? 'kt-menu__item--active' : ''; ?>">
						<span class="kt-menu__arrow"></span>
						<ul class="kt-menu__subnav">
							<li class="kt-menu__item <?php echo ($this->uri->uri_string() == 'token_gaming/avail_token')? 'kt-menu__item--active' : ''; ?>" aria-haspopup="true">
								<a href="<?php echo base_url('token_gaming/avail_token'); ?>" class="kt-menu__link ">
									<i class="kt-menu__link-bullet kt-menu__link-bullet--dot">
										<span></span>
									</i>
									<span class="kt-menu__link-text">Tokens</span>
								</a>
							</li>
							<?php if($this->session->userdata()['user_id'] == "0000001") {?>
								<li class="kt-menu__item <?php echo ($this->uri->uri_string() == 'token_gaming/view_games')? 'kt-menu__item--active' : ''; ?>" aria-haspopup="true">
									<a href="<?php echo base_url('token_gaming/view_games'); ?>" class="kt-menu__link ">
										<i class="kt-menu__link-bullet kt-menu__link-bullet--dot">
											<span></span>
										</i>
										<span class="kt-menu__link-text">CFC Exclusive</span>
									</a>
								</li>
							<?php } ?>
						</ul>
					</div>
				</li>
				<li class="kt-menu__item  kt-menu__item--submenu <?php echo (in_array($this->uri->uri_string(), array('transaction/encashment','transaction/history','transaction/all_requests','transaction/transfer_rewards','transaction/buy_pincodes'))) ? 'kt-menu__item--active kt-menu__item--open' : ''; ?>" aria-haspopup="true" data-ktmenu-submenu-toggle="hover">
					<a href="javascript:;" class="kt-menu__link kt-menu__toggle">
						<i class="kt-menu__link-icon flaticon2-layers-1"></i>
						<span class="kt-menu__link-text">Transactions</span>
						<i class="kt-menu__ver-arrow la la-angle-right"></i>
					</a>
					<div class="kt-menu__submenu ">
						<span class="kt-menu__arrow"></span>
						<ul class="kt-menu__subnav">
							<li class="kt-menu__item <?php echo ($this->uri->uri_string() == 'transaction/encashment')? 'kt-menu__item--active' : ''; ?>" aria-haspopup="true">
								<a href="<?php echo base_url('transaction/encashment'); ?>" class="kt-menu__link ">
									<i class="kt-menu__link-bullet kt-menu__link-bullet--dot">
										<span></span>
									</i>
									<span class="kt-menu__link-text">Cashback</span>
								</a>
							</li>
							<li class="kt-menu__item <?php echo ($this->uri->uri_string() == 'transaction/history')? 'kt-menu__item--active' : ''; ?>" aria-haspopup="true">
								<a href="<?php echo base_url('transaction/history'); ?>" class="kt-menu__link ">
									<i class="kt-menu__link-bullet kt-menu__link-bullet--dot">
										<span></span>
									</i>
									<span class="kt-menu__link-text">Cashback History</span>
								</a>
							</li>
							<?php if($this->session->userdata()['user_id'] == "0000001") {?>
							<li class="kt-menu__item <?php echo ($this->uri->uri_string() == 'transaction/all_requests')? 'kt-menu__item--active' : ''; ?>" aria-haspopup="true">
								<a href="<?php echo base_url('transaction/all_requests'); ?>" class="kt-menu__link ">
									<i class="kt-menu__link-bullet kt-menu__link-bullet--dot">
										<span></span>
									</i>
									<span class="kt-menu__link-text">All Requests</span>
								</a>
							</li>
							<?php } ?>
							<li class="kt-menu__item <?php echo ($this->uri->uri_string() == 'transaction/transfer_rewards')? 'kt-menu__item--active' : ''; ?>" aria-haspopup="true">
								<a href="<?php echo base_url('transaction/transfer_rewards'); ?>" class="kt-menu__link ">
									<i class="kt-menu__link-bullet kt-menu__link-bullet--dot">
										<span></span>
									</i>
									<span class="kt-menu__link-text">Transfer Rewards</span>
								</a>
							</li>
							<li class="kt-menu__item <?php echo ($this->uri->uri_string() == 'transaction/buy_pincodes')? 'kt-menu__item--active' : ''; ?>" aria-haspopup="true">
								<a href="<?php echo base_url('transaction/buy_pincodes'); ?>" class="kt-menu__link ">
									<i class="kt-menu__link-bullet kt-menu__link-bullet--dot">
										<span></span>
									</i>
									<span class="kt-menu__link-text">Buy/Transfer Pincodes</span>
								</a>
							</li>
						</ul>
					</div>
				</li>
				<?php if($this->session->userdata()['user_id'] == "0000001") {?>
					<li class="kt-menu__item  kt-menu__item--submenu <?php echo (in_array($this->uri->uri_string(), array('pins/generate_pins','pins/generate_affiliate_shares_pin'))) ? 'kt-menu__item--active kt-menu__item--open' : ''; ?>" aria-haspopup="true" data-ktmenu-submenu-toggle="hover">
						<a href="javascript:;" class="kt-menu__link kt-menu__toggle">
							<i class="kt-menu__link-icon flaticon2-lock"></i>
							<span class="kt-menu__link-text">PINS</span>
							<i class="kt-menu__ver-arrow la la-angle-right"></i>
						</a>
						<div class="kt-menu__submenu">
							<span class="kt-menu__arrow"></span>
							<ul class="kt-menu__subnav">
								<li class="kt-menu__item <?php echo ($this->uri->uri_string() == 'pins/generate_pins')? 'kt-menu__item--active' : ''; ?>" aria-haspopup="true">
									<a href="<?php echo base_url('pins/generate_pins'); ?>" class="kt-menu__link ">
										<i class="kt-menu__link-bullet kt-menu__link-bullet--dot">
											<span></span>
										</i>
										<span class="kt-menu__link-text">Accounts PIN</span>
									</a>
								</li>
								<li class="kt-menu__item <?php echo ($this->uri->uri_string() == 'pins/generate_affiliate_shares_pin')? 'kt-menu__item--active' : ''; ?>" aria-haspopup="true">
									<a href="<?php echo base_url('pins/generate_affiliate_shares_pin'); ?>" class="kt-menu__link ">
										<i class="kt-menu__link-bullet kt-menu__link-bullet--dot">
											<span></span>
										</i>
										<span class="kt-menu__link-text">CFC WS PIN</span>
									</a>
								</li>
							</ul>
						</div>
					</li>

					<li class="kt-menu__item  <?php echo ($this->uri->uri_string() == 'dashboard/manage_announcement') ? 'kt-menu__item--active' : ''; ?>" aria-haspopup="true">
						<a href="<?php echo base_url('dashboard/manage_announcement'); ?>" class="kt-menu__link ">
							<i class="kt-menu__link-icon flaticon2-settings"></i>
							<span class="kt-menu__link-text">Manage Announcement</span>
						</a>
					</li>
				<?php } ?>
				<li class="kt-menu__item  kt-menu__item--submenu <?php echo (in_array($this->uri->uri_string(), array('Account/profile','Account/change_password','Bank/banks'))) ? 'kt-menu__item--active kt-menu__item--open' : ''; ?>" aria-haspopup="true" data-ktmenu-submenu-toggle="hover">
					<a href="javascript:;" class="kt-menu__link kt-menu__toggle">
						<i class="kt-menu__link-icon flaticon2-user"></i>
						<span class="kt-menu__link-text">Profile</span>
						<i class="kt-menu__ver-arrow la la-angle-right"></i>
					</a>
					<div class="kt-menu__submenu">
						<span class="kt-menu__arrow"></span>
						<ul class="kt-menu__subnav">
							<li class="kt-menu__item <?php echo ($this->uri->uri_string() == 'Account/profile')? 'kt-menu__item--active' : ''; ?>" aria-haspopup="true">
								<a href="<?php echo base_url('Account/profile'); ?>" class="kt-menu__link ">
									<i class="kt-menu__link-bullet kt-menu__link-bullet--dot">
										<span></span>
									</i>
									<span class="kt-menu__link-text">My Profile</span>
								</a>
							</li>
							<li class="kt-menu__item <?php echo ($this->uri->uri_string() == 'Account/change_password')? 'kt-menu__item--active' : ''; ?>" aria-haspopup="true">
								<a href="<?php echo base_url('Account/change_password'); ?>" class="kt-menu__link ">
									<i class="kt-menu__link-bullet kt-menu__link-bullet--dot">
										<span></span>
									</i>
									<span class="kt-menu__link-text">Change Password</span>
								</a>
							</li>
							<li class="kt-menu__item <?php echo ($this->uri->uri_string() == 'Bank/banks')? 'kt-menu__item--active' : ''; ?>" aria-haspopup="true">
								<a href="<?php echo base_url('Bank/banks'); ?>" class="kt-menu__link ">
									<i class="kt-menu__link-bullet kt-menu__link-bullet--dot">
										<span></span>
									</i>
									<span class="kt-menu__link-text">My Bank</span>
								</a>
							</li>
						</ul>
					</div>
				</li>
			</ul>
		</div>
	</div>
</div>