<div class="kt-container kt-container--fluid kt-grid__item kt-grid__item--fluid">
    <div class="kt-portlet kt-portlet--mobile kt-portlet--height-fluid-">
        <div class="kt-portlet__head kt-portlet__head--lg">
            <div class="kt-portlet__head-label">
                <span class="kt-portlet__head-icon">
                    <i class="kt-font-brand flaticon2-line-chart"></i>
                </span>
                <h3 class="kt-portlet__head-title">
                    Generate Affiliate Shares PIN
                </h3>
            </div>
        </div>
        <div class="kt-portlet__body">
            <form id="generate_pins" method="POST" enctype="multipart/form-data">
                <div class="row">
                    <div class="col-md-3">
                        <div class="form-group">
                            <input type="number" class="form-control" id="no_of_shares" name="no_of_shares" min="0" placeholder="No of Accounts" required>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <button type="submit" class="btn btn-sm btn-label-success btn-bold btn-upper">Export Pins</button>
                        </div>
                    </div>
                </div>
            </form>
            <div class="affiliate_shares_pin_table">
                <?php echo $this->load->view('pins/affiliate_shares_pin_table', NULL, TRUE); ?>
            </div>
        </div>
    </div>
</div>


<script type="text/javascript">
    $(document).ready(function() {
        $('#affiliate_shares_pin_table').DataTable({
            "order": [0, 'desc'],
            responsive: true
        });
        $('#generate_pins').on('submit', function(e){
            e.preventDefault();
            $.ajax({
                type: 'POST',
                url: '<?php echo base_url();?>pins/generated_affiliate_shares_pin',
                data: {no_of_shares : $('#no_of_shares').val()},
                success: function(data) 
                {
                    var data = JSON.parse(data);
                    $('.affiliate_shares_pin_table').html(data.table);
                    $('#affiliate_shares_pin_table').DataTable({
                        "order": [0, 'desc'],
                        responsive: true
                    });
                    $('.alert').attr('hidden', false);
                    toastr.success("Success!");
                    window.open("<?php echo base_url('pins/export_cfcws_pins/'); ?>" + encodeURIComponent(data.created_date), '_blank');
                }
            });
        });
    });
</script>