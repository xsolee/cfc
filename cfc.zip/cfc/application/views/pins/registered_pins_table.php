<table id="registered_pins_table" class="table table-striped table-hover nowrap table-bordered" style="width:100%;">
    <thead>
        <tr>
            <th>Pin ID</th>
            <th>Pin 1</th>
            <th>Pin 2</th>
            <th>Account ID</th>
            <th>Account Username</th>
            <th>Account Name</th>
            <th>Transfer To</th>
            <th>Date Used</th>
            <th>Date Created</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach($result as $row) { ?>
            <tr class="tr-hover">
                <td><?php echo $row->PIN_id; ?></td>
                <td><?php echo $row->PIN1; ?></td>
                <td><?php echo $row->PIN2; ?></td>
                <td><?php echo $row->account_id; ?></td>
                <td><?php echo $row->username; ?></td>
                <td><?php echo ucwords($row->first_name . " " . $row->last_name); ?></td>
                <td><?php echo $row->transfer_to; ?></td>
                <td><?php echo $row->date_used!=null?(new DateTime($row->date_used))->format('Y-m-d'):""; ?></td>
                <td><?php echo (new DateTime($row->date_created))->format('Y-m-d'); ?></td>
            </tr>
        <?php } ?>
    </tbody>
</table>