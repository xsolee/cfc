<table id="product_purchases_table" class="table table-striped table-hover nowrap table-bordered" style="width:100%;">
    <thead>
        <tr>
            <th>ID</th>
            <th>Account ID</th>
            <th>Product Name</th>
            <th>Product Price</th>
            <th>Product Quantity</th>
            <th>Total</th>
            <th>Date Created</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach($result as $row) { ?>
            <tr class="tr-hover">
                <td><?php echo $row->id; ?></td>
                <td><?php echo $row->account_id; ?></td>
                <td><?php echo $row->product_name; ?></td>
                <td><?php echo $row->product_price; ?></td>
                <td><?php echo $row->product_quantity; ?></td>
                <td><?php echo $row->product_price * $row->product_quantity; ?></td>
                <td><?php echo (new DateTime($row->date_created))->format('Y-m-d'); ?></td>
            </tr>
        <?php } ?>
    </tbody>
</table>