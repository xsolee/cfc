<section class="content">
	<div class="row">
		<div class="col-md-12">
			<div class="row">
				<div class="pull-right box-tools" style="margin: -40px 20px; ">
					<button type="button" class="btn btn-success btn-sm" data-toggle="modal" data-target="#add_purchase_modal"> Add </button>
				</div>
			</div>
			<div id="alert1" class="alert alert-warning alert-dismissible" hidden>
				<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button>
				<strong class="message">Successfully added purchase</strong>
			</div>
			<div class="box box-darkbrown">
				<div class="box-body product_purchases_table">
                    <?php echo $this->load->view('product_purchases/product_purchases_table', NULL, TRUE); ?>
				</div>
			</div>
		</div>
	</div>
</section>

<div class="modal" id="add_purchase_modal">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">×</span></button>
				<h4 class="modal-title">Add Purchase Details</h4>
			</div>
			<div class="modal-body">
				<form class="form-horizontal" id="add_purchase_form" method="post">
					<div class="box-body">
						<div class="row">
							<div id="alert" class="alert alert-warning alert-dismissible" hidden>
								<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button>
								<strong id="message"></strong>
							</div>
						</div>
						<div class="col-md-12">
							<div class="form-group">
								<label for="account_id">Account ID</label>
								<input type="text" class="form-control" id="account_id" name="account_id">
							</div>
						</div>
						<div class="col-md-12">
							<div class="form-group">
								<label for="product_name">Product Name</label>
								<input type="text" class="form-control" id="product_name" name="product_name">
							</div>
						</div>
						<div class="col-md-12">
							<div class="form-group">
								<label for="product_price">Product Unit Price</label>
								<input type="text" class="form-control" id="product_price" name="product_price">
							</div>
						</div>
						<div class="col-md-12">
							<div class="form-group">
								<label for="product_quantity">Quantity</label>
								<input type="text" class="form-control" id="product_quantity" name="product_quantity">
							</div>
						</div>
					</div>
				</form>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
				<button type="button" class="btn btn-primary" onclick="add_purchase()">Add Purchase</button>
			</div>
		</div>
		<!-- /.modal-content -->
	</div>
	<!-- /.modal-dialog -->
</div>
<!-- /.modal -->

<script type="text/javascript">
	$(document).ready(function(){
		$('#add_purchase_modal').modal('hide');

		$('#product_purchases_table').DataTable({
			"order": [0, 'asc']
		});
	});

	function add_purchase(){

		$.ajax({
			type: 'POST',
			url: "<?php echo base_url('product_purchases/add'); ?>",
			data: $('#add_purchase_form').serialize(),

			success: function(data) {
				if(data.search("Error") != -1){
					$("#alert").attr("hidden",false);
					$('#message').text(data);
				} else {
					$('.product_purchases_table').html(data);
	                $('#product_purchases_table').DataTable({
	                    "order": [0, 'asc']
	                });
					$("#alert1").attr("hidden",false);
					$('#add_purchase_modal').modal('hide');
				}
			}
		});
	}

</script>