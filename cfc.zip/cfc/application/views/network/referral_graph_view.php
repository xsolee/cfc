<div class="kt-container kt-container--fluid kt-grid__item kt-grid__item--fluid">
	<div class="kt-portlet kt-portlet--mobile kt-portlet--height-fluid-">
		<div class="kt-portlet__head kt-portlet__head--lg">
			<div class="kt-portlet__head-label">
				<span class="kt-portlet__head-icon">
					<i class="kt-font-brand flaticon-map"></i>
				</span>
				<h3 class="kt-portlet__head-title">
					Direct Referral
				</h3>
			</div>
		</div>
		<div class="kt-portlet__body" style="overflow-x: scroll;">
			<?php echo ucwords($this->session->userdata()['lastname'].", ".$this->session->userdata()['firstname'])." (".$this->session->userdata()['user_id'].")"; ?>
			<div id="direct_referrals" class="tree-demo">
			</div>
		</div>
	</div>
</div>

<script type="text/javascript">
	$(document).ready(function() {
		$("#direct_referrals").jstree({
            "core" : {
                "themes" : {
                    "responsive": false
                }, 
                // so that create works
                "check_callback" : true,
                'data' : {
                    'url' : function (node) {
                      return "<?php echo base_url('network/ajax_tree');?>";
                    },
                    'data' : function (node) {
                      return { 'parent' : node.id };
                    }
                }
            },
            "types" : {
                "default" : {
                    "icon" : "fa fa-folder kt-font-brand"
                },
                "file" : {
                    "icon" : "fa fa-file  kt-font-brand"
                }
            },
            "plugins" : [ "types" ]
        });
	});
</script>