<link rel="stylesheet" href="<?php echo base_url('resources/css/jquery.treegrid.css');?>">
<section class="content">
	<div class="row">
		<div class="col-sm-12">
			<div class="box box-primary">
				<div class="box-header with-border">
					<h3 class="box-title">[<?php echo $this->session->userdata()['user_id']; ?>] <?php echo ucwords($this->session->userdata()['firstname']." ".$this->session->userdata()['lastname']); ?></h3>
				</div>
				<!-- /.box-header -->
				<div class="box-body">
					<table class="tree">
					  <tbody>
						<?php foreach ($tree as $user_id => $user) {
							if($user_id != 0 && $user['parent']==0){
								echo "<tr class='treegrid-".$user_id."'><td>[".ucwords($user['position']).": ".$user['user_id']." : ".$user['username']."] ".ucwords($user['name'])."</td></tr>";
							} else if ($user_id != 0){
								echo "<tr class='treegrid-".$user_id." treegrid-parent-".$user['parent']."'><td>[".ucwords($user['position']).": ".$user['user_id']." : ".$user['username']."] ".ucwords($user['name'])."</td></tr>";
							}
						}
						?>
					  </tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
	<!-- <div class="tree">
		<ul>
  			<li>
				<a href="#" title="tooltip goes here">Parent</a>
				<ul>
		  			<li>
						<a href="#">Child</a>
						<ul>
			  				<li>
								<a href="#">Grand Child</a>
			  				</li>
			  				<li>
								<a href="#">Grand Child</a>
								<ul>
				  					<li>
										<a href="#">Grand Child</a>
				  					</li>
				  					<li>
										<a href="#">Grand Child</a>
				  					</li>
								</ul>
			  				</li>
						</ul>
		  			</li>
		  			<li>
						<a href="#">Child</a>
						<ul>
						  	<li>
								<a href="#">Grand Child</a>
								<ul>
							  		<li>
										<a href="#">Grand Grand Child</a>
							  		</li>
								</ul>
						  	</li>
						  	<li>
								<a href="#">Grand Child</a>
						  	</li>
						</ul>
		  			</li>
				</ul>
	  		</li>
		</ul>
	</div> -->
</section>
<style type="text/css">
	body {
  font-family: sans-serif;
  font-size: 15px;
}

.tree ul {
  position: relative;
  padding: 1em 0;
  white-space: nowrap;
  margin: 0 auto;
  text-align: center;
}
.tree ul::after {
  content: '';
  display: table;
  clear: both;
}

.tree li {
  display: inline-block;
  vertical-align: top;
  text-align: center;
  list-style-type: none;
  position: relative;
  padding: 1em .5em 0 .5em;
}
.tree li::before, .tree li::after {
  content: '';
  position: absolute;
  top: 0;
  right: 50%;
  border-top: 1px solid #ccc;
  width: 50%;
  height: 1em;
}
.tree li::after {
  right: auto;
  left: 50%;
  border-left: 1px solid #ccc;
}
.tree li:only-child::after, .tree li:only-child::before {
  display: none;
}
.tree li:only-child {
  padding-top: 0;
}
.tree li:first-child::before, .tree li:last-child::after {
  border: 0 none;
}
.tree li:last-child::before {
  border-right: 1px solid #ccc;
  border-radius: 0 5px 0 0;
}
.tree li:first-child::after {
  border-radius: 5px 0 0 0;
}

.tree ul ul::before {
  content: '';
  position: absolute;
  top: 0;
  left: 50%;
  border-left: 1px solid #ccc;
  width: 0;
  height: 1em;
}

.tree li a {
  border: 1px solid #ccc;
  padding: .5em .75em;
  text-decoration: none;
  display: inline-block;
  border-radius: 5px;
  color: #333;
  position: relative;
  top: 1px;
}

.tree li a:hover,
.tree li a:hover + ul li a {
  background: #e9453f;
  color: #fff;
  border: 1px solid #e9453f;
}

.tree li a:hover + ul li::after,
.tree li a:hover + ul li::before,
.tree li a:hover + ul::before,
.tree li a:hover + ul ul::before {
  border-color: #e9453f;
}

</style>

<script src="<?php echo base_url('resources/js/jquery.treegrid.min.js');?>"></script>
<script type="text/javascript">
	$('.tree').treegrid();
</script>