<div class="kt-container kt-container--fluid kt-grid__item kt-grid__item--fluid">
	<div class="kt-portlet kt-portlet--mobile kt-portlet--height-fluid-">
		<div class="kt-portlet__head kt-portlet__head--lg">
			<div class="kt-portlet__head-label">
				<span class="kt-portlet__head-icon">
					<i class="kt-font-brand flaticon2-list-1"></i>
				</span>
				<h3 class="kt-portlet__head-title">
					Genealogy List
				</h3>
			</div>
		</div>
		<div class="kt-portlet__body">
			<table id="genealogy_list" class="table table-striped table-bordered table-hover">
				<thead>
					<tr>
						<th>ID</th>
						<th>Parent</th>
						<th>Position</th>
						<th>Account ID</th>
						<th>Username</th>
						<th>Name</th>
					</tr>
				</thead>
				<tbody>
					<?php foreach($tree as $user_id => $user) { ?>
						<tr>
							<td><?php echo $user_id; ?></td>
							<td><?php echo $user['parent']; ?></td>
							<td><?php echo $user['position']; ?></td>
							<td><?php echo $user['user_id']; ?></td>
							<td><?php echo $user['username']; ?></td>
							<td><?php echo $user['name']; ?></td>
						</tr>
					<?php } ?>
				</tbody>
			</table>
		</div>
	</div>
</div>

<script type="text/javascript">

	$(document).ready(function(){
		$('#genealogy_list').DataTable({
            "order": [0, 'asc'],
			"iDisplayLength": 25,
            responsive: true
        });
	});
</script>