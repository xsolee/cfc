<div class="kt-container kt-container--fluid kt-grid__item kt-grid__item--fluid">
    <div class="kt-portlet kt-portlet--mobile kt-portlet--height-fluid-">
        <div class="kt-portlet__head kt-portlet__head--lg">
            <div class="kt-portlet__head-label">
                <span class="kt-portlet__head-icon">
                    <i class="kt-font-brand flaticon-map"></i>
                </span>
                <h3 class="kt-portlet__head-title">
                    Forex Unilevel
                </h3>
            </div>
            <div class="kt-portlet__head-toolbar">
                <?php if(!$has_forex_sponsor && $this->session->userdata('user_id')!="0000001") { ?>
                    <div class="row">
                        <button type="button" class="btn btn-sm btn-label-success btn-bold btn-upper forexSponsor" data-toggle="modal" data-target="#sponsor_modal">Add Forex Sponsor</button>
                    </div>
                <?php } else if($has_forex_sponsor && !$has_forex_placement && $this->session->userdata('user_id')!="0000001") { ?>
                    <div class="row">
                        <button type="button" class="btn btn-sm btn-label-success btn-bold btn-upper forexPlacement" data-toggle="modal" data-target="#placement_modal">Add Forex Placement</button>
                    </div>
                <?php } ?>
            </div>
        </div>
        <div class="kt-portlet__body" style="overflow-x: scroll;">
            <?php echo ucwords($this->session->userdata()['lastname'].", ".$this->session->userdata()['firstname'])." (".$this->session->userdata()['user_id'].")"; ?>
            <div id="direct_referrals" class="tree-demo">
            </div>
        </div>
    </div>
</div>

<?php if(!$has_forex_sponsor) { ?>
    <div class="modal fade" id="sponsor_modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" >
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <form id="sponsor_form" method="POST">
                    <div class="modal-header">
                        <h5 class="modal-title" id="myModalLabel">Add Forex Sponsor</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="col-md-12">
                            <div class="form-group">
                                <label for="account_id" class="col-sm-3 control-label">Sponsor ID</label>
                                <input type="number" class="form-control" name="account_id" required>
                            </div>
                            <div class="form-group">
                                <label for="placement_id" class="col-sm-3 control-label">Placement ID</label>
                                <input type="number" class="form-control" name="placement_id" required>
                            </div>
                            <div class="form-group">
                                <label for="placement" class="col-sm-3 control-label">Placement</label>
                                <select class="form-control selectpicker" tabindex="-1" name="placement" required>
                                    <option value="left">Left</option>
                                    <option value="center">Center</option>
                                    <option value="right">Right</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="pin" class="col-sm-3 control-label">Pincode</label>
                                <input type="text" class="form-control" name="pin" required>
                            </div>
                            <div class="form-group row">
                                <label for="date_started" class="col-sm-3 control-label">Start Date</label>
                                <div class="input-group date">
                                    <input type="text" class="form-control kt_datepicker_2" readonly placeholder="Select date" name="date_started">
                                    <div class="input-group-append">
                                        <span class="input-group-text">
                                            <i class="la la-calendar-check-o"></i>
                                        </span>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Save</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php } else if($has_forex_sponsor && !$has_forex_placement) { ?>
    <div class="modal fade" id="placement_modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" >
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <form id="placement_form" method="POST">
                    <div class="modal-header">
                        <h5 class="modal-title" id="myModalLabel">Add Forex Placement</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="col-md-12">
                            <div class="form-group">
                                <label for="placement_id" class="col-sm-3 control-label">Placement ID</label>
                                <input type="number" class="form-control" name="placement_id" required>
                            </div>
                            <div class="form-group">
                                <label for="placement" class="col-sm-3 control-label">Placement</label>
                                <select class="form-control selectpicker" tabindex="-1" name="placement" required>
                                    <option value="left">Left</option>
                                    <option value="center">Center</option>
                                    <option value="right">Right</option>
                                </select>
                            </div>
                            <div class="form-group row">
                                <label for="date_started" class="col-sm-3 control-label">Start Date</label>
                                <div class="input-group date">
                                    <input type="text" class="form-control kt_datepicker_2" readonly placeholder="Select date" name="date_started">
                                    <div class="input-group-append">
                                        <span class="input-group-text">
                                            <i class="la la-calendar-check-o"></i>
                                        </span>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Save</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php } ?>

<script type="text/javascript">
    $(document).ready(function() {
        $('.kt_datepicker_2').datepicker({
            todayHighlight: true,
            orientation: "bottom left",
            templates: {
                leftArrow: '<i class="la la-angle-left"></i>',
                rightArrow: '<i class="la la-angle-right"></i>'
            }
        });

        $("#direct_referrals").jstree({
            "core" : {
                "themes" : {
                    "responsive": false
                }, 
                // so that create works
                "check_callback" : true,
                'data' : {
                    'url' : function (node) {
                      return "<?php echo base_url('network/forex_tree');?>";
                    },
                    'data' : function (node) {
                      return { 'parent' : node.id };
                    }
                }
            },
            "types" : {
                "default" : {
                    "icon" : "fa fa-folder kt-font-brand"
                },
                "file" : {
                    "icon" : "fa fa-file  kt-font-brand"
                }
            },
            "plugins" : [ "types" ]
        });


        $( "#sponsor_form" ).validate({
            // define validation rules
            rules: {
                account_id : {
                    required: true,
                    minlength: 8
                },
                placement_id : {
                    required: true,
                    minlength: 8
                },
                placement : {
                    required: true
                },
                pin : {
                    required: true,
                    minlength: 10
                }
            },
            
            invalidHandler: function(event, validator) {     
                swal.fire("Error!", "Please fill the fields correctly and try submitting again.", "warning");
            },

            submitHandler: function (form) {
                $.ajax({
                    type: 'POST',
                    url: "<?php echo base_url('account/add_forex_sponsor'); ?>",
                    data: $('#sponsor_form').serialize(),

                    success: function(data) {
                        var data = JSON.parse(data);
                        if(data.message == 'Success') {
                            $('#sponsor_modal').modal('hide');
                            $('.forexSponsor').hide();
                            toastr.success("Success!");
                        } else {
                            toastr.error(data.message);
                        }
                    }
                });
            }
        });

        $( "#placement_form" ).validate({
            // define validation rules
            rules: {
                placement_id : {
                    required: true,
                    minlength: 8
                },
                placement : {
                    required: true
                }
            },
            
            invalidHandler: function(event, validator) {     
                swal.fire("Error!", "Please fill the fields correctly and try submitting again.", "warning");
            },

            submitHandler: function (form) {
                $.ajax({
                    type: 'POST',
                    url: "<?php echo base_url('account/add_forex_sponsor'); ?>",
                    data: $('#placement_form').serialize(),

                    success: function(data) {
                        var data = JSON.parse(data);
                        if(data.message == 'Success') {
                            $('#placement_modal').modal('hide');
                            $('.forexPlacement').hide();
                            toastr.success("Success!");
                        } else {
                            toastr.error(data.message);
                        }
                    }
                });
            }
        });
    });
</script>