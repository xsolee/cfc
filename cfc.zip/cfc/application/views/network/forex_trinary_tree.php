<style type="text/css">
	#forex_trinary_tree_table a {
		color: green;
	}
</style>
<div class="kt-container kt-container--fluid kt-grid__item kt-grid__item--fluid">
	<div class="kt-portlet kt-portlet--mobile kt-portlet--height-fluid-">
		<div class="kt-portlet__head kt-portlet__head--lg">
			<div class="kt-portlet__head-label">
				<span class="kt-portlet__head-icon">
					<i class="kt-font-brand flaticon-map"></i>
				</span>
				<h3 class="kt-portlet__head-title">
					Forex Trinary Tree
				</h3>
			</div>
		</div>
		<div class="kt-portlet__body" style="overflow-x: scroll;">
			<table id="forex_trinary_tree_table" width="98%" border="0" align="center" cellpadding="0" cellspacing="0" style="font-family:Arial, Helvetica, sans-serif; font-size:10px;border:0px; ">
				<tbody>
					<tr align="center" height="100">
						<td colspan="9" style="text-align:center; border:0px;">
							<?php if ($tree[0]['user_id'] != $this->session->userdata()['user_id']){ ?>
							<a href="<?php echo base_url('network/forex_trinary_tree/'.$parent_id); ?>" class="col-xs-12">
								<img src="<?php echo base_url('resources/images/arrowupblue.png'); ?>" border="0" alt="Up One Level" title="Up One Level">
							</a><br>
							<?php } ?>
							<a title="<?php echo $tree[0]['name']; ?>" href="<?php echo base_url('network/forex_trinary_tree/'.$tree[0]['user_id']); ?>">
								<img src="<?php echo base_url('resources/images/'.$tree[0]['color'].'.png'); ?>" width="32" height="32" border="0" style="display:inline-table" align="middle">
							<br><b style="font-size: 13px;"><?php echo $tree[0]['username']; ?></b>
							</a>
							<a style="color: blue;" class="get_user_id" data-user_id="<?php echo $tree[0]['user_id']; ?>"><br><b style="font-size: 13px;"><?php echo $tree[0]['user_id']; ?></b></a>
							
						</td>
					</tr>

					<tr align="center" height="100">

						<td colspan="3" style="text-align:center; border:0px;" width="33.33%">
							<?php if(!empty($tree[1]) && $tree[1]['activated']) { ?>
								<img src="<?php echo base_url('resources/images/'.$tree[1]['color'].'.png'); ?>" width="32" height="32" border="0" style="display:inline-table;">
							<?php } else { ?>
								<img src="<?php echo base_url('resources/images/noman_red.png'); ?>" width="32" height="32" border="0" style="display:inline-table;">
							<?php } ?>
							<?php if(!empty($tree[1])) { ?>
								<a title="<?php echo $tree[1]['name']; ?>" href="<?php echo base_url('network/forex_trinary_tree/'.$tree[1]['user_id']); ?>">
								
								<br><b style="font-size: 13px;"><?php echo $tree[1]['username']; ?></b>
								</a>
								<a style="color: blue;" class="get_user_id" data-user_id="<?php echo $tree[1]['user_id']; ?>"><br><b style="font-size: 13px;"><?php echo $tree[1]['user_id']; ?></b></a>
								
							<?php } ?>
						</td>

						<td colspan="3" style="text-align:center; border:0px;" width="33.33%">
							
							<?php if(!empty($tree[2]) && $tree[2]['activated']) { ?>
								<img src="<?php echo base_url('resources/images/'.$tree[2]['color'].'.png'); ?>" width="32" height="32" border="0" style="display:inline-table;">
							<?php } else { ?>
								<img src="<?php echo base_url('resources/images/noman_red.png'); ?>" width="32" height="32" border="0" style="display:inline-table;">
							<?php } ?>

							<?php if(!empty($tree[2])) { ?>
								<a title="<?php echo $tree[2]['name']; ?>" href="<?php echo base_url('network/forex_trinary_tree/'.$tree[2]['user_id']); ?>">
								
								<br><b style="font-size: 13px;"><?php echo $tree[2]['username']; ?></b>
								</a>
								<a style="color: blue;" class="get_user_id" data-user_id="<?php echo $tree[2]['user_id']; ?>"><br><b style="font-size: 13px;"><?php echo $tree[2]['user_id']; ?></b></a>
								
							<?php } ?>
						</td>

						<td colspan="3" style="text-align:center; border:0px;" width="33.33%">
							
							<?php if(!empty($tree[3]) && $tree[3]['activated']) { ?>
								<img src="<?php echo base_url('resources/images/'.$tree[3]['color'].'.png'); ?>" width="32" height="32" border="0" style="display:inline-table;">
							<?php } else { ?>
								<img src="<?php echo base_url('resources/images/noman_red.png'); ?>" width="32" height="32" border="0" style="display:inline-table;">
							<?php } ?>

							<?php if(!empty($tree[3])) { ?>
								<a title="<?php echo $tree[3]['name']; ?>" href="<?php echo base_url('network/forex_trinary_tree/'.$tree[3]['user_id']); ?>">
								
								<br><b style="font-size: 13px;"><?php echo $tree[3]['username']; ?></b>
								</a>
								<a style="color: blue;" class="get_user_id" data-user_id="<?php echo $tree[3]['user_id']; ?>"><br><b style="font-size: 13px;"><?php echo $tree[3]['user_id']; ?></b></a>
								
							<?php } ?>
						</td>
					</tr>

					<tr align="center" height="100">

						<td colspan="1" style="text-align:center; border:0px;" width="11.11%">
							<?php if(!empty($tree[4]) && $tree[4]['activated']) { ?>
								<img src="<?php echo base_url('resources/images/'.$tree[4]['color'].'.png'); ?>" width="32" height="32" border="0" style="display:inline-table;">
							<?php } else { ?>
								<img src="<?php echo base_url('resources/images/noman_red.png'); ?>" width="32" height="32" border="0" style="display:inline-table;">
							<?php } ?>
							<?php if(!empty($tree[4])) { ?>
								<a title="<?php echo $tree[4]['name']; ?>" href="<?php echo base_url('network/forex_trinary_tree/'.$tree[4]['user_id']); ?>">
								
								<br><b style="font-size: 13px;"><?php echo $tree[4]['username']; ?></b>
								</a>
								<a style="color: blue;" class="get_user_id" data-user_id="<?php echo $tree[4]['user_id']; ?>"><br><b style="font-size: 13px;"><?php echo $tree[4]['user_id']; ?></b></a>
								
							<?php } ?>
						</td>

						<td colspan="1" style="text-align:center; border:0px;" width="11.11%">
							
							<?php if(!empty($tree[5]) && $tree[5]['activated']) { ?>
								<img src="<?php echo base_url('resources/images/'.$tree[5]['color'].'.png'); ?>" width="32" height="32" border="0" style="display:inline-table;">
							<?php } else { ?>
								<img src="<?php echo base_url('resources/images/noman_red.png'); ?>" width="32" height="32" border="0" style="display:inline-table;">
							<?php } ?>

							<?php if(!empty($tree[5])) { ?>
								<a title="<?php echo $tree[5]['name']; ?>" href="<?php echo base_url('network/forex_trinary_tree/'.$tree[5]['user_id']); ?>">
								
								<br><b style="font-size: 13px;"><?php echo $tree[5]['username']; ?></b>
								</a>
								<a style="color: blue;" class="get_user_id" data-user_id="<?php echo $tree[5]['user_id']; ?>"><br><b style="font-size: 13px;"><?php echo $tree[5]['user_id']; ?></b></a>
								
							<?php } ?>
						</td>

						<td colspan="1" style="text-align:center; border:0px;" width="11.11%">
							
							<?php if(!empty($tree[6]) && $tree[6]['activated']) { ?>
								<img src="<?php echo base_url('resources/images/'.$tree[6]['color'].'.png'); ?>" width="32" height="32" border="0" style="display:inline-table;">
							<?php } else { ?>
								<img src="<?php echo base_url('resources/images/noman_red.png'); ?>" width="32" height="32" border="0" style="display:inline-table;">
							<?php } ?>

							<?php if(!empty($tree[6])) { ?>
								<a title="<?php echo $tree[6]['name']; ?>" href="<?php echo base_url('network/forex_trinary_tree/'.$tree[6]['user_id']); ?>">
								
								<br><b style="font-size: 13px;"><?php echo $tree[6]['username']; ?></b>
								</a>
								<a style="color: blue;" class="get_user_id" data-user_id="<?php echo $tree[6]['user_id']; ?>"><br><b style="font-size: 13px;"><?php echo $tree[6]['user_id']; ?></b></a>
								
							<?php } ?>
						</td>

						<td colspan="1" style="text-align:center; border:0px;" width="11.11%">
							<?php if(!empty($tree[7]) && $tree[7]['activated']) { ?>
								<img src="<?php echo base_url('resources/images/'.$tree[7]['color'].'.png'); ?>" width="32" height="32" border="0" style="display:inline-table;">
							<?php } else { ?>
								<img src="<?php echo base_url('resources/images/noman_red.png'); ?>" width="32" height="32" border="0" style="display:inline-table;">
							<?php } ?>
							<?php if(!empty($tree[7])) { ?>
								<a title="<?php echo $tree[7]['name']; ?>" href="<?php echo base_url('network/forex_trinary_tree/'.$tree[7]['user_id']); ?>">
								
								<br><b style="font-size: 13px;"><?php echo $tree[7]['username']; ?></b>
								</a>
								<a style="color: blue;" class="get_user_id" data-user_id="<?php echo $tree[7]['user_id']; ?>"><br><b style="font-size: 13px;"><?php echo $tree[7]['user_id']; ?></b></a>
								
							<?php } ?>
						</td>

						<td colspan="1" style="text-align:center; border:0px;" width="11.11%">
							
							<?php if(!empty($tree[8]) && $tree[8]['activated']) { ?>
								<img src="<?php echo base_url('resources/images/'.$tree[8]['color'].'.png'); ?>" width="32" height="32" border="0" style="display:inline-table;">
							<?php } else { ?>
								<img src="<?php echo base_url('resources/images/noman_red.png'); ?>" width="32" height="32" border="0" style="display:inline-table;">
							<?php } ?>

							<?php if(!empty($tree[8])) { ?>
								<a title="<?php echo $tree[8]['name']; ?>" href="<?php echo base_url('network/forex_trinary_tree/'.$tree[8]['user_id']); ?>">
								
								<br><b style="font-size: 13px;"><?php echo $tree[8]['username']; ?></b>
								</a>
								<a style="color: blue;" class="get_user_id" data-user_id="<?php echo $tree[8]['user_id']; ?>"><br><b style="font-size: 13px;"><?php echo $tree[8]['user_id']; ?></b></a>
								
							<?php } ?>
						</td>

						<td colspan="1" style="text-align:center; border:0px;" width="11.11%">
							
							<?php if(!empty($tree[9]) && $tree[9]['activated']) { ?>
								<img src="<?php echo base_url('resources/images/'.$tree[9]['color'].'.png'); ?>" width="32" height="32" border="0" style="display:inline-table;">
							<?php } else { ?>
								<img src="<?php echo base_url('resources/images/noman_red.png'); ?>" width="32" height="32" border="0" style="display:inline-table;">
							<?php } ?>

							<?php if(!empty($tree[9])) { ?>
								<a title="<?php echo $tree[9]['name']; ?>" href="<?php echo base_url('network/forex_trinary_tree/'.$tree[9]['user_id']); ?>">
								
								<br><b style="font-size: 13px;"><?php echo $tree[9]['username']; ?></b>
								</a>
								<a style="color: blue;" class="get_user_id" data-user_id="<?php echo $tree[9]['user_id']; ?>"><br><b style="font-size: 13px;"><?php echo $tree[9]['user_id']; ?></b></a>
								
							<?php } ?>
						</td>

						<td colspan="1" style="text-align:center; border:0px;" width="11.11%">
							<?php if(!empty($tree[10]) && $tree[10]['activated']) { ?>
								<img src="<?php echo base_url('resources/images/'.$tree[10]['color'].'.png'); ?>" width="32" height="32" border="0" style="display:inline-table;">
							<?php } else { ?>
								<img src="<?php echo base_url('resources/images/noman_red.png'); ?>" width="32" height="32" border="0" style="display:inline-table;">
							<?php } ?>
							<?php if(!empty($tree[10])) { ?>
								<a title="<?php echo $tree[10]['name']; ?>" href="<?php echo base_url('network/forex_trinary_tree/'.$tree[10]['user_id']); ?>">
								
								<br><b style="font-size: 13px;"><?php echo $tree[10]['username']; ?></b>
								</a>
								<a style="color: blue;" class="get_user_id" data-user_id="<?php echo $tree[10]['user_id']; ?>"><br><b style="font-size: 13px;"><?php echo $tree[10]['user_id']; ?></b></a>
								
							<?php } ?>
						</td>

						<td colspan="1" style="text-align:center; border:0px;" width="11.11%">
							
							<?php if(!empty($tree[11]) && $tree[11]['activated']) { ?>
								<img src="<?php echo base_url('resources/images/'.$tree[11]['color'].'.png'); ?>" width="32" height="32" border="0" style="display:inline-table;">
							<?php } else { ?>
								<img src="<?php echo base_url('resources/images/noman_red.png'); ?>" width="32" height="32" border="0" style="display:inline-table;">
							<?php } ?>

							<?php if(!empty($tree[11])) { ?>
								<a title="<?php echo $tree[11]['name']; ?>" href="<?php echo base_url('network/forex_trinary_tree/'.$tree[11]['user_id']); ?>">
								
								<br><b style="font-size: 13px;"><?php echo $tree[11]['username']; ?></b>
								</a>
								<a style="color: blue;" class="get_user_id" data-user_id="<?php echo $tree[11]['user_id']; ?>"><br><b style="font-size: 13px;"><?php echo $tree[11]['user_id']; ?></b></a>
								
							<?php } ?>
						</td>

						<td colspan="1" style="text-align:center; border:0px;" width="11.11%">
							
							<?php if(!empty($tree[12]) && $tree[12]['activated']) { ?>
								<img src="<?php echo base_url('resources/images/'.$tree[12]['color'].'.png'); ?>" width="32" height="32" border="0" style="display:inline-table;">
							<?php } else { ?>
								<img src="<?php echo base_url('resources/images/noman_red.png'); ?>" width="32" height="32" border="0" style="display:inline-table;">
							<?php } ?>

							<?php if(!empty($tree[12])) { ?>
								<a title="<?php echo $tree[12]['name']; ?>" href="<?php echo base_url('network/forex_trinary_tree/'.$tree[12]['user_id']); ?>">
								
								<br><b style="font-size: 13px;"><?php echo $tree[12]['username']; ?></b>
								</a>
								<a style="color: blue;" class="get_user_id" data-user_id="<?php echo $tree[12]['user_id']; ?>"><br><b style="font-size: 13px;"><?php echo $tree[12]['user_id']; ?></b></a>
								
							<?php } ?>
						</td>
					</tr>
				</tbody>
			</table>
		</div>
	</div>
</div>

<script type="text/javascript">

	$(document).ready(function(){
		toastr.options = {
		  "closeButton": false,
		  "debug": false,
		  "newestOnTop": false,
		  "progressBar": false,
		  "positionClass": "toast-top-right",
		  "preventDuplicates": false,
		  "onclick": null,
		  "showDuration": "300",
		  "hideDuration": "1000",
		  "timeOut": "5000",
		  "extendedTimeOut": "1000",
		  "showEasing": "swing",
		  "hideEasing": "linear",
		  "showMethod": "fadeIn",
		  "hideMethod": "fadeOut"
		};

		$('a.get_user_id').on('click', function(e) {
			var element = $(this).attr('data-user_id');

			var $temp = $("<input>");
			$("body").append($temp);
			$temp.val(element).select();
			document.execCommand("copy");
			$temp.remove();

			toastr.success("Account ID Copied.", "Success!");
		});
	});	
	
</script>