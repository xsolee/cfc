<section class="content">
	<div class="register-box-body">
		<div class="alert alert-warning alert-dismissible" hidden>
			<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
			<h4><i class="icon fa fa-warning"></i> Alert!</h4>
			<p id="message"></p>
		</div>
		<form class="form-horizontal" id="register_form" method="post">
			<div class="box-body">
				<div class="col-md-6">
					<div class="form-group">
						<label for="sponsor_ID" class="col-sm-3 control-label">Sponsor ID</label>
						<div class="col-sm-9">
							<input type="text" class="form-control" id="sponsor_ID" name="sponsor_ID" required="" value="<?php echo $this->session->userdata()['user_id']; ?>">
						</div>
					</div>
					<div class="form-group">
						<label for="placement_ID" class="col-sm-3 control-label">Placement ID</label>
						<div class="col-sm-9">
							<input type="text" class="form-control" id="placement_ID" name="placement_ID" required="">
						</div>
					</div>
					<div class="form-group">
						<label for="placement" class="col-sm-3 control-label">Placement</label>
						<div class="col-sm-5">
							<select class="form-control selectpicker" tabindex="-1" name="placement" required>
								<option>Left</option>
								<option>Right</option>
							</select>
						</div>
					</div>
					<div class="form-group">
						<label for="pin1" class="col-sm-3 control-label">PIN1</label>
						<div class="col-sm-5">
						<input type="text" class="form-control" id="pin1" name="pin1" required="">
						</div>
					</div>
					<div class="form-group">
						<label for="pin2" class="col-sm-3 control-label">PIN2</label>
						<div class="col-sm-5">
							<input type="text" class="form-control" id="pin2" name="pin2" required="">
						</div>
					</div>
					<div class="form-group">
						<label for="username" class="col-sm-3 control-label">Username</label>
						<div class="col-sm-9">
							<input type="text" class="form-control" id="username" name="username" autocomplete="off" required="">
						</div>
					</div>
					<div class="form-group">
						<label for="password" class="col-sm-3 control-label">Password</label>
						<div class="col-sm-9">
							<input type="password" class="form-control" id="password" name="password" autocomplete="off" required="">
						</div>
					</div>
					<div class="form-group">
						<label for="firstname" class="col-sm-3 control-label">First Name</label>
						<div class="col-sm-9">
							<input type="text" class="form-control" id="firstname" name="firstname" required="">
						</div>
					</div>
					<div class="form-group">
						<label for="lastname" class="col-sm-3 control-label">Last Name</label>
						<div class="col-sm-9">
							<input type="text" class="form-control" id="lastname" name="lastname" required="">
						</div>
					</div>
					<div class="form-group">
						<label for="mobile_number" class="col-sm-3 control-label">Mobile Number</label>
						<div class="col-sm-9">
							<input type="text" class="form-control" id="mobile_number" name="mobile_number" placeholder="09xxxxxxxxx" required="" maxlength="11">
						</div>
					</div>
				</div>
				<div class="col-md-6">
					<div class="form-group">
						<label for="email_address" class="col-sm-3 control-label">Email Address</label>
						<div class="col-sm-9">
							<input type="email" class="form-control" id="email_address" name="email_address">
						</div>
					</div>
					<div class="form-group">
						<label for="country" class="col-sm-3 control-label">Country</label>
						<div class="col-sm-9">
							<input type="text" class="form-control" id="country" name="country">
						</div>
					</div>
					<div class="form-group">
						<label for="address" class="col-sm-3 control-label">Address</label>
						<div class="col-sm-9">
							<input type="text" class="form-control" id="Address" name="address">
						</div>
					</div>
					<div class="form-group">
						<label for="birthday" class="col-sm-3 control-label">Birthday</label>
						<div class="date col-sm-9">
							<input type="text" class="form-control pull-right" id="datepicker" name="birthday">
						</div>
					</div>
					<div class="form-group">
						<label for="gender" class="col-sm-3 control-label">Gender</label>
						<div class="col-sm-5">
							<select class="form-control selectpicker" tabindex="-1" name="gender">
								<option>Male</option>
								<option>Female</option>
							</select>
						</div>
					</div>
				</div>
			</div>
			<div class="box-footer">
				<div class="col-md-6" style="float: none; margin: 0 auto; ">
					<button type="button" class="btn btn-danger btn-block btn-flat" id="btn_register">Register</button>
				</div>
			</div>
		</form>
	</div>
</section>
<script type="text/javascript">
	$(document).ready(function(){
		$('#datepicker').datepicker({
			autoclose: true,
			format: 'yyyy-mm-dd'
		});
		$('body').on('click','#btn_register', function(){
			$.ajax({
				type: 'POST',
				url: '<?php echo base_url();?>Account/register_subaccount',
				data: $('#register_form').serialize(),
				success: function(data) 
				{
					$(".alert").attr("hidden",false);
					$('#message').text(data);
					$("html, body").animate({ scrollTop: 0 }, "slow");
				}
			});
		});
	});
</script>