<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

if ( ! function_exists('mysql_date')){
	function mysql_date($date){
		return date('Y-m-d', strtotime($date));
	}
}

if ( ! function_exists('oracle_dff_date')){
	function oracle_dff_date($date){
		if($date == NULL OR $date == '0000-00-00'){
			return '-';
		}
		return date('Y/m/d', strtotime($date));
	}
}

if ( ! function_exists('oracle_date')){
	function oracle_date($date){
		if($date == NULL OR $date == '0000-00-00'){
			return '-';
		}
		return date('d-M-y', strtotime($date));
	}
}

if ( ! function_exists('date1')){
	function date1($date){
		if($date == NULL OR $date == '0000-00-00'){
			return '-';
		}
		return date('m/d/Y', strtotime($date));
	}
}

if ( ! function_exists('datetime1')){
	function datetime1($date){
		if($date == NULL OR $date == '0000-00-00'){
			return '-';
		}
		return date('m/d/Y g:i a', strtotime($date));
	}
}

if ( ! function_exists('formatDatetime2'))
{
    function formatDatetime2($datetime){

        return date('j M. Y', strtotime($datetime));
    }
}

if ( ! function_exists('timeAgo'))
{
    function timeAgo($time) {
        
        $orig_time = $time;
        $time = strtotime($time);
        $time = time() - $time;
        $time = ($time<1)? 1 : $time;
        $tokens = array (
            31536000 => 'year',
            2592000 => 'month',
            604800 => 'week',
            86400 => 'day',
            3600 => 'hour',
            60 => 'minute',
            1 => 'second'
        );
        foreach ($tokens as $unit => $text) {
            if ($time < $unit) continue;
            $numberOfUnits = floor($time / $unit);
            
            if($text == 'week' OR $text == 'month' OR $text == 'year'){
                return date('g:i a', strtotime($orig_time));
            }
            else{
                return $numberOfUnits.' '.$text.(($numberOfUnits>1)?'s ago':' ago');
            }
        }
        
        return $time;
    }  
}

if ( ! function_exists('amount_format')){
	function amount_format($number){
		return number_format($number, 2);
	}
}

if ( ! function_exists('str_uwords')){
	function str_uwords($str){
		return ucwords(strtolower($str));
	}
}

if ( ! function_exists('get_months')){
	function get_months(){

		$months = array(
			array('1'  , 'January'),
			array('2'  , 'February'),
			array('3'  , 'March'),
			array('4'  , 'April'),
			array('5'  , 'May'),
			array('6'  , 'June'),
			array('7'  , 'July'),
			array('8'  , 'August'),
			array('9'  , 'September'),
			array('10' , 'October'),
			array('11' , 'November'),
			array('12' , 'December')
		);

		return $months;
	}
}

if ( ! function_exists('get_years')){
	function get_years(){

		$curr_year  = date('Y');
		$start_year = 2017;
		$ctr        = 0;
		$years      = array();

		while($start_year <= $curr_year) {
			$years[$ctr] = $start_year;
			$start_year++;
			$ctr++;
		}

		return array_reverse($years, false);
	}
}

if ( ! function_exists('reArrayFiles')){
	function reArrayFiles($file_post){

		$file_ary = array();
		$file_count = count($file_post['name']);
		$file_keys = array_keys($file_post);

		for ($i=0; $i<$file_count; $i++) {
			foreach ($file_keys as $key) {
				$file_ary[$i][$key] = $file_post[$key][$i];
			}
		}

		return $file_ary;
	}
}