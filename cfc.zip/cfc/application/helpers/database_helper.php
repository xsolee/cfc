<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

if ( ! function_exists('get_account_details'))
{
    function get_account_details($account_id)
    {
        if($account_id == NULL) {
            return '-';
        }

    	$CI = get_instance();
        $CI->load->model('Account_model');
        $result = $CI->Account_model->get_account_details($account_id);
        return $result;
    }
}

if ( ! function_exists('get_sub_account_id'))
{
    function get_sub_account_id($account_id)
    {
        if($account_id == NULL) {
            return '-';
        }

        $CI = get_instance();
        $CI->load->model('Account_model');
        $main = $CI->Account_model->get_main_account_id($account_id);
        if($main){
            $result = $CI->Account_model->get_sub_account_id($main->main_account_id);
        } else {
            $result = $CI->Account_model->get_sub_account_id($account_id);
        }
        return $result;
    }

    function get_main_account_id($account_id)
    {
        if($account_id == NULL) {
            return '-';
        }

        $CI = get_instance();
        $CI->load->model('Account_model');
        $main = $CI->Account_model->get_main_account_id($account_id);
        if($main){
            return $main->main_account_id;
        } else {
            return $account_id;
        }
    }

    function get_all_sub_accounts($account_id)
    {
        if($account_id == NULL) {
            return '-';
        }

        $CI = get_instance();
        $CI->load->model('Account_model');
        $main = $CI->Account_model->get_main_account_id($account_id);
        if($main){
            $result = $CI->Account_model->get_sub_accounts($main->main_account_id);
            // $main = $CI->Account_model->get_account_from_id($main->account_id);
            array_unshift($result, (object)array('sub_account_id' => $main->main_account_id));
            return $result;
        } else {
            return $CI->Account_model->get_sub_accounts($account_id);
        }
    }
}